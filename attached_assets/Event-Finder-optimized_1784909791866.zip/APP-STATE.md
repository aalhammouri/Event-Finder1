# APP-STATE — Event Finder

> Complete technical reference for the Event Finder application.  
> Last generated: 2026-06-05  
> Intended audience: any AI or developer who needs a full mental model of the app in one read.

---

## 1. Tech Stack

### Monorepo
- **Package manager:** pnpm workspaces
- **TypeScript:** ~5.9.3 across all packages
- **Build system:** custom `esbuild` script for the server; Vite for the frontend

### Frontend (`artifacts/event-finder`)
| Concern | Library |
|---|---|
| Framework | React 18 |
| Bundler | Vite |
| Routing | Wouter |
| Server state | TanStack Query (React Query) |
| UI components | shadcn/ui (Radix UI primitives + Tailwind CSS) |
| Icons | Lucide React |
| Notifications | Sonner / shadcn Toaster |
| Auth storage | `localStorage` (`auth_token` key) |

### Backend (`artifacts/api-server`)
| Concern | Library |
|---|---|
| Runtime | Node.js (ESM) |
| HTTP framework | Express 5 |
| Logging | Pino + pino-http |
| Auth | JWT via `jose` (HS256, 8-hour expiry) |
| Password hashing | bcryptjs (12 rounds) |
| Web scraping (primary) | Firecrawl JS SDK (`@mendable/firecrawl-js`) |
| Web scraping (fallback) | `got` + `cheerio` |
| AI text extraction | OpenAI SDK → `gpt-4o-mini` |
| AI image extraction | OpenAI SDK → `gpt-4o` (vision) |
| Scheduling | `node-cron` |
| Email | Replit Connectors SDK → Resend API |

### Database (`lib/db`)
| Concern | Library |
|---|---|
| ORM | Drizzle ORM |
| Driver | `drizzle-orm/pg-core` (PostgreSQL) |
| Migrations | Drizzle Kit |
| Schema validation | Zod (via `drizzle-zod`) |

### Shared Libraries
- **`lib/api-spec`** — OpenAPI 3.x YAML specification
- **`lib/api-zod`** — Auto-generated Zod schemas from the OpenAPI spec (via Orval)
- **`lib/api-client-react`** — Auto-generated React Query hooks from the OpenAPI spec (via Orval)

### Hosting
- Replit (inferred from `REPLIT_DOMAINS` env var usage and `@replit/connectors-sdk` dependency)

---

## 2. Database Schema

All tables use PostgreSQL. Managed via Drizzle ORM. `DATABASE_URL` env var is required.

### `users`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `name` | text NOT NULL | |
| `email` | text NOT NULL UNIQUE | |
| `role` | text NOT NULL | `"admin"` or `"viewer"`, default `"viewer"` |
| `password_hash` | text | Null until account is activated |
| `activation_token` | text UNIQUE | UUID; cleared after activation |
| `activation_token_expires_at` | timestamptz | 7 days from issuance |
| `activated_at` | timestamptz | Null = pending account |
| `created_at` | timestamptz NOT NULL | default now() |

### `url_lists`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `name` | text NOT NULL | User-defined label |
| `created_at` | timestamptz NOT NULL | |
| `updated_at` | timestamptz NOT NULL | Auto-updated on change |

### `url_list_items`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `url_list_id` | integer NOT NULL FK → `url_lists.id` ON DELETE CASCADE | |
| `url` | text NOT NULL | The seed URL to crawl |
| `created_at` | timestamptz NOT NULL | |

### `crawl_runs`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `url_list_id` | integer NOT NULL FK → `url_lists.id` ON DELETE CASCADE | |
| `status` | text enum | `pending`, `running`, `completed`, `failed`, `stopped` |
| `triggered_by` | text enum | `manual`, `scheduled` |
| `total_urls` | integer | Count of seed URLs |
| `pages_crawled` | integer | Incremented during run |
| `events_matched` | integer | Incremented during run |
| `error_count` | integer | Incremented during run |
| `archived` | boolean NOT NULL | default false |
| `created_at` | timestamptz NOT NULL | |
| `completed_at` | timestamptz | Null while in-progress |
| `debug_log` | jsonb | Array of `{ ts, type, url?, msg, score? }` objects; flushed to DB every 5 seconds during a run |

### `events`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `run_id` | integer NOT NULL FK → `crawl_runs.id` ON DELETE CASCADE | |
| `score` | integer NOT NULL | 0–100 |
| `tier` | text enum | `A`, `B`, `C` |
| `status` | text enum | `NEW`, `UPDATED`, `UNCHANGED` |
| `event_name` | text | |
| `event_date` | text | Stored as extracted string |
| `event_venue` | text | |
| `event_address` | text | |
| `event_description` | text | |
| `auction_type` | text | `silent`, `live`, `both`, `online`, `none` |
| `has_silent_auction` | boolean | |
| `has_live_auction` | boolean | |
| `ticket_price` | numeric(10,2) | Per-person price |
| `table_price` | numeric(10,2) | Per-table/sponsorship price |
| `formality` | text | `black-tie`, `gala`, `cocktail`, `casual`, `unknown` |
| `rsvp_link` | text | |
| `contact_name` | text | |
| `contact_email` | text | |
| `contact_phone` | text | |
| `event_page_url` | text | Source URL of the page |
| `audience_note` | text | |
| `sponsorship_mentioned` | boolean | |
| `org_name` | text | |
| `org_address` | text | |
| `org_city` | text | |
| `org_phone` | text | |
| `org_email` | text | |
| `org_website` | text | |
| `is_past` | boolean NOT NULL | Computed at extraction time |
| `error_message` | text | |
| `created_at` | timestamptz NOT NULL | |

### `admin_settings`
Single-row configuration table (created on first `GET /admin/settings` if absent).

| Column | Type | Default |
|---|---|---|
| `id` | serial PK | |
| `search_keywords` | text[] | `["silent auction", "live auction", "raffle", "golf", "gala", ...]` |
| `avoid_keywords` | text[] | `["bingo", "walk", "wine", "arts", ...]` |
| `override_keywords` | text[] | `["silent auction"]` |
| `max_pages_per_site` | integer | `30` |
| `timeout_per_page` | integer | `30` (seconds) |
| `image_reading_enabled` | boolean | `true` |
| `scoring_weights` | jsonb | See §5 |
| `tier_thresholds` | jsonb | `{ tierA: 70, tierB: 45 }` |
| `min_score_for_email` | integer | `45` |
| `schedule_enabled` | boolean | `false` |
| `schedule_days` | text[] | `["Monday"]` |
| `schedule_time` | text | `"06:00"` |
| `schedule_timezone` | text | `"America/Chicago"` |
| `schedule_url_list_id` | integer | nullable |
| `updated_at` | timestamptz | auto-updated |

### `email_recipients`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `email` | text NOT NULL UNIQUE | |
| `active` | boolean NOT NULL | default true |
| `created_at` | timestamptz NOT NULL | |

Users are automatically upserted here on account activation.

### `domain_blacklist`
| Column | Type | Notes |
|---|---|---|
| `id` | serial PK | |
| `domain` | text NOT NULL UNIQUE | Bare hostname, e.g. `example.com` |
| `created_at` | timestamptz NOT NULL | |

---

## 3. API Routes

All routes are mounted under `/api`. Auth routes are public; everything else requires a valid `Authorization: Bearer <jwt>` header (or `?token=<jwt>` for SSE endpoints).

### Auth (`/api/auth/*`) — public

| Method | Path | What it does |
|---|---|---|
| POST | `/auth/register` | Self-registration for `@gofffinancial.com` emails. Creates pending user, sends activation email. |
| POST | `/auth/activate` | Consumes activation token, sets password hash, returns JWT + user. Also upserts user into `email_recipients`. |
| POST | `/auth/login` | Email + password → JWT + user object. |
| POST | `/auth/resend` | Resends activation email for a pending (unactivated) user. Response is deliberately non-revealing. |
| POST | `/auth/change-password` | Authenticated. Verifies current password, updates hash. |
| GET | `/auth/me` | Validates Bearer token, returns `{ id, email, name, role }`. |

### URL Lists (`/api/url-lists/*`) — auth required

| Method | Path | What it does |
|---|---|---|
| GET | `/url-lists` | List all URL lists with `urlCount` and `lastRunAt`. |
| POST | `/url-lists` | Create a list. Body: `{ name, urls?: string[] }`. Returns created list. |
| GET | `/url-lists/:id` | Single list with full URL array and `lastRunAt`. |
| PATCH | `/url-lists/:id` | Update name and/or replace URL array (delete-all-then-insert). |
| DELETE | `/url-lists/:id` | Delete list (cascades to runs and events). |
| POST | `/url-lists/:id/run` | Create a new crawl run for this list and start it in the background. Returns `202` with run object. |

### Crawl Runs (`/api/crawl-runs/*`) — auth required

| Method | Path | What it does |
|---|---|---|
| GET | `/crawl-runs` | List all non-archived runs (pass `?includeArchived=true` for all). Optionally filter by `?urlListId=`. Includes `topScore`. |
| GET | `/crawl-runs/:id` | Single run with top 3 events. |
| PATCH | `/crawl-runs/:id` | Archive or unarchive. Body: `{ archived: boolean }`. |
| DELETE | `/crawl-runs/:id` | Delete run and all its events. |
| POST | `/crawl-runs/:id/stop` | Signals in-memory stop flag and immediately marks DB status as `stopped`. |
| POST | `/crawl-runs/:id/rerun` | Creates a new run using the same URL list, starts it in background. Returns `202`. |
| GET | `/crawl-runs/:id/logs` | Returns `debugLog` array (from in-memory buffer if run is active, from DB if completed). |
| GET | `/crawl-runs/:id/events` | All events for a run, ordered by score desc. |
| GET | `/crawl-runs/:id/progress` | **SSE endpoint.** Streams `CrawlProgressEvent` objects. Replays historical log on connect via `{ type: "log_replay", entries: [...] }`. Accepts token via `?token=` query param (required for `EventSource`). |

### Events (`/api/events/*`) — auth required

| Method | Path | What it does |
|---|---|---|
| GET | `/events` | Paginated, filtered event list. Query params: `runId`, `tier`, `auctionType`, `status`, `minScore`, `maxScore`, `search` (searches name/org/venue/address/contact/audience), `sortBy`, `sortDir`, `page`, `limit`, `hidePast` (default true). Returns `{ events, total, page, limit }`. |
| GET | `/events/export` | CSV download. Filters: `runId`, `tier`. Returns `text/csv` with Content-Disposition header. |
| GET | `/events/:id` | Single event by ID. |

### Dashboard (`/api/dashboard/*`) — auth required

| Method | Path | What it does |
|---|---|---|
| GET | `/dashboard/summary` | Returns `{ totalLists, totalRuns, totalEvents, tierACount, tierBCount, tierCCount, newEvents, updatedEvents, lastRunAt }`. |
| GET | `/dashboard/top-events` | Top 10 events by score across all runs. |
| GET | `/dashboard/tier-breakdown` | Array of `{ tier, count }` grouped by tier. |

### Admin (`/api/admin/*`) — auth required + admin role

| Method | Path | What it does |
|---|---|---|
| GET | `/admin/settings` | Returns full admin settings object (creates defaults if none exist). |
| PATCH | `/admin/settings` | Partial update of any settings field (keywords, limits, scoring, schedule). |
| GET | `/admin/email-recipients` | List all email recipients. |
| POST | `/admin/email-recipients` | Add recipient. Body: `{ email }`. |
| PATCH | `/admin/email-recipients/:id` | Update `email` or `active` flag. |
| DELETE | `/admin/email-recipients/:id` | Remove recipient. |
| GET | `/admin/domain-blacklist` | List blacklisted domains. |
| POST | `/admin/domain-blacklist` | Add domain. Body: `{ domain }`. |
| DELETE | `/admin/domain-blacklist/:id` | Remove domain. |
| GET | `/admin/users` | List all users (id, name, email, role, activatedAt, createdAt). |
| POST | `/admin/users` | Create user + send activation email. Body: `{ name, email, role? }`. |
| PATCH | `/admin/users/:id` | Update name, email, or role. |
| DELETE | `/admin/users/:id` | Remove user. |
| POST | `/admin/users/:id/resend-invite` | Re-generate activation token and resend email for pending user. |

### Health

| Method | Path | What it does |
|---|---|---|
| GET | `/healthz` | Public. Returns `200 OK`. Auth middleware skips this path. |

---

## 4. Scraping Engine

### Pipeline Overview

```
URL list  →  for each seed URL
              │
              ├─ 1. Check domain blacklist  →  skip if matched
              │
              ├─ 2. Try sitemap.xml  →  extract crawlable URLs
              │     (if sitemap absent, start BFS from seed URL)
              │
              ├─ 3. Priority queue: event-path URLs first
              │     (paths containing: event, gala, auction, fundraiser,
              │      calendar, benefit, banquet, rsvp, donate, tickets, etc.)
              │
              └─ 4. Per page (up to maxPagesPerSite):
                    │
                    ├─ a. Skip static assets (.pdf, .png, .js, .css, /wp-json/, etc.)
                    ├─ b. Skip archive pages (URL or content contains: past, archive,
                    │        previous, recap, gallery, 2020–2024)
                    ├─ c. Fetch page → Firecrawl first, got+cheerio fallback
                    ├─ d. Extract internal links → prioritize event-path links
                    ├─ e. Keyword gate → send to AI only if search keywords hit
                    │     (override keywords bypass avoid-keyword filter)
                    └─ f. AI extraction (gpt-4o-mini) + optional image analysis (gpt-4o)
                          → Score event → store if relevant=true
```

### Page Fetching

**Firecrawl (primary):**
- Uses `fc.scrape(url, { formats: ["markdown", "html", "links"], onlyMainContent: true })`
- Returns clean markdown (used for AI prompt), raw HTML (used for link/image extraction), and same-domain links
- A per-page timeout (`timeoutPerPage` seconds) is enforced via `Promise.race`; on timeout falls back to got

**got + cheerio (fallback):**
- Sends `Mozilla/5.0 (compatible; EventFinderBot/1.0)` User-Agent
- Strips `script`, `style`, `nav`, `header`, `footer`, cookie banners, sidebars
- Prefers `main`, `article`, `[role="main"]`, `.main-content` for text extraction
- Does **not** return links (BFS link extraction uses cheerio on the raw HTML separately)

### Keyword Gate (before AI call)

1. Check if page text contains any **override keyword** (default: `"silent auction"`) → if yes, bypass avoid keywords entirely
2. Check if page text contains any **search keyword** → must hit at least one
3. Check if page text contains any **avoid keyword** → if yes AND no override, skip page

### AI Extraction (`gpt-4o-mini`)

**What is sent:**
- System prompt: detailed instructions on qualifying events, field population rules, disqualification criteria
- User message: `Page URL: <url>\nPage title: <t>\nFirst H1: <h1>\nFirst markdown heading: <h>\n\nPage markdown:\n<first 8000 chars of markdown>`

**What is returned:** JSON object with `relevant: boolean` and all event fields listed in §2 (`events` table)

**Fallback if no AI key:** `basicExtraction()` — regex-only extraction (ticket/table price patterns, `has*Auction` via substring match)

### Image Analysis (`gpt-4o`, optional)

- Enabled via `imageReadingEnabled` admin setting
- Extracts up to 5 images from the page HTML; prioritizes images near auction/gala keywords in alt text or surrounding text
- Skips: logos, icons, avatars, images < 80px, images < 5 KB or > 4 MB
- SSRF guard: only fetches same-domain images; blocks all private/loopback IP ranges
- Each image sent as base64 `detail: "low"` with a specialized system prompt
- Image result is merged into text result using **first-write-wins** (text fields take priority; image fills gaps)
- Image's `relevant=true` can override text's `relevant=false` only if image explicitly classifies as charity fundraiser

### Deduplication

After all pages of a site are crawled, events are deduplicated by `(eventName.lower + eventDate.lower)`. The richer record (more non-null fields) wins.

### Progress Streaming

- An in-memory `progressListeners` map holds SSE response writers keyed by `runId`
- An in-memory `logBuffers` map holds `LogEntry[]` keyed by `runId`
- Log buffer is flushed to `crawl_runs.debug_log` (JSONB) every 5 seconds during a run, and after each URL completes
- On SSE reconnect, the server replays all log entries as a single `{ type: "log_replay", entries }` message
- A `stoppedRuns` Set (in-memory) is checked between each URL; stop is cooperative (finishes current URL)

---

## 5. Scoring Logic

Source: `artifacts/api-server/src/services/scorer.ts`

### Score Calculation (0–100, capped)

```
score = 0

// Auction presence
if hasSilentAuction OR hasLiveAuction:
    score += hasAuction (default: 30)

// Auction type named
if auctionType in ("silent", "live"):
    score += auctionTypeBonus (default: 10)

// Ticket/table price tiers
if ticketPrice >= 500 OR tablePrice >= 5000:
    score += highTicketPrice (default: 30)
elif ticketPrice >= 250 OR tablePrice >= 2500:
    score += midTicketPrice (default: 20)
elif ticketPrice >= 100:
    score += lowTicketPrice (default: 8)

// Formality
if formality in ("black-tie", "gala"):
    score += formalityBonus (default: 15)

// Timing (based on weeks until event date)
weeksAway = (eventDate - now) / 7 days
if weeksAway < 0 OR weeksAway < 2:      score += timingPenalty (default: -20)
elif 6 <= weeksAway <= 12:              score += timingPrime (default: 25)
elif (2 <= weeksAway < 6) OR
     (12 < weeksAway <= 17):            score += timingGood (default: 10)
else:                                   score += 0

// Beneficiary org type
if orgName contains any of:
   "hospital", "foundation", "museum", "symphony", "opera",
   "ballet", "university", "college":
    score += beneficiaryBonus (default: 10)

score = clamp(score, 0, 100)
```

### Default Weights (stored in `admin_settings.scoring_weights`)

| Weight Key | Default |
|---|---|
| `hasAuction` | 30 |
| `auctionTypeBonus` | 10 |
| `highTicketPrice` | 30 |
| `midTicketPrice` | 20 |
| `lowTicketPrice` | 8 |
| `formalityBonus` | 15 |
| `timingPrime` | 25 |
| `timingGood` | 10 |
| `timingPenalty` | -20 |
| `beneficiaryBonus` | 10 |

### Tier Assignment

| Tier | Condition |
|---|---|
| A | score >= `tierThresholds.tierA` (default 70) |
| B | score >= `tierThresholds.tierB` (default 45) |
| C | score < `tierThresholds.tierB` |

### `isPast` Determination

- If `eventDate` is a date-only string (e.g. `"April 30, 2026"` or `"2026-04-30"`), compare against end-of-day (23:59:59) to avoid marking same-day events as past
- If `eventDate` has a time component, compare directly against `new Date()`
- Missing or unparseable date → `isPast = false`

**Note:** All weights and thresholds are configurable through the Admin Settings UI and stored in the database. The scorer also has hardcoded `{ tierA: 70, tierB: 45 }` defaults in `getTier()` that are NOT reading from DB — this is a known issue (see §8).

---

## 6. Frontend Pages

React SPA with Wouter routing. All protected routes redirect to `/login` if no valid JWT in localStorage.

### Public Routes

| Path | Component | Description |
|---|---|---|
| `/login` | `LoginPage` | Email + password form. On success stores JWT, redirects to `/`. |
| `/request-access` | `RequestAccessPage` | Self-registration form for `@gofffinancial.com` emails. |
| `/activate` | `ActivatePage` | Reads `?token=` from URL, shows password-set form. On success logs user in automatically. |

### Protected Routes (require JWT)

All wrapped in `<Layout>` which renders the sidebar navigation.

| Path | Component | Description |
|---|---|---|
| `/` | `Dashboard` | Summary stat cards (lists, runs, events, tier counts). Top 10 scored events table. Active run banner with Stop button. |
| `/lists` | `UrlLists` | Table of all URL lists with URL count and last run date. Create/delete lists. |
| `/lists/:id` | `UrlListDetail` | View/edit URLs in a list. Start a new crawl run from this page. |
| `/runs` | `RunHistory` | Table/card list of all crawl runs with status, page/event counts. Archive, delete, re-run actions. |
| `/runs/:id` | `RunDetail` | Live run view with SSE progress stream, animated activity log, progress bar. Also shows stored log for completed runs. Two tabs: Activity Log + Events Found (polls every 5s during active run). |
| `/results` | `Results` | Combined view: run cards list → click to see events table for that run. CSV export per run. Archive/delete/re-run actions inline. |
| `/automation` | `AutomationPage` | Configure scheduled crawls: enable/disable, frequency (daily/weekly/monthly/custom), day-of-week picker, time, timezone, URL list target. Saves to `admin_settings`. |
| `/admin` | `Admin` | Left-nav settings panel with 6 sections: Scraping Settings, Scoring & Tiers, Domain Blacklist, Email Notifications, Users, My Account. Admin-only route. |

### Key UI Components

- **`event-badges.tsx`** — `TierBadge` (A/B/C color coded), `ScorePill` (0–100 pill), `StatusBadge` (NEW/UPDATED/UNCHANGED), `RunStatusBadge`
- **`AuthContext.tsx`** — JWT stored/loaded from `localStorage["auth_token"]`. Decoded client-side. Expiry checked on load. `setAuthTokenGetter` wires the token into the auto-generated API client.
- **`auth-fetch.ts`** — `authFetch()` wrapper that injects `Authorization: Bearer <token>` header; `sseUrl()` that appends `?token=<jwt>` for SSE endpoints (since `EventSource` can't set headers)
- **`report.ts`** — CSV export helper (client-side, used for `/events/export`)

---

## 7. Automation

### Cron Scheduler

Source: `artifacts/api-server/src/services/scheduler.ts`

- Initialized once on server start via `initScheduler()`
- Uses `node-cron` with a **hardcoded** expression `"0 6 * * 1"` (every Monday 6 AM) and `timezone: "America/Chicago"`
- **Known issue:** The cron expression is hardcoded and does NOT respect `scheduleDays`, `scheduleTime`, or `scheduleTimezone` from the database. The UI lets users configure these fields, but the scheduler ignores them. Only `scheduleEnabled` and `scheduleUrlListId` are respected at runtime.

### Weekly Job Logic

1. Read `admin_settings` — if `scheduleEnabled` is false, exit
2. If `scheduleUrlListId` is set, crawl only that list; otherwise crawl all lists
3. For each list: create a `crawl_run` row (triggeredBy: `"scheduled"`), call `startCrawlRun()`
4. After each run completes, call `sendDigestForRun()`:
   - Query events from this run where `status = "NEW"` or `"UPDATED"` AND `score >= minScoreForEmail`
   - Filter active email recipients
   - Call `sendWeeklyDigest()` with events grouped by status

### Email Service

Source: `artifacts/api-server/src/services/emailService.ts`

- Uses **Replit Connectors SDK** (`@replit/connectors-sdk`) to proxy requests to Resend
- No direct Resend API key needed — authentication is handled by the Replit platform
- FROM address: `Event Finder <noreply@resend.dev>`
- **`sendActivationEmail(to, name, activationUrl)`** — HTML email with activation button, 7-day expiry warning
- **`sendWeeklyDigest(recipients[], summary)`** — HTML digest email. Shows Tier A events first, then Tier B. Includes NEW/UPDATED badges, scores, org names, dates, and direct event page links. Sends one email per recipient (sequential loop).

---

## 8. Known Issues

### Critical

1. **Scheduler ignores DB settings** (`scheduler.ts:18`): The cron expression is hardcoded to `"0 6 * * 1"` (Monday 6 AM Central). The `scheduleDays`, `scheduleTime`, and `scheduleTimezone` fields saved by the UI are stored in the DB but never read by the scheduler. The schedule would need to be dynamically rebuilt (or the server restarted) to pick up changes.

2. **Scoring uses hardcoded tier thresholds** (`scorer.ts:96`): `scoreEvent()` calls `getTier(score, { tierA: 70, tierB: 45 })` with hardcoded defaults, ignoring the `tierThresholds` object that is passed in through `config.tierThresholds`. The `config.tierThresholds` parameter is passed to `crawlRuns.ts` but the inner `getTier()` call in `scorer.ts` uses literals. Events may be assigned wrong tiers if the admin changes tier thresholds in settings.

3. **Event `status` is always `"NEW"`** (`crawlRuns.ts:142`): Every crawled event is inserted with `status: "NEW"`. There is no deduplication logic against previous runs, so `"UPDATED"` and `"UNCHANGED"` statuses are never set. The email digest references `"UPDATED"` events but they won't exist in practice.

### Moderate

4. **`scheduleFrequency` and `scheduleMonthDay` not in DB schema** (`automation.tsx:108`): The UI sends `scheduleFrequency` and `scheduleMonthDay` fields via PATCH, but these columns don't exist in `adminSettingsTable`. The values are silently dropped by the admin route's update logic.

5. **`hidePast` query param coercion bug** (`events.ts:30`): A comment notes that Zod's `coerce.boolean()` treats the string `"false"` as `true`. The route bypasses Zod for this field and reads `req.query.hidePast === "false"` directly. This is a workaround, not a fix — other boolean query params could have the same problem.

6. **No rate limiting or request size limits**: The API has no rate limiting middleware. The `extractEventFromPage` function truncates page text to 8000 characters before sending to OpenAI, but there's no throttling of concurrent AI calls across multiple URLs.

7. **Stop signal is in-memory only** (`crawlRuns.ts:20`): The `stoppedRuns` Set is module-level in-memory state. If the server restarts mid-run, the stop signal is lost. However, the route immediately marks the DB status as `stopped` before checking the in-memory set, so UI will show the correct state after restart.

8. **`xlsx` package imported but unused**: `xlsx` is listed as a production dependency in `package.json` but is never imported or used in any source file.

### Minor

9. **`results/index.tsx` is the "Runs" list, not a separate results view**: `/results` route renders `RunHistory` logic (run cards → click → events table inline). There is a separate `/runs` route with a dedicated `RunHistory` component. Both pages duplicate similar run-card UI with slight differences.

10. **No pagination on the runs list**: `GET /crawl-runs` returns all non-archived runs with no limit/offset. Could be slow with large history.

---

## 9. Environment Variables

All required on the server (`artifacts/api-server`). No env vars are used directly in the frontend (all config comes from the API).

| Variable | Required | Description |
|---|---|---|
| `DATABASE_URL` | **Required** | PostgreSQL connection string. Used by Drizzle ORM. Example: `postgres://user:pass@host:5432/dbname` |
| `JWT_SECRET` | **Required** | Secret for signing/verifying JWTs (HS256). Server throws on startup if missing. |
| `AI_INTEGRATIONS_OPENAI_BASE_URL` | Optional | Base URL for the OpenAI-compatible API. If absent, AI extraction falls back to `basicExtraction()` (regex-only). |
| `AI_INTEGRATIONS_OPENAI_API_KEY` | Optional | API key for OpenAI. Required alongside `BASE_URL` for AI extraction to work. |
| `FIRECRAWL_API_KEY` | Optional | API key for Firecrawl. If absent, crawler uses `got` + `cheerio` fallback for all page fetches. |
| `REPLIT_DOMAINS` | Optional | Used by `getAppBaseUrl()` to construct activation email links. If absent, defaults to `http://localhost:80`. Should be set automatically by Replit. |

> **Note:** There is no `.env.example` file in the repository. The Replit Connectors SDK handles Resend auth automatically through the Replit platform — no `RESEND_API_KEY` env var is needed.
