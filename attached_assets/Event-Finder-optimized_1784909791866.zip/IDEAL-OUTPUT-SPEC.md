# Ideal Output Specification — Event Finder
## Based on Manual Research Workflow (Event Search Houston and Austin 02-03-2025.xlsx)

> This document tells the developer exactly what the automated Event Finder app needs to produce  
> to match how Goff Financial Group previously did this research by hand.  
> All field names, default values, and column ordering come directly from the orange-highlighted  
> zone (columns AE–BH) of the manual spreadsheet — that is the gold standard output.

---

## Background: What the Manual Process Was

A researcher would:
1. Pull a bulk nonprofit list from Guidestar (org name, EIN, address, phone, NTEE code, etc.)
2. Open each org's website manually
3. Decide: **Suitable** or **Not Suitable**
4. For Suitable orgs: fill in ~30 orange-highlighted fields about the fundraising event
5. Paste "Suitable" rows into a **"Ready for Import"** sheet formatted for ACT CRM

The automated app should eliminate steps 2–4 and produce the same 30-field output automatically.

---

## The 30 "Ideal Output" Fields (Orange Zone from Spreadsheet)

These are the exact column headers from the orange-highlighted section of the manual spreadsheet, in order. The developer must ensure the app's export/output produces all of these.

| # | Field Name (exact) | Source | App Field Today | Notes |
|---|---|---|---|---|
| 1 | GCP - Donation Needed By | AI extraction | ❌ Missing | "Yes" / "No" / "Unknown" — infer from page: does it say "donate items", "gift", "in-kind"? |
| 2 | GCP - Online Auction | AI extraction | ❌ Missing (partial) | "Yes" / "No" / "Unknown" — currently `auctionType` enum only; need separate Yes/No flags |
| 3 | GCP - Live Auction | AI extraction | ✅ `hasLiveAuction` | Rename/map; output "Yes" / "No" / "Unknown" |
| 4 | GCP - Silent Auction | AI extraction | ✅ `hasSilentAuction` | Rename/map; output "Yes" / "No" / "Unknown" |
| 5 | GCP - Raffle | AI extraction | ❌ Missing | "Yes" / "No" / "Unknown" — AI should detect raffle language |
| 6 | GCP - Event Web Page | Crawler | ✅ `eventPageUrl` | Direct match |
| 7 | Organization ID | CRM | ❌ Missing | Leave blank — filled manually in ACT CRM after import |
| 8 | GCP - Event Date Sort | AI extraction | ✅ `eventDate` | Needs to be a proper date, not a free-text string |
| 9 | GCP - Beneficiary of Fundraiser | Org name | ✅ `orgName` | Auto-populate from org name |
| 10 | GCP - Event | AI extraction | ✅ `eventName` | Direct match |
| 11 | First Name | AI extraction | ✅ `contactName` (partial) | Split full name into First + Last |
| 12 | Last name | AI extraction | ✅ `contactName` (partial) | Split full name into First + Last |
| 13 | Salutation | AI extraction | ❌ Missing | "Mr." / "Ms." / "Dr." — low priority, usually blank |
| 14 | Title 1 | AI extraction | ❌ Missing | Contact's job title — map from new AI extraction field |
| 15 | Mailing Address 1 | From org data | ✅ `orgName` | **Always set to the Org Name** (not street address) — this is the CRM mailing name line |
| 16 | Mailing Address 2 | From org data | ✅ `orgAddress` | Street address of the org |
| 17 | Mailing City | From org data | ✅ `orgCity` | Direct match |
| 18 | Mailing State | From org data | ❌ Missing | State — needs to be extracted/stored separately |
| 19 | Mailing Zip | From org data | ❌ Missing | Zip code — needs to be extracted/stored separately |
| 20 | Phone - Business | From org data | ✅ `orgPhone` | Direct match |
| 21 | E-mail | AI extraction | ✅ `contactEmail` | Direct match; also try `orgEmail` |
| 22 | GCP - Event Status | Static default | N/A | **Always = "Pending"** — hardcoded default |
| 23 | Primary Group 1 | Static default | N/A | **Always = "2025 Events"** — should be the current year, configurable |
| 24 | Primary Group 2 | Static default | N/A | **Always = "Charity"** — hardcoded default |
| 25 | Company | From org data | ✅ `orgWebsite` | The org's website URL |
| 26 | Web Site | From org data | ✅ `orgWebsite` | Same as Company; duplicate column for CRM compatibility |
| 27 | GCP - Mail By | Manual | ❌ Missing | Usually blank — leave empty |
| 28 | Mailing Title | Manual | ❌ Missing | Usually blank — leave empty |
| 29 | GC - Estate Planning Expiration Date | Manual | ❌ Missing | Usually blank — leave empty |
| 30 | GCP - Items Donated | Manual | ❌ Missing | Usually blank — leave empty; could be populated by AI if donation request language found |

---

## What's Missing in the App vs. the Manual Output

### Fields that need to be ADDED to AI extraction and the database

| Field Needed | What to Extract / How |
|---|---|
| `hasOnlineAuction` (boolean) | AI: detect "online auction", "virtual auction" language |
| `hasRaffle` (boolean) | AI: detect "raffle", "drawing", "50/50" language |
| `hasDonationRequest` (boolean) | AI: detect "donate items", "in-kind donation", "gift certificate" language |
| `contactTitle` (text) | AI: extract the contact person's job title |
| `contactFirstName` (text) | Split from existing `contactName` field OR ask AI to return separately |
| `contactLastName` (text) | Split from existing `contactName` field OR ask AI to return separately |
| `orgState` (text) | AI or org data: state where org is located (usually TX) |
| `orgZip` (text) | AI or org data: zip code of org |

### Fields that need to be RENAMED / MAPPED on export

| App Field | Export As |
|---|---|
| `eventName` | GCP - Event |
| `eventDate` | GCP - Event Date Sort |
| `eventPageUrl` | GCP - Event Web Page |
| `hasSilentAuction` | GCP - Silent Auction (as "Yes"/"No"/"Unknown") |
| `hasLiveAuction` | GCP - Live Auction (as "Yes"/"No"/"Unknown") |
| `orgName` | GCP - Beneficiary of Fundraiser AND Mailing Address 1 |
| `orgAddress` | Mailing Address 2 |
| `orgCity` | Mailing City |
| `orgPhone` | Phone - Business |
| `contactEmail` | E-mail |
| `orgWebsite` | Company AND Web Site |

### Static defaults (same for every row — no AI needed)

| Field | Value |
|---|---|
| GCP - Event Status | `Pending` |
| Primary Group 1 | `[Current Year] Events` (e.g., "2025 Events") — make this configurable in admin settings |
| Primary Group 2 | `Charity` |
| Mailing State | `TX` (current scope is Houston + Austin — make configurable) |

---

## CSV Export Format for "Ready for Import"

The CSV/Excel export from the app should produce **exactly these 30 columns in this order** so rows can be copy-pasted directly into ACT CRM without any reformatting:

```
GCP - Donation Needed By
GCP - Online Auction
GCP - Live Auction
GCP - Silent Auction
GCP - Raffle
(blank column F — CRM requires it)
GCP - Event Web Page
Organization ID
GCP - Event Date Sort
GCP - Beneficiary of Fundraiser
GCP - Event
First Name
Last name
Salutation
Title 1
Mailing Address 1
Mailing Address 2
Mailing City
Mailing State
Mailing Zip
Phone - Business
E-mail
GCP - Event Status
Primary Group 1
Primary Group 2
Web Site
GC - Estate Planning Expiration Date
GCP - Items Donated
Contact
Company
```

> **Note:** Column F is intentionally blank in the manual spreadsheet — preserve it for CRM compatibility.

---

## Boolean Field Output Convention

In the manual spreadsheet, all Yes/No fields use exactly these string values:
- `"Yes"` — confirmed present
- `"No"` — confirmed absent
- `"Unkown"` *(sic — note the typo, match exactly for CRM compatibility)*

The app should output the same strings. When the AI cannot determine, output `"Unkown"` (matching the typo in the original CRM import template).

---

## Date Format Convention

The manual spreadsheet stores `GCP - Event Date Sort` as an Excel serial date number (e.g., `45709`). For a CSV export, output as `MM/DD/YYYY` format (e.g., `3/15/2025`). The CRM import accepts this format.

---

## Sample "Perfect" Output Row

Below is what a fully-populated output row should look like (based on a real Suitable row from the spreadsheet):

| Field | Value |
|---|---|
| GCP - Donation Needed By | Yes |
| GCP - Online Auction | No |
| GCP - Live Auction | No |
| GCP - Silent Auction | Yes |
| GCP - Raffle | No |
| (blank) | |
| GCP - Event Web Page | https://sttheresaschool.cc/2025gala |
| Organization ID | (blank) |
| GCP - Event Date Sort | 3/15/2025 |
| GCP - Beneficiary of Fundraiser | St. Theresa Catholic School |
| GCP - Event | St. Theresa Catholic School Annual Gala |
| First Name | Kathy |
| Last name | McCarty |
| Salutation | Ms. |
| Title 1 | Development Director |
| Mailing Address 1 | St. Theresa Catholic School |
| Mailing Address 2 | 6318 Holy Cross Dr |
| Mailing City | Houston |
| Mailing State | TX |
| Mailing Zip | 77007 |
| Phone - Business | 346-335-1700 |
| E-mail | k.mccarty@sttheresa.cc |
| GCP - Event Status | Pending |
| Primary Group 1 | 2025 Events |
| Primary Group 2 | Charity |
| Web Site | http://www.sttheresaschool.cc |
| GC - Estate Planning Expiration Date | (blank) |
| GCP - Items Donated | (blank) |
| Contact | (blank) |
| Company | http://www.sttheresaschool.cc |

---

## Changes Needed in the App (Developer Task List)

### 1. Database — Add columns to `events` table

```sql
ALTER TABLE events ADD COLUMN has_online_auction BOOLEAN;
ALTER TABLE events ADD COLUMN has_raffle BOOLEAN;
ALTER TABLE events ADD COLUMN has_donation_request BOOLEAN;
ALTER TABLE events ADD COLUMN contact_title TEXT;
ALTER TABLE events ADD COLUMN contact_first_name TEXT;
ALTER TABLE events ADD COLUMN contact_last_name TEXT;
ALTER TABLE events ADD COLUMN org_state TEXT;
ALTER TABLE events ADD COLUMN org_zip TEXT;
```

### 2. AI Extractor — Expand system prompt + JSON schema

Add these fields to the AI extraction prompt (`extractor.ts`):

```
- hasOnlineAuction: true if "online auction" or "virtual auction" explicitly mentioned
- hasRaffle: true if "raffle", "drawing", "50/50 raffle" explicitly mentioned  
- hasDonationRequest: true if page asks for donated items, gift certificates, in-kind donations
- contactTitle: the job title of the primary contact person
- contactFirstName: first name of primary contact (separate from last name)
- contactLastName: last name of primary contact
- orgState: 2-letter state abbreviation for the organization's address
- orgZip: 5-digit zip code for the organization's address
```

Also update the system prompt to split `contactName` into `contactFirstName` + `contactLastName` directly — don't return a combined name field, return the two parts separately.

### 3. Scorer — No changes needed for new fields, but:

Update the existing `auctionType` field logic: keep it as-is for scoring, but the boolean flags (`hasSilentAuction`, `hasLiveAuction`, `hasOnlineAuction`) are what drive the export output — all four must be extracted independently.

### 4. CSV Export — Replace current export with the 30-column CRM format

Update `GET /events/export` in `routes/events.ts`:

- Output exactly the 30 columns listed in the "Ready for Import" section above
- Map all field names to the exact CRM column headers
- Convert boolean `true`/`false`/`null` → `"Yes"` / `"No"` / `"Unkown"` (note the typo — match it)
- Format dates as `M/D/YYYY`
- Hardcode: GCP - Event Status = `"Pending"`, Primary Group 2 = `"Charity"`
- Set Mailing Address 1 = orgName (not the street address — street goes in Mailing Address 2)
- Include a blank column F (empty header, empty values)

Add a new admin setting: **`primaryGroup1Label`** (default: `"2025 Events"`) so the year can be updated without a code deploy.

### 5. Admin Settings — Add `primaryGroup1Label` field

- Default: `"2025 Events"`
- Shown in Admin UI under a new "Export Settings" section
- Used in every CSV export row as the `Primary Group 1` value

### 6. UI — Results page

Add a column picker or "CRM Export" button that exports specifically in the 30-column CRM format (separate from the current all-fields debug CSV export). Label it clearly: **"Export for ACT CRM"**.

---

## What Does NOT Need to Change

The existing scoring logic (tiers A/B/C, 0–100 score, timing penalty, formality bonus etc.) does not need to change — the score is used **internally** to rank events and decide what to show first. The CRM export does not include the score column — the researcher uses the score to decide which events to import, then the exported rows contain only the CRM fields above.

The existing crawling, Firecrawl integration, and domain blacklist all stay the same.

---

## Priority Order for Implementation

1. **High priority** — The 4 new boolean fields: `hasOnlineAuction`, `hasRaffle`, `hasDonationRequest`, and splitting `contactName` into `contactFirstName` + `contactLastName`
2. **High priority** — The new CRM-format CSV export with the correct 30 columns and exact header names
3. **Medium priority** — `orgState`, `orgZip`, `contactTitle` (currently often blank even in manual process)
4. **Low priority** — `primaryGroup1Label` admin setting (can hardcode `"2025 Events"` temporarily)
5. **Low priority** — `Salutation`, `GCP - Mail By`, `Mailing Title`, `GCP - Items Donated` (were almost always blank in the manual process)
