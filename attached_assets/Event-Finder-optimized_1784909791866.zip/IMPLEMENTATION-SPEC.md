# Event Finder — Implementation Spec

> **Purpose:** Single reference document for the Replit AI agent.
> Covers three workstreams that must be applied **in order**:
> 1. Extraction Accuracy (fix skipped pages, image detection, wrong data)
> 2. Speed Optimization (concurrency at every level)
> 3. Enhanced Live Preview & Error-Feedback Loop
>
> **Files you will modify** (and ONLY these files unless stated otherwise):
> - `artifacts/api-server/src/services/crawler.ts`
> - `artifacts/api-server/src/services/extractor.ts`
> - `artifacts/api-server/src/services/scorer.ts` (minor)
> - `artifacts/api-server/src/routes/crawlRuns.ts`
> - `artifacts/event-finder/src/pages/runs/detail.tsx`
>
> **Files you will also modify** (for Workstream 4 only):
> - `lib/db` — Drizzle schema (add columns to `events` and `admin_settings` tables)
> - `artifacts/api-server/src/routes/events.ts` — CRM export endpoint
> - `artifacts/event-finder/src/pages/results/index.tsx` — "Export for ACT CRM" button
> - `artifacts/event-finder/src/pages/admin/index.tsx` — Export Settings section
>
> **Do NOT change:** authentication, frontend routing, or any other files
> unless a change here explicitly requires it.

---

## Table of Contents

1. [Workstream 1 — Extraction Accuracy](#workstream-1--extraction-accuracy)
   - 1A. Fix archive-page false negatives
   - 1B. Fix BFS link prioritization
   - 1C. Two-pass AI extraction
   - 1D. Improve image analysis
   - 1E. Increase text truncation limit
2. [Workstream 2 — Speed Optimization](#workstream-2--speed-optimization)
   - 2A. Concurrent site crawling
   - 2B. Concurrent page fetching within a site
   - 2C. Parallel AI + image extraction
   - 2D. Batch DB inserts
   - 2E. Early termination heuristics
3. [Workstream 3 — Enhanced Live Preview & Error Feedback](#workstream-3--enhanced-live-preview--error-feedback)
   - 3A. Richer SSE progress events
   - 3B. Enhanced run detail page (3-panel layout)
   - 3C. Error log → LLM analysis endpoint
   - 3D. Per-URL retry from error log
4. [Workstream 4 — CRM Export Format (ACT Import-Ready)](#workstream-4--crm-export-format-act-import-ready)
   - 4A. The 31 export columns (exact order)
   - 4B. Database schema additions
   - 4C. AI extractor changes
   - 4D. Boolean output convention ("Unkown" typo)
   - 4E. Date format convention (M/D/YYYY)
   - 4F. CSV export endpoint
   - 4G. Frontend — "Export for ACT CRM" button
   - 4H. Admin Settings — Export configuration
   - 4I. Sample "perfect" export row
   - 4J. Testing checklist for CRM export
5. [Workstream 5 — Output Quality Fixes](#workstream-5--output-quality-fixes-from-real-crawl-results)
   - 5A. Fix contact extraction (stronger AI prompt)
   - 5B. Fix original website extraction
   - 5C. Block vendor/SaaS pages
   - 5D. Fix duplicate events
   - 5E. Add geographic filter
   - 5F. Stricter relevance gate (require charity signals)
   - 5G. Handle event aggregator URLs
   - 5H. Testing checklist for output quality
6. [Testing Checklist](#testing-checklist)
7. [Expected Outcomes](#expected-outcomes)

---

## Workstream 1 — Extraction Accuracy

### 1A. Fix archive-page false negatives

**File:** `crawler.ts` — `isArchivePage()` (lines 89–99) and `ARCHIVE_PATTERNS` (lines 67–70)

**Problem:** The function checks the first 2000 characters of page body text for words
like "past", "gallery", "highlights", and years "2020"–"2024". This incorrectly skips
pages that say things like "Past sponsors include..." or "View our photo gallery" while
describing a CURRENT upcoming event. Charity event pages frequently reference prior years.

**Changes:**

1. Remove ALL year-based patterns (`"2020"`, `"2021"`, `"2022"`, `"2023"`, `"2024"`) from
   `ARCHIVE_PATTERNS` entirely.

2. Rewrite `isArchivePage()` to ONLY check the **URL path** for archive signals. Do NOT
   scan body text. Use path-segment matching (not substring) to avoid false positives:

```typescript
const ARCHIVE_PATH_SEGMENTS = [
  "/past-events", "/archive", "/previous-events", "/recap",
  "/event-gallery", "/past-galas", "/event-history",
];

function isArchivePage(url: string): boolean {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    return ARCHIVE_PATH_SEGMENTS.some((seg) => pathname.includes(seg));
  } catch {
    return false;
  }
}
```

3. Update the call site (line 343) to only pass `url`, not `text || html`:
```typescript
if (isArchivePage(url)) {
  onProgress({ type: "error", pageUrl: url, errorMessage: "Skipped: archive/past URL path" });
  continue;
}
```

---

### 1B. Fix BFS link prioritization

**File:** `crawler.ts` — lines 331–339

**Problem:** Both event-path links and non-event links use `unshift`, which means the
last-discovered non-event link gets crawled before earlier event links.

**Change:** Event-path links → `unshift` (front of queue). Non-event links → `push` (back).

```typescript
for (const link of eventLinks) {
  if (!visited.has(link)) toVisit.unshift(link);  // priority: front
}
for (const link of otherLinks) {
  if (!visited.has(link)) toVisit.push(link);     // low priority: back
}
```

---

### 1C. Two-pass AI extraction

**File:** `extractor.ts` — replace the single OpenAI call (lines 376–394) with two focused calls.

**Why:** A single prompt asking the AI to simultaneously classify relevance, identify the
event name/date, AND extract 20+ detail fields leads to systematic errors:
- Wrong dates (registration deadlines, past event dates, early-bird deadlines)
- Wrong titles (org name used as event name)
- Wrong contacts (general office contact instead of event-specific contact)

Two focused passes with explicit disambiguation rules fix all three.

#### Pass 1 — Classification + Event Identity

Runs on every page that passes the keyword gate. Fast and cheap.

```typescript
const PASS1_SYSTEM_PROMPT = `You are classifying whether a webpage describes a SINGLE upcoming charity fundraising event. Return JSON only.

QUALIFYING events: charity galas, fundraising dinners, silent auctions, live auctions, benefit concerts, golf tournaments for charity, nonprofit fundraisers with ticketed admission or sponsorship.

DISQUALIFY: business conferences, trade shows, community markets, craft fairs, past event recaps, general event calendars listing multiple events, events with no fundraising language, events whose date has clearly passed.

CRITICAL DISAMBIGUATION RULES:

EVENT NAME:
- The event name is the name of the SPECIFIC EVENT (e.g. "Annual Crystal Ball Gala"), NOT the organization name (e.g. "Houston Children's Foundation").
- If the H1 heading is the org name, look for the event name in H2, H3, bold text, or a subheading.
- Event names typically include words like: gala, auction, benefit, fundraiser, tournament, dinner, ball, celebration, luncheon.

EVENT DATE:
- The event date is the day the event TAKES PLACE. It is NOT:
  * A registration deadline ("Register by March 1")
  * An early bird deadline ("Early bird pricing ends Feb 15")
  * A sponsorship deadline ("Sponsor commitments due by...")
  * A past event date ("Last year's gala was held on...")
  * A general website copyright date
- Look for patterns like: "Join us on [DATE]", "Event Date: [DATE]", "[DAY OF WEEK], [MONTH] [DAY], [YEAR]" near the event name or in a details/info section.
- If multiple dates appear, prefer the one closest to event-related context (venue, tickets, RSVP).

Return JSON: {"relevant": boolean, "eventName": string|null, "eventDate": string|null, "reasoning": string}
The "reasoning" field: 1 sentence explaining your classification.`;
```

User message format (same as current):
```
Page URL: {url}
Page title: {title}
First H1: {h1}
First markdown heading: {mdHeading}

Page markdown:
{first 12000 chars}
```

#### Pass 2 — Detail Extraction

Runs ONLY when Pass 1 returns `relevant: true`. Receives the event name and date from
Pass 1 so it doesn't re-derive them (and can't get them wrong).

```typescript
const PASS2_SYSTEM_PROMPT = `You are extracting structured details from a charity fundraising event page.
You already know this page describes the event "{eventName}" on {eventDate}. Extract the remaining details.

CONTACT DISAMBIGUATION — THIS IS CRITICAL:
There are often TWO different contacts on a charity event page:
1. EVENT CONTACT — the person handling tickets, RSVPs, table reservations, or event questions. This is who you want for contactName/contactEmail/contactPhone. Look for: "For tickets contact...", "RSVP to...", "Event questions?", "Event Chair:", "Event Coordinator:".
2. ORGANIZATION CONTACT — the general office phone, info@ email, executive director, webmaster. This is NOT the event contact. Put this in orgPhone/orgEmail instead.

If only one contact is listed and it's ambiguous, put it in BOTH event contact AND org contact fields.

PRICING RULES:
- ticketPrice: per-PERSON or per-TICKET price. "$X per person", "$X/ticket", "$X individual". If multiple tiers, use the LOWEST non-free tier.
- tablePrice: per-TABLE or SPONSORSHIP price. "$X per table", "$X table of 10", "$X sponsorship". If multiple levels, use the LOWEST sponsorship tier.
- Do NOT confuse auction item prices, donation amounts, or raffle ticket prices with event ticket/table prices.

ADDRESS RULES:
- eventVenue: NAME of the venue (e.g. "The Hilton Americas-Houston"), not the street address.
- eventAddress: STREET ADDRESS of the venue (e.g. "1600 Lamar St, Houston, TX 77010").
- orgAddress: the organization's mailing/office address — may differ from the event venue.
- orgCity: the city of the ORGANIZATION, not necessarily the event venue city.

Return ONLY valid JSON with these fields (omit fields you cannot determine):
eventVenue, eventAddress, eventDescription (1-2 sentences), auctionType ("silent"|"live"|"both"|"online"|"none"), hasSilentAuction (boolean), hasLiveAuction (boolean), ticketPrice (number|null), tablePrice (number|null), formality ("black-tie"|"gala"|"cocktail"|"casual"|"unknown"), rsvpLink, contactName, contactEmail, contactPhone, audienceNote, sponsorshipMentioned (boolean), orgName, orgAddress, orgCity, orgPhone, orgEmail, orgWebsite.`;
```

User message for Pass 2:
```
This page describes the event "{eventName}" on {eventDate}. Extract details.

Page URL: {url}

Page markdown:
{first 12000 chars}
```

#### Merging logic

```typescript
// Pass 1 fields (eventName, eventDate) take priority — they were extracted with
// focused disambiguation rules.
// Pass 2 fills in all remaining detail fields.
// Image extraction (see §1D) fills any remaining gaps.
const result: ExtractedEvent = {
  relevant: pass1.relevant,
  eventName: pass1.eventName,
  eventDate: pass1.eventDate,
  ...pass2Result,  // detail fields
};
// Then merge image data using existing mergeExtracted() — first-write-wins
```

---

### 1D. Improve image analysis

**File:** `extractor.ts`

1. **Process more images** (line 231): Change `.slice(0, 3)` to `.slice(0, 5)`.

2. **Higher resolution for priority images** (line 248): Use `detail: "high"` for the
   first 2 images (event-keyword-adjacent priority images). Keep `detail: "low"` for
   images 3–5 to control cost. The cost difference is ~$0.01/image but the accuracy
   improvement for reading text on flyers is dramatic.

```typescript
for (let i = 0; i < imageUrls.slice(0, 5).length; i++) {
  const url = imageUrls[i];
  // ... existing fetchImageAsBase64 ...
  const detailLevel = i < 2 ? "high" : "low";  // high-res for priority images
  // ... use detailLevel in the API call ...
}
```

3. **Parse srcset/data-srcset** (in `extractImageUrls`, line 150): Many modern sites
   lazy-load event flyers via `srcset`. Add:

```typescript
// After checking src, data-src, data-lazy-src:
const srcset = $(el).attr("srcset") || $(el).attr("data-srcset") || "";
if (srcset && !src) {
  // Pick the largest resolution from srcset
  const candidates = srcset.split(",").map(s => s.trim().split(/\s+/));
  const best = candidates.sort((a, b) => {
    const aW = parseInt(a[1] || "0");
    const bW = parseInt(b[1] || "0");
    return bW - aW;
  })[0];
  if (best?.[0]) src = best[0];
}
```

4. **Relax size filter for event-related images** (line 157): If an image has
   event-related alt text, skip the dimension check entirely — a small thumbnail of
   a flyer is still worth analyzing:

```typescript
const alt = ($(el).attr("alt") || "").toLowerCase();
const isEventAlt = ["gala", "auction", "fundraiser", "event", "benefit", "tournament"]
  .some(k => alt.includes(k));

// Skip tiny images UNLESS they have event-related alt text
if (!isEventAlt && ((width > 0 && width < 80) || (height > 0 && height < 80))) return;
```

---

### 1E. Increase text truncation limit

**File:** `extractor.ts` — line 377

Change `pageText.slice(0, 8000)` to `pageText.slice(0, 12000)`.

**Why:** Many charity event pages have contact info, pricing, and event details below
the 8000-char mark (after navigation, hero content, and sponsor logos). 12000 chars costs
~$0.003 more per page with gpt-4o-mini. Apply to both Pass 1 and Pass 2 prompts.

---

## Workstream 2 — Speed Optimization

### 2A. Concurrent site crawling

**File:** `crawlRuns.ts` — replace the sequential `for` loop (line 108)

**Problem:** URLs are processed one at a time. 500 URLs × ~2 min each = ~16 hours.

**Solution:** Process 5 sites simultaneously using a worker-pool pattern.

```typescript
const SITE_CONCURRENCY = 5;

async function processWithConcurrency<T>(
  items: T[],
  concurrency: number,
  fn: (item: T, index: number) => Promise<void>
): Promise<void> {
  let nextIndex = 0;
  async function worker() {
    while (nextIndex < items.length) {
      const i = nextIndex++;
      await fn(items[i], i);
    }
  }
  await Promise.all(
    Array.from({ length: Math.min(concurrency, items.length) }, () => worker())
  );
}
```

Replace the `for (let i = 0; i < urls.length; i++)` loop with:

```typescript
let completedCount = 0;

await processWithConcurrency(urls, SITE_CONCURRENCY, async (url, i) => {
  if (stoppedRuns.has(runId)) return;

  const startEvt: CrawlProgressEvent = {
    type: "url_start", url,
    progress: { done: completedCount, total: urls.length }
  };
  appendLog(toLogEntry(startEvt));
  emitProgress(runId, startEvt);

  try {
    const events = await crawlSite(url, config, (ev) => {
      if (ev.type === "page_crawled") pagesCrawled++;
      if (ev.type === "error") errorCount++;
      appendLog(toLogEntry(ev));
      emitProgress(runId, ev);
    });

    // Batch insert all events for this site at once (see §2D)
    if (events.length > 0) {
      await db.insert(eventsTable).values(
        events.map((event) => ({
          runId,
          score: event.score,
          tier: event.tier,
          status: "NEW" as const,
          eventName: event.eventName,
          eventDate: event.eventDate,
          eventVenue: event.eventVenue,
          eventAddress: event.eventAddress,
          eventDescription: event.eventDescription,
          auctionType: event.auctionType,
          hasSilentAuction: event.hasSilentAuction,
          hasLiveAuction: event.hasLiveAuction,
          ticketPrice: event.ticketPrice?.toString(),
          tablePrice: event.tablePrice?.toString(),
          formality: event.formality,
          rsvpLink: event.rsvpLink,
          contactName: event.contactName,
          contactEmail: event.contactEmail,
          contactPhone: event.contactPhone,
          eventPageUrl: event.eventPageUrl,
          audienceNote: event.audienceNote,
          sponsorshipMentioned: event.sponsorshipMentioned,
          orgName: event.orgName,
          orgAddress: event.orgAddress,
          orgCity: event.orgCity,
          orgPhone: event.orgPhone,
          orgEmail: event.orgEmail,
          orgWebsite: event.orgWebsite,
          isPast: event.isPast,
          errorMessage: event.errorMessage,
        }))
      );
      eventsMatched += events.length;
    }

    completedCount++;
    const doneEvt: CrawlProgressEvent = {
      type: "url_done", url,
      progress: { done: completedCount, total: urls.length }
    };
    appendLog(toLogEntry(doneEvt));
    emitProgress(runId, doneEvt);
  } catch (err) {
    errorCount++;
    completedCount++;
    logger.error({ err, url }, "Crawl site error");
    const errEvt: CrawlProgressEvent = { type: "error", url, errorMessage: String(err) };
    appendLog(toLogEntry(errEvt));
    emitProgress(runId, errEvt);
  }
});
```

**Important:** Remove the per-URL DB flush (lines 180–183 and 192–195). Keep only the
5-second interval flush (line 77–84) — with 5 concurrent sites completing URLs rapidly,
per-URL DB writes would be excessive.

---

### 2B. Concurrent page fetching within a site

**File:** `crawler.ts` — replace the sequential `while` loop (line 312)

```typescript
const PAGE_CONCURRENCY = 3;

while (toVisit.length > 0 && visited.size < config.maxPagesPerSite) {
  // Pull up to PAGE_CONCURRENCY URLs
  const batch: string[] = [];
  while (batch.length < PAGE_CONCURRENCY && toVisit.length > 0) {
    const url = toVisit.shift()!;
    if (visited.has(url) || getDomain(url) !== domain || isStaticAsset(url)) continue;
    visited.add(url);
    batch.push(url);
  }
  if (batch.length === 0) break;

  // Check visited.size limit
  if (visited.size > config.maxPagesPerSite) break;

  const batchResults = await Promise.all(
    batch.map(async (url) => {
      onProgress({ type: "page_crawled", pageUrl: url });

      const result = await fetchPage(url, domain, timeoutMs);
      if (!result) {
        onProgress({ type: "error", pageUrl: url, errorMessage: "Failed to fetch page" });
        return { events: [] as CrawledEvent[], newLinks: [] as string[] };
      }

      const { text, html } = result;

      // Extract links for BFS
      let newLinks: string[] = [];
      if (sitemapUrls.length === 0) {
        const rawLinks = result.links ?? extractInternalLinks(html, url);
        newLinks = rawLinks.filter((l) => !isStaticAsset(l));
      }

      // Archive gate
      if (isArchivePage(url)) {
        onProgress({ type: "error", pageUrl: url, errorMessage: "Skipped: archive/past URL path" });
        return { events: [], newLinks };
      }

      // Keyword gate + AI extraction
      try {
        const extracted = await extractEventFromPage(
          text, url,
          config.searchKeywords, config.avoidKeywords, config.overrideKeywords,
          html, config.imageReadingEnabled
        );

        if (extracted) {
          const { score, tier, isPast } = scoreEvent(
            {
              hasSilentAuction: extracted.hasSilentAuction,
              hasLiveAuction: extracted.hasLiveAuction,
              auctionType: extracted.auctionType,
              ticketPrice: extracted.ticketPrice,
              tablePrice: extracted.tablePrice,
              formality: extracted.formality,
              eventDate: extracted.eventDate,
              orgName: extracted.orgName,
            },
            config.scoringWeights
          );

          const crawledEvent: CrawledEvent = {
            ...extracted,
            eventPageUrl: url,
            score, tier, isPast,
            ticketPrice: extracted.ticketPrice ?? null,
            tablePrice: extracted.tablePrice ?? null,
          };
          onProgress({ type: "event_found", pageUrl: url, eventName: extracted.eventName, score });
          return { events: [crawledEvent], newLinks };
        }
      } catch (err) {
        logger.error({ err, url }, "Extraction error");
      }

      return { events: [] as CrawledEvent[], newLinks: [] as string[] };
    })
  );

  // Collect events
  for (const r of batchResults) {
    events.push(...r.events);
  }

  // Add discovered links: event-path first, others last
  for (const r of batchResults) {
    const eventLinks = r.newLinks.filter(isEventUrl);
    const otherLinks = r.newLinks.filter((l) => !isEventUrl(l));
    for (const link of eventLinks) {
      if (!visited.has(link)) toVisit.unshift(link);
    }
    for (const link of otherLinks) {
      if (!visited.has(link)) toVisit.push(link);
    }
  }
}
```

---

### 2C. Parallel AI + image extraction

**File:** `extractor.ts`

After Pass 1 returns `relevant: true`, run Pass 2 and image extraction **in parallel**:

```typescript
if (pass1Result.relevant === false) return null;

const [pass2Result, imageResult] = await Promise.all([
  runPass2(client, truncatedText, pageUrl, pass1Result.eventName, pass1Result.eventDate, pageMeta),
  (imageReadingEnabled && pageHtml)
    ? extractFromImages(extractImageUrls(pageHtml, pageUrl), client)
    : Promise.resolve({} as Partial<ExtractedEvent>),
]);

// Merge: Pass 1 (name + date) → Pass 2 (details) → Image (gap-fill)
let result: ExtractedEvent = {
  relevant: true,
  eventName: pass1Result.eventName,
  eventDate: pass1Result.eventDate,
  ...pass2Result,
};
result = mergeExtracted(result, imageResult);

// Image relevance override (same logic as current)
if (pass2Result.relevant === false && (imageResult as any).relevant === true) {
  result.relevant = true;
}
```

This cuts per-page AI latency from ~3 sequential calls to ~2 (Pass 1, then Pass 2 + images together).

---

### 2D. Batch DB inserts

**File:** `crawlRuns.ts`

Already shown in §2A above — replace the per-event `db.insert()` loop with a single
`db.insert(eventsTable).values(events.map(...))` call per site. Reduces DB round-trips
from N events to 1 per site.

---

### 2E. Early termination heuristics

**File:** `crawler.ts` — add inside the page-processing loop

```typescript
// Track keyword-gate failures for this site
let consecutiveNoKeywords = 0;
let tierACount = 0;

// Inside the per-page processing, after keyword gate:
if (!extracted) {
  consecutiveNoKeywords++;
} else {
  consecutiveNoKeywords = 0;
  if (extracted.tier === "A") tierACount++;
}

// EARLY EXIT 1: If first 3 pages all fail keyword gate, skip remaining
if (consecutiveNoKeywords >= 3 && visited.size <= 5) {
  onProgress({
    type: "error", url: siteUrl,
    errorMessage: `Early exit: first ${consecutiveNoKeywords} pages had no keyword matches`
  });
  break;
}

// EARLY EXIT 2: Already found 3+ Tier A events — no need to dig deeper
if (tierACount >= 3) {
  onProgress({
    type: "url_done", url: siteUrl,
    errorMessage: `Early exit: found ${tierACount} Tier A events`
  });
  break;
}
```

Also add sitemap truncation at the top of `crawlSite`:

```typescript
if (sitemapUrls.length > 200) {
  const eventUrls = sitemapUrls.filter((u) => !isStaticAsset(u) && isEventUrl(u)).slice(0, 100);
  const otherUrls = sitemapUrls.filter((u) => !isStaticAsset(u) && !isEventUrl(u)).slice(0, 50);
  toVisit.push(...eventUrls, ...otherUrls);
} else {
  // ... existing logic ...
}
```

---

## Workstream 3 — Enhanced Live Preview & Error Feedback

### 3A. Richer SSE progress events

**File:** `crawler.ts` — modify progress callback data

Add timing and metadata to every progress event:

```typescript
// At the start of each page:
const pageStartTime = Date.now();

// In the page_crawled event:
onProgress({
  type: "page_crawled",
  pageUrl: url,
  textLength: text.length,
  keywordsFound: hasSearch || hasOverride,
  durationMs: Date.now() - pageStartTime,
});

// In the event_found event — include full event data:
onProgress({
  type: "event_found",
  pageUrl: url,
  eventName: extracted.eventName,
  score,
  eventData: crawledEvent,  // full object for live preview cards
  durationMs: Date.now() - pageStartTime,
});

// For skipped pages — use a distinct "skipped" type instead of "error":
onProgress({
  type: "skipped",
  pageUrl: url,
  reason: "archive_path",  // or "keyword_gate", "avoid_keyword", "blacklisted"
  durationMs: Date.now() - pageStartTime,
});

// For actual errors — add structured error info:
onProgress({
  type: "error",
  pageUrl: url,
  errorType: "timeout" | "fetch_failed" | "ai_failed" | "unknown",
  errorMessage: String(err),
  durationMs: Date.now() - pageStartTime,
});
```

**File:** `crawlRuns.ts` — update `CrawlProgressEvent` type and `toLogEntry()`

Add the new fields to the `CrawlProgressEvent` interface:

```typescript
export interface CrawlProgressEvent {
  type: "url_start" | "url_done" | "page_crawled" | "event_found"
      | "error" | "skipped" | "complete";
  url?: string;
  pageUrl?: string;
  eventName?: string;
  score?: number;
  errorMessage?: string;
  errorType?: string;
  reason?: string;
  progress?: { done: number; total: number };
  // New fields:
  textLength?: number;
  keywordsFound?: boolean;
  durationMs?: number;
  eventData?: any;  // full CrawledEvent for live preview
}
```

Update `toLogEntry()` to include duration and new types:

```typescript
case "skipped":
  return {
    ts, type: event.type, url: event.pageUrl,
    msg: `Skipped: ${event.pageUrl ?? ""} (${event.reason})`,
    durationMs: event.durationMs,
  };
case "page_crawled":
  return {
    ts, type: event.type, url: event.pageUrl,
    msg: `Crawled: ${event.pageUrl ?? ""} (${event.textLength ?? 0} chars, ${event.durationMs ?? 0}ms)`,
    durationMs: event.durationMs,
  };
```

Also add `durationMs` to the `LogEntry` type.

---

### 3B. Enhanced run detail page (3-panel layout)

**File:** `detail.tsx` — major UI update

Replace the current 2-tab layout (Activity Log | Events Found) with a 3-panel view:

#### Layout

```
┌─────────────────────────────────────────────────────────────────┐
│  Header: run name, status badge, stop button, progress bar     │
│  Stat cards: Pages | Events | Errors | Duration | Speed        │
├────────────────────────┬────────────────────────────────────────┤
│                        │                                        │
│   ACTIVITY LOG         │   LIVE EVENT CARDS                     │
│   (40% width)          │   (60% width, top section)             │
│                        │                                        │
│   - Color-coded        │   Cards animate in as events are       │
│   - Duration per page  │   found. Each card shows:              │
│   - Expandable detail  │   - Score pill + Tier badge            │
│   - Scroll + auto-     │   - Event name (bold)                  │
│     follow             │   - Org, date, venue on one line       │
│                        │   - Auction type badges                │
│                        │   - Contact info if found              │
│                        │   - "Open page" external link          │
│                        │   Sorted by score descending.          │
│                        ├────────────────────────────────────────┤
│                        │                                        │
│                        │   ERROR SUMMARY PANEL                  │
│                        │   (60% width, bottom section)          │
│                        │                                        │
│                        │   Grouped by error type:               │
│                        │   Timeouts: 12 | Fetch: 3 | No KW: 45 │
│                        │   Expandable per-type URL list         │
│                        │   [Analyze Errors with AI] button      │
│                        │                                        │
└────────────────────────┴────────────────────────────────────────┘
```

On mobile (< 768px): stack all 3 panels vertically.

#### Activity Log enhancements

- Show page duration as a badge: `2.3s` in muted text next to each entry
- Color-code the new "skipped" type: gray background, gray left border
- Add a new stat card: **Speed** — `avg X.Xs / page` calculated from durationMs values

#### Live Event Cards

Render directly from SSE `event_found` events (which now include full `eventData`).
No polling needed.

```tsx
function LiveEventCard({ event }: { event: CrawledEvent }) {
  return (
    <div className="border rounded-lg p-3 bg-card shadow-sm animate-in slide-in-from-top-2 fade-in duration-300">
      <div className="flex items-center gap-2 mb-1">
        <ScorePill score={event.score} />
        <TierBadge tier={event.tier} />
        {event.hasSilentAuction && <Badge variant="outline" className="text-xs">Silent Auction</Badge>}
        {event.hasLiveAuction && <Badge variant="outline" className="text-xs">Live Auction</Badge>}
      </div>
      <p className="font-semibold text-sm truncate">{event.eventName || "Unnamed"}</p>
      <p className="text-xs text-muted-foreground truncate">
        {[event.orgName, event.eventDate, event.eventVenue].filter(Boolean).join(" · ")}
      </p>
      {(event.contactEmail || event.contactPhone) && (
        <p className="text-xs text-muted-foreground mt-1">
          {event.contactEmail} {event.contactPhone && `· ${event.contactPhone}`}
        </p>
      )}
      {event.eventPageUrl && (
        <a href={event.eventPageUrl} target="_blank" rel="noopener noreferrer"
           className="text-xs text-primary hover:underline mt-1 inline-flex items-center gap-1">
          Open page <ExternalLink className="w-3 h-3" />
        </a>
      )}
    </div>
  );
}
```

#### Error Summary Panel

```tsx
function ErrorSummary({ entries, runId }: { entries: LogEntry[]; runId: number }) {
  const errors = entries.filter(e => e.type === "error");
  const skipped = entries.filter(e => e.type === "skipped");

  // Group by errorType/reason
  const grouped = new Map<string, LogEntry[]>();
  for (const e of [...errors, ...skipped]) {
    const key = (e as any).errorType || (e as any).reason || e.type;
    if (!grouped.has(key)) grouped.set(key, []);
    grouped.get(key)!.push(e);
  }

  // ... render counts as badges, expandable URL lists per group ...
  // ... "Analyze Errors with AI" button that POSTs to /api/crawl-runs/:id/analyze-errors ...
}
```

---

### 3C. Error log → LLM analysis endpoint

**File:** `crawlRuns.ts` — add new route

```typescript
// POST /crawl-runs/:id/analyze-errors
router.post("/crawl-runs/:id/analyze-errors", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [row] = await db
    .select({ debugLog: crawlRunsTable.debugLog, totalUrls: crawlRunsTable.totalUrls,
              pagesCrawled: crawlRunsTable.pagesCrawled, eventsMatched: crawlRunsTable.eventsMatched,
              errorCount: crawlRunsTable.errorCount })
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!row) { res.status(404).json({ error: "Not found" }); return; }

  const log = (row.debugLog ?? []) as LogEntry[];
  const errors = log.filter(e => e.type === "error" || e.type === "skipped");

  // Group errors by type
  const errorsByType = new Map<string, { count: number; sampleUrls: string[] }>();
  for (const e of errors) {
    const type = (e as any).errorType || (e as any).reason || "unknown";
    if (!errorsByType.has(type)) errorsByType.set(type, { count: 0, sampleUrls: [] });
    const group = errorsByType.get(type)!;
    group.count++;
    if (group.sampleUrls.length < 5 && e.url) group.sampleUrls.push(e.url);
  }

  // Group by domain
  const domainErrors = new Map<string, number>();
  for (const e of errors) {
    if (!e.url) continue;
    try {
      const domain = new URL(e.url).hostname;
      domainErrors.set(domain, (domainErrors.get(domain) || 0) + 1);
    } catch {}
  }

  // Get current settings for context
  const [settings] = await db.select().from(adminSettingsTable).limit(1);

  // Build analysis prompt
  const analysisPrompt = `You are analyzing the error log from a web scraping run that crawls charity/nonprofit websites looking for fundraising events (galas, auctions, golf tournaments, etc).

Run summary:
- Total URLs attempted: ${row.totalUrls}
- Pages crawled: ${row.pagesCrawled}
- Events found: ${row.eventsMatched}
- Errors: ${row.errorCount}

Current configuration:
- Search keywords: ${JSON.stringify(settings?.searchKeywords ?? [])}
- Avoid keywords: ${JSON.stringify(settings?.avoidKeywords ?? [])}
- Override keywords: ${JSON.stringify(settings?.overrideKeywords ?? [])}
- Timeout per page: ${settings?.timeoutPerPage ?? 30}s
- Max pages per site: ${settings?.maxPagesPerSite ?? 30}

Error breakdown by type:
${Array.from(errorsByType.entries()).map(([type, data]) =>
  `- ${type}: ${data.count} errors\n  Sample URLs: ${data.sampleUrls.join(", ")}`
).join("\n")}

Domains with most failures:
${Array.from(domainErrors.entries())
  .sort((a, b) => b[1] - a[1])
  .slice(0, 15)
  .map(([domain, count]) => `- ${domain}: ${count} errors`)
  .join("\n")}

Analyze and return JSON:
{
  "summary": "2-3 sentence overview of crawl health",
  "patterns": [{"pattern": "description", "affectedCount": N, "suggestion": "what to do"}],
  "configSuggestions": [{"setting": "settingName", "currentValue": "X", "suggestedValue": "Y", "reason": "why"}],
  "siteIssues": [{"domain": "example.com", "issue": "blocks scrapers", "workaround": "add to blacklist or skip"}],
  "possibleMissedEvents": [{"url": "https://...", "likelyReason": "event info was in image only"}],
  "overallHealthScore": 0-100
}`;

  // Call OpenAI
  const client = getOpenAIClient();
  if (!client) {
    res.status(503).json({ error: "AI not configured" });
    return;
  }

  const response = await client.chat.completions.create({
    model: "gpt-4o-mini",
    messages: [
      { role: "system", content: "You are a web scraping diagnostics expert. Analyze error logs and provide actionable suggestions. Return only valid JSON." },
      { role: "user", content: analysisPrompt },
    ],
    response_format: { type: "json_object" },
    max_tokens: 2000,
  });

  const analysis = JSON.parse(response.choices[0]?.message?.content || "{}");
  res.json(analysis);
});
```

#### Frontend rendering for analysis results

After the "Analyze Errors with AI" button click, render the response:

```
┌─────────────────────────────────────────────────────┐
│  CRAWL HEALTH: ██████████░░ 78/100                  │
│  "78% of URLs processed successfully. Main issues   │
│   are timeouts on WordPress sites and..."            │
├─────────────────────────────────────────────────────┤
│  PATTERNS                                           │
│  ▸ WordPress sites timing out (12 URLs)             │
│    → Increase timeout to 45s                        │
│  ▸ "wine" avoid keyword blocking galas with wine    │
│    bars (8 URLs)                                    │
│    → Remove "wine" from avoid keywords              │
├─────────────────────────────────────────────────────┤
│  CONFIG SUGGESTIONS                                 │
│  ┌──────────────┬─────────┬──────────┬───────────┐  │
│  │ Setting      │ Current │ Suggest  │ Action    │  │
│  │ timeoutPage  │ 30s     │ 45s      │ [Apply]   │  │
│  │ avoidKeywords│ [wine]  │ remove   │ [Apply]   │  │
│  └──────────────┴─────────┴──────────┴───────────┘  │
├─────────────────────────────────────────────────────┤
│  SITE ISSUES                                        │
│  • scraper-blocking.org — Cloudflare challenge      │
│    → [Add to Blacklist]                             │
├─────────────────────────────────────────────────────┤
│  POSSIBLE MISSED EVENTS                             │
│  • https://example.com/gala2026 — likely image-only │
│    → [Re-crawl]                                     │
└─────────────────────────────────────────────────────┘
```

Each **[Apply]** button sends `PATCH /api/admin/settings` with the suggested value.
Each **[Add to Blacklist]** sends `POST /api/admin/domain-blacklist`.
Each **[Re-crawl]** collects selected URLs for the retry endpoint (§3D).

---

### 3D. Per-URL retry from error log

**File:** `crawlRuns.ts` — add new route

```typescript
// POST /crawl-runs/:id/retry-urls
router.post("/crawl-runs/:id/retry-urls", async (req, res) => {
  const id = Number(req.params.id);
  const { urls } = req.body as { urls: string[] };

  if (!id || !Array.isArray(urls) || urls.length === 0) {
    res.status(400).json({ error: "Invalid id or urls array" });
    return;
  }

  // Get the original run's url_list_id for association
  const [originalRun] = await db
    .select({ urlListId: crawlRunsTable.urlListId })
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!originalRun) { res.status(404).json({ error: "Not found" }); return; }

  // Create a new run with only the retry URLs
  const [newRun] = await db
    .insert(crawlRunsTable)
    .values({
      urlListId: originalRun.urlListId,
      status: "pending",
      triggeredBy: "manual",
      totalUrls: urls.length,
      pagesCrawled: 0,
      eventsMatched: 0,
      errorCount: 0,
      archived: false,
      debugLog: [],
    })
    .returning();

  const [listRow] = await db
    .select({ name: urlListsTable.name })
    .from(urlListsTable)
    .where(eq(urlListsTable.id, originalRun.urlListId));

  // Fire and forget
  startCrawlRun(newRun.id, urls, "manual").catch((err) =>
    logger.error({ err, runId: newRun.id }, "Retry run failed")
  );

  res.status(202).json(serializeRun(newRun, listRow?.name ?? ""));
});
```

---

## Workstream 4 — CRM Export Format (ACT Import-Ready)

This workstream ensures the CSV/Excel export matches the **exact** column layout from
the manual "Ideal Output" spreadsheet used by Goff Financial Group. Every column name,
column order, and value convention must match exactly — the output is pasted directly
into ACT CRM with no reformatting.

### 4A. The 31 export columns (exact order)

Based on the actual `Ideal Output.xlsx` spreadsheet, the export must produce these
columns in exactly this order:

```
 #  Column Header                          Source                  Example Value
──  ─────────────────────────────────────  ──────────────────────  ──────────────────────
 1  GCP - Donation Needed By               AI extraction           "Yes" / "No" / "Unkown"
 2  GCP - Online Auction                   AI extraction           "Yes" / "No" / "Unkown"
 3  GCP - Live Auction                     AI extraction           "Yes" / "No" / "Unkown"
 4  GCP - Silent Auction                   AI extraction           "Yes" / "No" / "Unkown"
 5  GCP - Raffle                           AI extraction           "Yes" / "No" / "Unkown"
 6  GCP - Event Web Page                   Crawler                 "https://example.org/gala"
 7  Organization ID                        Blank (filled in CRM)   ""
 8  GCP - Event Date Sort                  AI extraction           "2/22/2025"
 9  GCP - Beneficiary of Fundraiser        AI / org data           "Kingwood Womens Club"
10  GCP - Event                            AI extraction           "Mardi Gras Ball"
11  First Name                             AI extraction           "Ellie"
12  Last name                              AI extraction           "Csengery"
13  Salutation                             AI extraction           "Ms." / "" (usually blank)
14  Title 1                                AI extraction           "Development Director" / ""
15  Mailing Address 1                      Org data                "KINGWOOD WOMEN'S CLUB"
                                           (ALWAYS the org name,
                                            NOT street address)
16  Mailing Address 2                      Org data                "P.O. Box 5411"
                                           (street/PO box)
17  Mailing City                           Org data                "Kingwood"
18  Mailing State                          Org data / default      "TX"
19  Mailing Zip                            Org data                "77325"
20  Phone - Business                       Org data                "281-703-5224"
21  E-mail                                 AI extraction           "info@example.org"
22  GCP - Event Status                     Static default          "Pending" (always)
23  Primary Group 1                        Admin setting           "2025 Events"
24  Primary Group 2                        Static default          "Charity" (always)
25  Web Site                               Org data                "http://www.example.org"
26  GC - Estate Planning Expiration Date   Blank (manual field)    ""
27  GCP - Items Donated                    Blank (manual field)    ""
28  Contact                                AI extraction           "Ellie Csengery" (full name)
29  Imported into ACT                      Blank (post-import)     ""
30  Company2                               Org data                "KINGWOOD WOMEN'S CLUB"
                                           (full legal entity name,
                                            often UPPERCASE)
31  Primary Group 3                        Admin setting / blank   "Houston B" / "Guidestar" / ""
```

> **IMPORTANT DIFFERENCES from the existing IDEAL-OUTPUT-SPEC.md:**
> - Column 6 is `GCP - Event Web Page` (no blank column F before it)
> - Column 28 `Contact` = full name (same as First Name + Last Name combined)
> - Column 29 `Imported into ACT` = always blank on export (filled post-import)
> - Column 30 `Company2` = the org's full legal entity name (often uppercase)
> - Column 31 `Primary Group 3` = region/source tag — needs new admin setting

---

### 4B. Database schema additions

Add these columns to the `events` table:

```sql
ALTER TABLE events ADD COLUMN has_online_auction BOOLEAN;
ALTER TABLE events ADD COLUMN has_raffle BOOLEAN;
ALTER TABLE events ADD COLUMN has_donation_request BOOLEAN;
ALTER TABLE events ADD COLUMN contact_title TEXT;
ALTER TABLE events ADD COLUMN contact_first_name TEXT;
ALTER TABLE events ADD COLUMN contact_last_name TEXT;
ALTER TABLE events ADD COLUMN org_state TEXT;
ALTER TABLE events ADD COLUMN org_zip TEXT;
```

Add these columns to the `admin_settings` table:

```sql
ALTER TABLE admin_settings ADD COLUMN primary_group_1_label TEXT DEFAULT '2026 Events';
ALTER TABLE admin_settings ADD COLUMN primary_group_3_label TEXT DEFAULT '';
ALTER TABLE admin_settings ADD COLUMN default_mailing_state TEXT DEFAULT 'TX';
```

Update the Drizzle schema file (`lib/db`) to match. Run `drizzle-kit generate` and
`drizzle-kit push` to apply migrations.

---

### 4C. AI extractor changes

**File:** `extractor.ts`

Add these fields to the Pass 2 system prompt's extraction list:

```
- hasOnlineAuction: true if "online auction", "virtual auction", or "bid online" is
  explicitly mentioned. false if not mentioned. null if ambiguous.
- hasRaffle: true if "raffle", "drawing", "50/50", "lucky draw", or "opportunity
  drawing" is explicitly mentioned. false if not mentioned. null if ambiguous.
- hasDonationRequest: true if the page asks for donated items, gift certificates,
  in-kind donations, or auction item contributions. Look for: "donate items",
  "gift certificate", "in-kind", "auction donations", "donate a prize".
  false if not mentioned. null if ambiguous.
- contactTitle: the job title of the event contact person (e.g. "Development Director",
  "Event Chair", "Executive Director"). null if not found.
- contactFirstName: first name of the event contact. Return separately from last name.
- contactLastName: last name of the event contact. Return separately from first name.
- orgState: 2-letter US state abbreviation for the organization's address (e.g. "TX").
- orgZip: 5-digit zip code for the organization's address (e.g. "77325").
```

Update the `ExtractedEvent` interface to include all new fields.

---

### 4D. Boolean output convention

**CRITICAL:** The manual spreadsheet uses these exact string values for all Yes/No fields.
The CRM import template expects them verbatim:

| AI returns       | Export as   |
|------------------|-------------|
| `true`           | `"Yes"`     |
| `false`          | `"No"`      |
| `null`/undefined | `"Unkown"`  |

> Note the typo: `"Unkown"` (not "Unknown"). This matches the original CRM template.
> Do NOT fix the typo — it must match exactly for ACT CRM compatibility.

---

### 4E. Date format convention

The export must format `GCP - Event Date Sort` as `M/D/YYYY` (no leading zeros):
- `"2/22/2025"` not `"02/22/2025"`
- `"3/5/2025"` not `"03/05/2025"`

If the AI returns a date string like `"February 22, 2025"`, convert it to `"2/22/2025"`.
If the date cannot be parsed, leave the field blank (empty string).

---

### 4F. CSV export endpoint

**File:** `artifacts/api-server/src/routes/events.ts`

Replace the current `GET /events/export` with the 31-column CRM format.

```typescript
router.get("/events/export", async (req, res) => {
  const runId = req.query.runId ? Number(req.query.runId) : undefined;
  const tier = req.query.tier as string | undefined;

  // Build query with filters
  let query = db.select().from(eventsTable);
  const conditions = [];
  if (runId) conditions.push(eq(eventsTable.runId, runId));
  if (tier) conditions.push(eq(eventsTable.tier, tier));
  // ... apply conditions ...

  const events = await query.orderBy(sql`${eventsTable.score} desc`);

  // Get admin settings for Primary Group labels and default state
  const [settings] = await db.select().from(adminSettingsTable).limit(1);
  const primaryGroup1 = settings?.primaryGroup1Label ?? "2026 Events";
  const primaryGroup3 = settings?.primaryGroup3Label ?? "";
  const defaultState = settings?.defaultMailingState ?? "TX";

  // Boolean formatter
  const boolToYesNo = (val: boolean | null | undefined): string => {
    if (val === true) return "Yes";
    if (val === false) return "No";
    return "Unkown";  // intentional typo — matches CRM template
  };

  // Date formatter: M/D/YYYY (no leading zeros)
  const formatDate = (dateStr: string | null | undefined): string => {
    if (!dateStr) return "";
    try {
      const d = new Date(dateStr);
      if (isNaN(d.getTime())) return "";
      return `${d.getMonth() + 1}/${d.getDate()}/${d.getFullYear()}`;
    } catch {
      return "";
    }
  };

  // Build CSV rows
  const headers = [
    "GCP - Donation Needed By",
    "GCP - Online Auction",
    "GCP - Live Auction",
    "GCP - Silent Auction",
    "GCP - Raffle",
    "GCP - Event Web Page",
    "Organization ID",
    "GCP - Event Date Sort",
    "GCP - Beneficiary of Fundraiser",
    "GCP - Event",
    "First Name",
    "Last name",        // lowercase 'n' — matches CRM template
    "Salutation",
    "Title 1",
    "Mailing Address 1",
    "Mailing Address 2",
    "Mailing City",
    "Mailing State",
    "Mailing Zip",
    "Phone - Business",
    "E-mail",
    "GCP - Event Status",
    "Primary Group 1",
    "Primary Group 2",
    "Web Site",
    "GC - Estate Planning Expiration Date",
    "GCP - Items Donated",
    "Contact",
    "Imported into ACT",
    "Company2",
    "Primary Group 3",
  ];

  const rows = events.map((e) => [
    boolToYesNo(e.hasDonationRequest),              // GCP - Donation Needed By
    boolToYesNo(e.hasOnlineAuction),                 // GCP - Online Auction
    boolToYesNo(e.hasLiveAuction),                   // GCP - Live Auction
    boolToYesNo(e.hasSilentAuction),                 // GCP - Silent Auction
    boolToYesNo(e.hasRaffle),                        // GCP - Raffle
    e.eventPageUrl ?? "",                            // GCP - Event Web Page
    "",                                              // Organization ID (blank)
    formatDate(e.eventDate),                         // GCP - Event Date Sort
    e.orgName ?? "",                                 // GCP - Beneficiary of Fundraiser
    e.eventName ?? "",                               // GCP - Event
    e.contactFirstName ?? "",                        // First Name
    e.contactLastName ?? "",                         // Last name
    "",                                              // Salutation (usually blank)
    e.contactTitle ?? "",                            // Title 1
    e.orgName ?? "",                                 // Mailing Address 1 (= org name, NOT street)
    e.orgAddress ?? "",                              // Mailing Address 2 (= street address)
    e.orgCity ?? "",                                 // Mailing City
    e.orgState ?? defaultState,                      // Mailing State
    e.orgZip ?? "",                                  // Mailing Zip
    e.orgPhone ?? "",                                // Phone - Business
    e.contactEmail ?? e.orgEmail ?? "",              // E-mail
    "Pending",                                       // GCP - Event Status (always)
    primaryGroup1,                                   // Primary Group 1
    "Charity",                                       // Primary Group 2 (always)
    e.orgWebsite ?? "",                              // Web Site
    "",                                              // GC - Estate Planning Expiration Date (blank)
    "",                                              // GCP - Items Donated (blank)
    [e.contactFirstName, e.contactLastName]          // Contact (full name)
      .filter(Boolean).join(" ") || "",
    "",                                              // Imported into ACT (blank on export)
    (e.orgName ?? "").toUpperCase(),                  // Company2 (legal name, uppercase)
    primaryGroup3,                                   // Primary Group 3
  ]);

  // Generate CSV with proper escaping
  const csvContent = [
    headers.map(escapeCSV).join(","),
    ...rows.map((row) => row.map(escapeCSV).join(",")),
  ].join("\n");

  res.setHeader("Content-Type", "text/csv; charset=utf-8");
  res.setHeader("Content-Disposition",
    `attachment; filename="CRM_Export_${new Date().toISOString().slice(0, 10)}.csv"`);
  res.send(csvContent);
});

function escapeCSV(value: string): string {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}
```

---

### 4G. Frontend — "Export for ACT CRM" button

**File:** `artifacts/event-finder/src/pages/results/index.tsx`

Add a prominent **"Export for ACT CRM"** button alongside the existing CSV export.
This button should:
- Call `GET /api/events/export?runId={id}` (which now returns the 31-column format)
- Label it clearly: "Export for ACT CRM" with a download icon
- Optionally add a tier filter dropdown: "Export Tier A only" / "Export A + B" / "Export all"

---

### 4H. Admin Settings — Export configuration

**File:** `artifacts/event-finder/src/pages/admin/index.tsx`

Add an **"Export Settings"** section in the admin panel with:

| Setting | Field | Default | Description |
|---|---|---|---|
| Primary Group 1 | `primaryGroup1Label` | `"2026 Events"` | Year label for CRM grouping |
| Primary Group 3 | `primaryGroup3Label` | `""` | Region/source tag (e.g. "Houston B") |
| Default State | `defaultMailingState` | `"TX"` | Fallback when org state not extracted |

---

### 4I. Sample "perfect" export row

Based on the real spreadsheet data, here is what a correctly exported row should look like:

```csv
No,No,No,No,No,https://www.n.org/copy-of-mardi-gras-ball,,2/22/2025,Kingwood Womens Club,Mardi Gras Ball,,,,,KINGWOOD WOMEN'S CLUB,"P.O. Box 5411",Kingwood,TX,77325,281-703-5224,,Pending,2025 Events,Charity,http://www.kingwoodwomensclub.org,,,Ellie Csengery,,KINGWOOD WOMEN'S CLUB,
```

And one with "Unkown" values (when AI cannot determine):

```csv
Unkown,Unkown,Unkown,Unkown,Unkown,https://www.inspirationranch.org/copy-of-gala-vip-rsvp,,9/13/2025,Inspiration Ranch,Denim Diamonds Gala,,,,,INSPIRATION RANCH INC,"33029 Wright Road",Magnolia,TX,77355,281-719-9322,,Pending,2025 Events,Charity,http://www.InspirationRanch.org,,,MG Tindall,,INSPIRATION RANCH INC,
```

---

### 4J. Testing checklist for CRM export

- [ ] Export CSV has exactly 31 columns in the correct order
- [ ] Column headers match exactly (including `"Last name"` with lowercase 'n')
- [ ] Boolean fields output `"Yes"` / `"No"` / `"Unkown"` (with the typo)
- [ ] Dates are formatted as `M/D/YYYY` (no leading zeros)
- [ ] `Mailing Address 1` = org name (NOT street address)
- [ ] `Mailing Address 2` = street/PO box address
- [ ] `Company2` = org name in UPPERCASE
- [ ] `Contact` = full name (First + Last combined)
- [ ] `Organization ID`, `Imported into ACT`, `GC - Estate Planning Expiration Date`,
  `GCP - Items Donated` are all blank
- [ ] `GCP - Event Status` = `"Pending"` for every row
- [ ] `Primary Group 1` uses the admin setting value
- [ ] `Primary Group 2` = `"Charity"` for every row
- [ ] `Primary Group 3` uses the admin setting value
- [ ] CSV opens correctly in Excel without encoding issues
- [ ] Rows with commas in org names are properly quoted

---

## Workstream 5 — Output Quality Fixes (from real crawl results)

Based on an actual crawl run output, these are the specific problems observed and
the fixes required. These are **critical** — without them the output is unusable.

### Problems observed in real output

```
PROBLEM 1: No contacts extracted
  Every row has blank First Name, Last Name, Phone, Email.
  The AI is not extracting contact info even when it exists on the page.

PROBLEM 2: No original website
  The "Web Site" column (orgWebsite) is blank for every row.
  Only the event page URL is captured, not the org's main website.

PROBLEM 3: Junk vendor pages passing relevance gate
  LuxGive.com pages (a SaaS vendor selling auction software) appear 8+ times.
  These are marketing pages, NOT charity events. URLs like:
  /why-luxgive, /how-it-works, /partners, /blog, /experience/punta-cana-paradise
  They pass the keyword gate because they mention "gala" and "silent auction"
  in their marketing copy.

PROBLEM 4: Duplicate events
  SoundRise (Mumbai, India) appears 6 identical times — same event, same URL.
  Deduplication is not working.

PROBLEM 5: Non-qualifying events passing relevance gate
  - "Premium Spirits & Cigars Festival" — a commercial tasting event, not charity
  - "3rd Annual Black Gala Award Show" — an awards ceremony, not a fundraiser
  - "SoundRise Sunday at MuSo" — a music event in Mumbai, India
  These are NOT charity fundraisers but the AI classified them as relevant.

PROBLEM 6: Out-of-geography results
  SoundRise is in Mumbai, India. The scope is Houston/Austin/Texas.
  There is no geographic filter.
```

---

### 5A. Fix contact extraction — stronger AI prompt

**File:** `extractor.ts` — Pass 2 system prompt

The current prompt says "contactName, contactEmail, contactPhone: who to contact" but
does not instruct the AI WHERE to look on the page. Add explicit search instructions:

Add this to the Pass 2 system prompt (after the existing contact disambiguation section):

```
CONTACT SEARCH STRATEGY — LOOK IN ALL OF THESE LOCATIONS:
1. FOOTER: Most nonprofit sites put phone and email in the page footer.
   Look for text patterns at the end of the page content.
2. "CONTACT" SECTION: Look for headings like "Contact", "Contact Us",
   "Questions?", "For More Information", "Get In Touch".
3. SIDEBAR/HEADER: Some sites put phone numbers in the header or sidebar.
4. REGISTRATION/RSVP SECTION: Contact info is often near the RSVP or
   ticket purchase section.
5. "ABOUT" SECTION: Organization phone and email are often here.
6. PAGE BOTTOM: Copyright line often has org name, address, and phone.

WHAT TO EXTRACT:
- orgPhone: the organization's main business phone number. Look for patterns
  like (XXX) XXX-XXXX or XXX-XXX-XXXX. This is CRITICAL — almost every
  nonprofit website has a phone number somewhere on the page.
- orgEmail: the organization's general email. Look for info@, contact@,
  office@, or any email address on the page.
- contactEmail: the specific event contact's email if different from org email.
- contactPhone: the specific event contact's phone if different from org phone.
- contactFirstName / contactLastName: if a specific person is named as the
  event contact, extract their name. Check "Event Chair:", "Contact:",
  "Questions? Call [Name]", "For more info contact [Name]".

IMPORTANT: Do NOT return null for orgPhone or orgEmail if a phone number or
email address appears ANYWHERE on the page. Scan the ENTIRE page content
including footer text. If you find a phone number but aren't sure whose it is,
put it in orgPhone. If you find an email but aren't sure, put it in orgEmail.
A phone number or email in orgPhone/orgEmail is ALWAYS better than null.
```

---

### 5B. Fix original website extraction

**File:** `extractor.ts` — Pass 2 system prompt

Add to the extraction fields:

```
- orgWebsite: the organization's MAIN website URL. This is NOT the event page URL
  (that's already captured separately). Look for:
  * The base domain of the current page URL (e.g. if crawling
    https://example.org/events/gala, orgWebsite = "https://example.org")
  * A "Visit our website" or "www.example.org" link
  * The URL in the page footer
  If you cannot find a separate website, use the root domain of the page URL.
```

**File:** `crawler.ts` — after AI extraction, auto-populate orgWebsite from the URL

Add a fallback in `processPage` or equivalent, after extraction:

```typescript
// If AI didn't extract orgWebsite, derive it from the page URL
if (extracted && !extracted.orgWebsite) {
  try {
    const parsed = new URL(pageUrl);
    extracted.orgWebsite = `${parsed.protocol}//${parsed.hostname}`;
  } catch {}
}
```

This guarantees orgWebsite is NEVER blank — worst case it's the root domain of the
crawled URL.

---

### 5C. Block vendor/SaaS pages — domain-level and page-level filters

**File:** `crawler.ts`

**Problem:** LuxGive.com is an auction software vendor. Their marketing pages mention
"gala", "silent auction", "benefit" etc. because they're selling TO charities, not
hosting events. The keyword gate can't distinguish this.

**Fix 1 — Add a default domain blacklist for known vendor/SaaS sites:**

```typescript
const DEFAULT_VENDOR_DOMAINS = [
  "luxgive.com",
  "onecause.com",       // auction platform — event pages are on subdomains
  "bidpal.net",          // auction platform
  "gofundme.com",        // crowdfunding, not events
  "eventbrite.com",      // event platform (not the org itself)
  "allevents.in",        // event aggregator — scrape the ACTUAL org site instead
  "givebutter.com",      // donation platform
  "classy.org",          // donation platform
  "handbid.com",         // auction platform
  "32auctions.com",      // auction platform
  "biddingforgood.com",  // auction platform
  "charitybuzz.com",     // auction platform
  "galabid.com",         // auction platform
  "auctria.com",         // auction platform
  "givesmart.com",       // auction platform
];
```

Check these IN ADDITION to the user's domain blacklist. These are vendor marketing
sites — their event LISTING pages (like allevents.in/houston/some-event) contain
scraped/aggregated data, not the actual org's contact info. The crawler should be
pointed at the ORG's actual website, not aggregator listings.

**Fix 2 — Add a vendor-page detection heuristic to the AI Pass 1 prompt:**

Add to the Pass 1 classification prompt:

```
DISQUALIFY and return relevant=false if the page is:
- A SOFTWARE VENDOR or PLATFORM marketing page (e.g. a company that SELLS auction
  software, event management tools, or fundraising platforms). These pages mention
  "gala", "auction", "fundraiser" etc. because they're marketing to charities,
  but they are NOT describing a specific charity event.
  Signs: "our platform", "our software", "sign up for a demo", "pricing",
  "features", "testimonials", "case studies", "schedule a call",
  "request a quote", product feature lists, SaaS pricing tiers.
- An EVENT AGGREGATOR listing page (like AllEvents.in, Eventbrite, Facebook Events).
  These pages list events but don't have the organization's actual contact info,
  address, or phone number. The data is incomplete and often scraped/stale.
```

---

### 5D. Fix duplicate events

**File:** `crawler.ts` — deduplication function

**Problem:** SoundRise appears 6 times with identical data. The current `deduplicateEvents`
function uses `(eventName + eventDate)` as the key, which should catch this. The issue is
likely that multiple PAGES on the same site produce the same event, and dedup runs per-site
but the same org URL was in the list multiple times, or Firecrawl's /crawl endpoint
returned the same page content from multiple URLs.

**Fix 1 — Add URL-based dedup:**

```typescript
function deduplicateEvents(events: CrawledEvent[]): CrawledEvent[] {
  const keyMap = new Map<string, CrawledEvent>();
  const urlSet = new Set<string>();
  const countFilled = (e: CrawledEvent): number =>
    Object.values(e).filter((v) => v !== null && v !== undefined && v !== "").length;

  for (const event of events) {
    // Dedup by URL first (exact same page)
    const urlKey = (event.eventPageUrl ?? "").toLowerCase().trim();
    if (urlKey && urlSet.has(urlKey)) continue;
    if (urlKey) urlSet.add(urlKey);

    // Then dedup by name+date (same event found on different pages)
    const name = (event.eventName ?? "").toLowerCase().trim();
    const date = (event.eventDate ?? "").toLowerCase().trim();
    const key = name || date ? `${name}|||${date}` : `__no-key-${Math.random()}`;
    const existing = keyMap.get(key);
    if (!existing || countFilled(event) > countFilled(existing)) {
      keyMap.set(key, event);
    }
  }
  return Array.from(keyMap.values());
}
```

**Fix 2 — Cross-run dedup in the DB insert:**

Before inserting events for a run, check if an event with the same `eventPageUrl`
already exists in the same run:

```typescript
// In crawlRuns.ts, before batch insert
const uniqueEvents = deduplicateEvents(events);
```

Make sure `deduplicateEvents` is called on the results from `crawlSite` (it already
is in the current code, but verify it's applied BEFORE the DB insert).

---

### 5E. Add geographic filter

**File:** `extractor.ts` — Pass 1 system prompt + `crawler.ts` post-extraction filter

**Problem:** SoundRise in Mumbai, India appeared in results. The tool's scope is
Houston/Austin/Texas-area events.

**Fix 1 — Add a geographic scope to admin settings:**

Add to `admin_settings` table:
```sql
ALTER TABLE admin_settings ADD COLUMN geographic_scope TEXT DEFAULT 'Texas';
ALTER TABLE admin_settings ADD COLUMN geographic_states TEXT[] DEFAULT ARRAY['TX'];
```

**Fix 2 — Add geography check to Pass 1 prompt:**

```
GEOGRAPHIC SCOPE: This tool searches for events in specific US regions. If the
event is clearly in a different country or a US state outside the configured scope,
return relevant=false. Events with no clear location should still return relevant=true
(we'll filter later).
```

Pass the geographic scope as a variable in the user message:
```
Geographic scope: Events in {settings.geographicScope} ({settings.geographicStates.join(", ")})
```

**Fix 3 — Post-extraction geographic filter in crawler.ts:**

After extraction and before adding to the events array:

```typescript
// Geographic filter: skip events clearly outside scope
if (extracted.orgCity || extracted.eventAddress) {
  const location = `${extracted.orgCity ?? ""} ${extracted.orgState ?? ""} ${extracted.eventAddress ?? ""}`.toLowerCase();
  const scopeStates = config.geographicStates.map(s => s.toLowerCase());

  // Only filter OUT if we have a state AND it's not in scope
  if (extracted.orgState && !scopeStates.includes(extracted.orgState.toLowerCase())) {
    onProgress({
      type: "skipped", pageUrl: url,
      reason: "out_of_geography",
      errorMessage: `Skipped: event in ${extracted.orgState}, outside scope`
    });
    continue; // or return, depending on code structure
  }
}
```

---

### 5F. Stricter relevance gate — require CHARITY signals

**File:** `extractor.ts` — Pass 1 system prompt

**Problem:** "Premium Spirits & Cigars Festival" and "3rd Annual Black Gala Award Show"
passed the relevance gate because they contain keywords like "gala" and "festival".
But they're not CHARITY FUNDRAISERS — one is a commercial tasting, the other is an
awards ceremony.

Add stronger charity qualification criteria to Pass 1:

```
A QUALIFYING event must have CLEAR FUNDRAISING SIGNALS — at least ONE of:
- Explicit mention of "fundraiser", "fundraising", "charity", "nonprofit",
  "501(c)(3)", "tax-deductible", "proceeds benefit", "in support of"
- Sponsorship packages with levels (Gold, Silver, Platinum, etc.)
- Donation language: "donate", "contribute", "give", "support our mission"
- Auction language: "silent auction items", "auction donations", "bid on"
- A named beneficiary organization that is clearly a charity

DISQUALIFY if the event has NONE of these signals, even if it uses words like
"gala", "ball", "benefit", or "tournament" — those words alone are not enough.
A "Whiskey Tasting Gala" is not a charity fundraiser unless it explicitly says
proceeds benefit a nonprofit.
```

---

### 5G. Handle event aggregator URLs (allevents.in, bidpal.net, etc.)

**Problem:** Several results come from `allevents.in` — an event aggregator that scrapes
event data from across the web. These listing pages have incomplete data (no org phone,
no org email, no org address) because the aggregator only captures partial info.

**Two approaches (implement BOTH):**

**Approach 1 — Extract the ACTUAL org website from aggregator pages:**

If the crawled URL is from a known aggregator domain, look for outbound links to the
actual organization's website and capture it in `orgWebsite`. Add to the Pass 2 prompt:

```
If this page is on an event aggregator site (allevents.in, eventbrite.com, etc.),
look for a link to the ACTUAL hosting organization's website. Extract that URL
as orgWebsite. The aggregator page will have incomplete contact info — note this
in eventDescription.
```

**Approach 2 — Flag aggregator results in the output:**

Add a field to the events table:
```sql
ALTER TABLE events ADD COLUMN source_quality TEXT DEFAULT 'direct';
-- Values: 'direct' (org's own site), 'aggregator' (allevents.in etc.), 'platform' (bidpal, onecause)
```

Set `source_quality = 'aggregator'` when the crawled domain is a known aggregator.
Display this in the UI and export so users know which results need manual verification.

---

### 5H. Testing checklist for output quality

- [ ] Contact phone numbers are extracted for sites that have them (check footer, header)
- [ ] Contact emails are extracted (check footer, contact section)
- [ ] orgWebsite is populated for every event (at minimum, root domain of crawled URL)
- [ ] LuxGive and other vendor marketing pages return relevant=false
- [ ] Aggregator sites (allevents.in) are either blacklisted or flagged as low-quality
- [ ] No duplicate events in output (same event name + date, or same URL)
- [ ] Events outside Texas/configured scope are filtered out
- [ ] "Premium Spirits & Cigars Festival" type events (no charity signal) are rejected
- [ ] Events from known platforms (bidpal.net, onecause.com) extract the actual org info

---

## Testing Checklist

### Accuracy (Workstream 1)
- [ ] A page mentioning "past sponsors" is NOT skipped by archive detection
- [ ] A page at `/past-events/` IS skipped
- [ ] Event-path links are crawled before generic links
- [ ] Two-pass extraction returns correct event name (not org name)
- [ ] Two-pass extraction returns correct event date (not registration deadline)
- [ ] Contact fields contain the event contact, not the general office contact
- [ ] Image analysis processes up to 5 images
- [ ] High-res image analysis reads text on flyer images correctly
- [ ] Pages with event info past the 8000-char mark still get correct extraction

### Speed (Workstream 2)
- [ ] 5 sites are crawled concurrently (check log timestamps — multiple url_start before url_done)
- [ ] 3 pages are fetched concurrently within each site
- [ ] Events are batch-inserted (one DB call per site, not per event)
- [ ] Early termination kicks in when first 3 pages have no keywords
- [ ] Early termination kicks in when 3+ Tier A events are found
- [ ] Large sitemaps (200+) are truncated correctly
- [ ] Stop signal still works across concurrent sites
- [ ] No duplicate events are created

### Live Preview (Workstream 3)
- [ ] SSE events include durationMs for pages
- [ ] Live event cards appear immediately when events are found (no 5s polling delay)
- [ ] Error summary groups errors by type with correct counts
- [ ] "Analyze Errors with AI" returns structured analysis
- [ ] [Apply] buttons update admin settings correctly
- [ ] [Add to Blacklist] adds domain correctly
- [ ] Retry endpoint creates a new run with only selected URLs
- [ ] Mobile layout stacks panels vertically
- [ ] Progress bar and stat cards update correctly with concurrent crawling

---

## Expected Outcomes

| Metric | Before | After |
|---|---|---|
| **Crawl speed** (500 URLs) | ~16 hours | ~1.5–2 hours |
| **Event name accuracy** | ~70% (often returns org name) | ~95% (two-pass disambiguation) |
| **Event date accuracy** | ~65% (picks up deadlines, past dates) | ~92% (explicit date rules) |
| **Contact accuracy** | ~50% (general office vs event contact) | ~85% (disambiguation rules) |
| **Image event detection** | ~40% (3 images, low-res) | ~75% (5 images, high-res priority) |
| **False page skips** | ~15% of event pages skipped | ~3% (URL-only archive check) |
| **Cost per 500-URL run** | ~$8 (AI calls) | ~$12 (more images + two-pass) |
| **Error visibility** | Flat text log | Grouped errors + AI analysis + retry |
| **CRM export columns** | Generic CSV (wrong columns) | Exact 31-column ACT CRM format |
| **Boolean format** | true/false | "Yes" / "No" / "Unkown" (CRM-compatible) |
| **Date format** | Free-text string | M/D/YYYY (CRM-compatible) |
| **New extraction fields** | 0 of 8 | 8 of 8 (online auction, raffle, donation request, contact split, org state/zip, contact title) |
| **Contact extraction** | 0% (all blank) | ~80% (footer/header/contact section scanning) |
| **Org website populated** | 0% (all blank) | 100% (fallback to root domain) |
| **Vendor spam results** | ~30% of results are junk | ~0% (vendor domain blacklist + AI filter) |
| **Duplicate events** | Frequent (6x SoundRise) | Zero (URL + name+date dedup) |
| **Out-of-geography results** | Present (Mumbai, India) | Filtered (state-based geographic scope) |
| **False positive events** | ~20% (cigars festival, award shows) | ~5% (charity-signal requirement) |
