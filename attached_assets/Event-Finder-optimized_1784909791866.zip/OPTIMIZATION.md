# Web Scraper Optimization — Summary of Changes

Date: 2026-07-24
Scope: scalability to ~5,000 targets per run, configurable keyword filtering, weekly automated re-scrape with dedupe, external API review.

---

## 1. Scalability

### Concurrency (worker pool)
`startCrawlRun` ([artifacts/api-server/src/routes/crawlRuns.ts](artifacts/api-server/src/routes/crawlRuns.ts)) no longer crawls seed URLs one at a time. A worker pool pulls sites off a shared cursor; pool size is the new **`maxConcurrentSites`** admin setting (default 5). Pages *within* a site are still fetched sequentially — politeness toward each individual site — while throughput comes from crawling many sites in parallel.

Rough capacity math: 5,000 sites ÷ 5 workers × ~30 s/site ≈ 8–9 hours per full run at defaults. Raising `maxConcurrentSites` to 15–20 (and confirming your Firecrawl/OpenAI plan limits) brings that under 3 hours.

### Per-domain rate limiting + backoff/retry
New module [artifacts/api-server/src/services/rateLimiter.ts](artifacts/api-server/src/services/rateLimiter.ts):

- **`politeDelay(domain, ms)`** — serializes requests per hostname and enforces a minimum gap between them (**`perDomainDelayMs`** setting, default 1000 ms). Applied to every page and sitemap fetch in `crawler.ts`.
- **`withRetry(fn, opts)`** — exponential backoff with jitter (1s → 2s → 4s, capped 30s), honors `Retry-After` headers, retries only transient failures (network errors, timeouts, 408/429/5xx). Retry count is the **`maxRetries`** setting (default 3).
- **`reportDomainBackoff`** — a 429/403/5xx from a site imposes a cooldown on the whole domain so parallel work doesn't keep hammering it.
- **`createLimiter(n)`** — dependency-free p-limit; used in `extractor.ts` to cap concurrent OpenAI calls at 4 (override with env `AI_MAX_CONCURRENCY`). The OpenAI client is also now constructed with `maxRetries: 3` (SDK-level backoff on 429s).

### Queueing: pause / resume / monitoring
- New run status **`paused`** plus endpoints **`POST /api/crawl-runs/:id/pause`** and **`POST /api/crawl-runs/:id/resume`**. Pause is cooperative (in-flight sites finish and are saved); resume re-queues only the seed URLs not yet in the run's new `completed_urls` column, and carries counters + activity log forward.
- **Crash recovery:** on server boot, `recoverInterruptedRuns()` marks any run left in `running`/`pending` by a dead process as `paused`, so it is resumable instead of stuck forever.
- Pause/Resume buttons added to the run detail page; `paused` badge added to `RunStatusBadge`.

### Error isolation
Each site is wrapped in its own try/catch inside its worker — a failing site increments `errorCount`, logs, and the pool moves on. A hard failure of the whole run still finalizes it as `failed` with the log preserved.

### Efficient DB writes
Events are now inserted in **batches of 50** (single multi-row `INSERT`) instead of one row at a time, after the dedupe classification (one query per site batch).

### Logging / monitoring
- Runs now track **`newCount` / `updatedCount` / `duplicateCount`** (returned by the runs API and stored on `crawl_runs`).
- Every run finish logs a one-line pino summary: status, pages, events, new/updated/duplicate/error counts.
- Existing SSE progress stream, 5-second debug-log flush, and per-URL DB flush are retained (the per-URL flush now also persists `completed_urls` for resume).

## 2. Keyword include/exclude filtering

This already existed and remains the mechanism — it is DB-backed and editable in **Admin → Scraping Settings** with no code change:

- **`searchKeywords`** (include list) — a page is only sent to AI extraction if it matches at least one.
- **`avoidKeywords`** (exclude list) — a matching page is skipped/discarded.
- **`overrideKeywords`** — bypass the exclude list (e.g. "silent auction" always qualifies).

All three are arrays in `admin_settings`, editable via UI or `PATCH /api/admin/settings`. No changes to the gate logic were needed; it now simply runs under the new concurrency/rate-limit machinery.

## 3. Weekly automation

### What was broken
The scheduler ignored the DB: cron was hardcoded to Monday 06:00 Central, and every event was always inserted as `NEW` (no dedupe), so the "new finds" digest was meaningless.

### What it does now
- **Schedule comes from the database** ([scheduler.ts](artifacts/api-server/src/services/scheduler.ts)): `scheduleDays` + `scheduleTime` + `scheduleTimezone` are compiled into a cron expression at startup, and **saving schedule settings in the Admin UI rebuilds the cron job immediately** (`reloadSchedule()` is called from the settings PATCH route — no restart needed).
- On each run it re-scrapes **every URL list in the database** (or just `scheduleUrlListId` if one is configured).
- **Dedupe** (new [dedupe.ts](artifacts/api-server/src/services/dedupe.ts), applies to *all* runs, manual or scheduled):
  - `dedupe_key` = sha256(normalized event name + date + source domain), falling back to the normalized page URL (tracking params stripped) when no name was extracted. Indexed column on `events`.
  - `content_hash` = sha256 of the significant fields (name, date, venue, prices, contacts, org…).
  - Already exists, unchanged → **skipped** (`duplicateCount`, logged "Skipped duplicate").
  - Exists but hash differs → inserted flagged **`UPDATED`**.
  - Unknown key → inserted flagged **`NEW`** (logged "NEW find").
- **Reporting:** after each scheduled run the existing digest email goes to active recipients — and now actually contains only genuinely NEW/UPDATED events ≥ `minScoreForEmail`. Errors and a per-run summary line are in the pino server logs; per-run counts are visible in the UI run history.

### How the job is triggered
`node-cron` inside the API server process (`initScheduler()` on boot). Requirements: the server must be running at the scheduled time (on Replit use an Always-On deployment/VM). If you ever move to serverless, replace `initScheduler` with an external trigger (Replit Scheduled Deployments, or any cron hitting an endpoint you expose) — all the job logic is in `runWeeklyJob()` and would be reusable as-is.

## 4. External API review

**Firecrawl (primary page fetcher)**
- Limitations: per-page `scrape` costs 1 credit/page; at 5,000 sites × up to 30 pages that is up to 150k credits per full run — the dominant cost. Plan-level rate limits (roughly 100 scrapes/min on Standard) will throttle high concurrency. A hanging scrape was already raced against a timeout with got+cheerio fallback (kept).
- Recommendations: (a) rely on the free `got`+cheerio path for plain static sites and reserve Firecrawl for JS-heavy sites — a cheap heuristic is to try got first and fall back to Firecrawl when the extracted text is suspiciously empty (inverse of today's order; worth an A/B on your real URL list); (b) Firecrawl's `crawl`/batch endpoints amortize better than per-page `scrape` if you keep it as primary; (c) the sitemap-first strategy already avoids many wasted fetches — keep `maxPagesPerSite` at 30 or below for weekly re-checks.

**OpenAI (extraction)**
- Text: `gpt-4o-mini` — appropriate; cheap and sufficient for structured extraction. The keyword gate already prevents most pages from reaching the API.
- Images: uses `gpt-4o` (vision) — **`gpt-4o-mini` also supports vision** at ~1/15th the cost and is usually adequate for reading flyer text; recommend switching the model string in `extractFromImages` after a spot-check on real flyers.
- The weekly run is not latency-sensitive: the **OpenAI Batch API (50% discount)** is the biggest available cost lever if AI spend becomes material. Requires restructuring extraction into a two-phase (collect pages → batch extract → store), so noted as a future option rather than done now.
- Note: the app talks to OpenAI through Replit's AI-integrations proxy (`AI_INTEGRATIONS_OPENAI_BASE_URL`); model availability/pricing follows that gateway.

**Resend (email via Replit Connectors)** — fine at this volume; digest sends one email per recipient sequentially, acceptable for an internal list.

**Also fixed while in there:** `scoreEvent` was ignoring the admin-configured tier thresholds (hardcoded `{tierA: 70, tierB: 45}`); it now receives `tierThresholds` from settings.

## 5. New configuration reference

| Setting (admin_settings) | Default | Where to change | Effect |
|---|---|---|---|
| `maxConcurrentSites` | 5 | Admin UI → Scraping Settings → Performance, or PATCH `/api/admin/settings` | Parallel site crawls per run |
| `perDomainDelayMs` | 1000 | same | Min gap between requests to one domain |
| `maxRetries` | 3 | same | Fetch retries with exponential backoff |
| env `AI_MAX_CONCURRENCY` | 4 | server env | Cap on concurrent OpenAI calls |

New/changed API surface: `POST /crawl-runs/:id/pause`, `POST /crawl-runs/:id/resume`; run objects now include `newCount`, `updatedCount`, `duplicateCount`, and may have status `paused`.

## 6. Deployment steps (run on Replit — this machine has no Node)

1. `pnpm install` (no new dependencies were added, but ensure lockfile state)
2. **`pnpm --filter @workspace/db run push`** — applies new columns: `events.dedupe_key` (+index), `events.content_hash`, `crawl_runs.new_count/updated_count/duplicate_count/completed_urls`, `admin_settings.max_concurrent_sites/per_domain_delay_ms/max_retries`. All nullable-or-defaulted; no data migration needed. Pre-existing events have no `dedupe_key`, so the first re-scrape of an old site reports its events as NEW once; dedupe is exact from then on.
3. `pnpm --filter @workspace/api-spec run codegen` — regenerate hooks/Zod from the updated `openapi.yaml` (the checked-in generated files were hand-patched to match, so this should produce no surprises).
4. `pnpm run typecheck && pnpm run build`
5. Restart the server; check the boot log for "Scheduler initialized from database settings" and (if applicable) "Marked interrupted runs as paused".
