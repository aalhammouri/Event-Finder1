import app from "./app";
import { logger } from "./lib/logger";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

app.listen(port, (err) => {
  if (err) {
    logger.error({ err }, "Error listening on port");
    process.exit(1);
  }

  logger.info({ port }, "Server listening");

  // Mark runs interrupted by a previous process as paused (resumable),
  // then initialize the scheduler from database settings.
  import("./routes/crawlRuns").then(({ recoverInterruptedRuns }) =>
    recoverInterruptedRuns()
  ).catch((err) => {
    logger.error({ err }, "Failed to recover interrupted runs");
  });

  import("./services/scheduler").then(({ initScheduler }) =>
    initScheduler()
  ).catch((err) => {
    logger.error({ err }, "Failed to initialize scheduler");
  });
});
