import { Router } from "express";
import { db } from "@workspace/db";
import {
  adminSettingsTable,
  emailRecipientsTable,
  domainBlacklistTable,
  usersTable,
} from "@workspace/db";
import { eq } from "drizzle-orm";
import { z } from "zod";
import {
  UpdateAdminSettingsBody,
  CreateEmailRecipientBody,
  UpdateEmailRecipientParams,
  UpdateEmailRecipientBody,
  DeleteEmailRecipientParams,
  AddDomainBlacklistBody,
  DeleteDomainBlacklistParams,
} from "@workspace/api-zod";
import { generateActivationToken, activationTokenExpiresAt, getAppBaseUrl } from "../utils/auth";
import { sendActivationEmail } from "../services/emailService";
import { reloadSchedule } from "../services/scheduler";
import { requireAdmin } from "../middleware/auth";

const router = Router();

// All routes in this router require admin role
router.use(requireAdmin);

async function getOrCreateSettings() {
  const existing = await db.select().from(adminSettingsTable).limit(1);
  if (existing.length > 0) return existing[0];
  const [created] = await db.insert(adminSettingsTable).values({}).returning();
  return created;
}

function serializeSettings(s: typeof adminSettingsTable.$inferSelect) {
  return {
    searchKeywords: s.searchKeywords,
    avoidKeywords: s.avoidKeywords,
    overrideKeywords: s.overrideKeywords,
    maxPagesPerSite: s.maxPagesPerSite,
    timeoutPerPage: s.timeoutPerPage,
    maxConcurrentSites: s.maxConcurrentSites,
    perDomainDelayMs: s.perDomainDelayMs,
    maxRetries: s.maxRetries,
    imageReadingEnabled: s.imageReadingEnabled,
    scoringWeights: s.scoringWeights,
    tierThresholds: s.tierThresholds,
    minScoreForEmail: s.minScoreForEmail,
    scheduleEnabled: s.scheduleEnabled,
    scheduleDays: s.scheduleDays,
    scheduleTime: s.scheduleTime,
    scheduleTimezone: s.scheduleTimezone,
    scheduleUrlListId: s.scheduleUrlListId ?? null,
  };
}

// GET /admin/settings
router.get("/admin/settings", async (_req, res) => {
  const settings = await getOrCreateSettings();
  res.json(serializeSettings(settings));
});

// PATCH /admin/settings
router.patch("/admin/settings", async (req, res) => {
  const ScheduleFields = z.object({
    scheduleEnabled: z.boolean().optional(),
    scheduleDays: z.array(z.string()).optional(),
    scheduleTime: z.string().optional(),
    scheduleTimezone: z.string().optional(),
    scheduleUrlListId: z.number().int().nullable().optional(),
  });

  // Crawl performance/politeness settings (not yet in the generated OpenAPI body)
  const PerformanceFields = z.object({
    maxConcurrentSites: z.number().int().min(1).max(50).optional(),
    perDomainDelayMs: z.number().int().min(0).max(60_000).optional(),
    maxRetries: z.number().int().min(0).max(10).optional(),
  });

  const parsed = UpdateAdminSettingsBody.safeParse(req.body);
  const scheduleParsed = ScheduleFields.safeParse(req.body);
  const perfParsed = PerformanceFields.safeParse(req.body);

  if (!parsed.success && !scheduleParsed.success && !perfParsed.success) {
    res.status(400).json({ error: "Invalid input" });
    return;
  }

  const existing = await getOrCreateSettings();
  const update: Partial<typeof adminSettingsTable.$inferInsert> = {};

  const data = parsed.data as any ?? {};
  if (data.searchKeywords !== undefined) update.searchKeywords = data.searchKeywords;
  if (data.avoidKeywords !== undefined) update.avoidKeywords = data.avoidKeywords;
  if (data.overrideKeywords !== undefined) update.overrideKeywords = data.overrideKeywords;
  if (data.maxPagesPerSite !== undefined) update.maxPagesPerSite = data.maxPagesPerSite;
  if (data.timeoutPerPage !== undefined) update.timeoutPerPage = data.timeoutPerPage;
  if (data.imageReadingEnabled !== undefined) update.imageReadingEnabled = data.imageReadingEnabled;
  if (data.scoringWeights !== undefined) update.scoringWeights = data.scoringWeights;
  if (data.tierThresholds !== undefined) update.tierThresholds = data.tierThresholds;
  if (data.minScoreForEmail !== undefined) update.minScoreForEmail = data.minScoreForEmail;

  const sched = scheduleParsed.data ?? {};
  if (sched.scheduleEnabled !== undefined) update.scheduleEnabled = sched.scheduleEnabled;
  if (sched.scheduleDays !== undefined) update.scheduleDays = sched.scheduleDays;
  if (sched.scheduleTime !== undefined) update.scheduleTime = sched.scheduleTime;
  if (sched.scheduleTimezone !== undefined) update.scheduleTimezone = sched.scheduleTimezone;
  if (sched.scheduleUrlListId !== undefined) update.scheduleUrlListId = sched.scheduleUrlListId;

  const perf = perfParsed.data ?? {};
  if (perf.maxConcurrentSites !== undefined) update.maxConcurrentSites = perf.maxConcurrentSites;
  if (perf.perDomainDelayMs !== undefined) update.perDomainDelayMs = perf.perDomainDelayMs;
  if (perf.maxRetries !== undefined) update.maxRetries = perf.maxRetries;

  const [updated] = await db
    .update(adminSettingsTable)
    .set(update)
    .where(eq(adminSettingsTable.id, existing.id))
    .returning();

  // If any schedule field changed, rebuild the cron job so the new schedule
  // takes effect immediately (no server restart needed).
  const scheduleChanged = ["scheduleEnabled", "scheduleDays", "scheduleTime", "scheduleTimezone"]
    .some((k) => k in update);
  if (scheduleChanged) {
    reloadSchedule().catch((err) => req.log.error({ err }, "Failed to reload schedule after settings update"));
  }

  res.json(serializeSettings(updated));
});

// ── Email Recipients ──────────────────────────────────────────────────────────

router.get("/admin/email-recipients", async (_req, res) => {
  const rows = await db.select().from(emailRecipientsTable);
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/admin/email-recipients", async (req, res) => {
  const parsed = CreateEmailRecipientBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const [row] = await db.insert(emailRecipientsTable).values({ email: parsed.data.email }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.patch("/admin/email-recipients/:id", async (req, res) => {
  const idParsed = UpdateEmailRecipientParams.safeParse({ id: Number(req.params.id) });
  if (!idParsed.success) { res.status(400).json({ error: "Invalid id" }); return; }
  const bodyParsed = UpdateEmailRecipientBody.safeParse(req.body);
  if (!bodyParsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const update: Partial<typeof emailRecipientsTable.$inferInsert> = {};
  if ((bodyParsed.data as any).email !== undefined) update.email = (bodyParsed.data as any).email;
  if ((bodyParsed.data as any).active !== undefined) update.active = (bodyParsed.data as any).active;
  const [updated] = await db.update(emailRecipientsTable).set(update).where(eq(emailRecipientsTable.id, idParsed.data.id)).returning();
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json({ ...updated, createdAt: updated.createdAt.toISOString() });
});

router.delete("/admin/email-recipients/:id", async (req, res) => {
  const parsed = DeleteEmailRecipientParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(emailRecipientsTable).where(eq(emailRecipientsTable.id, parsed.data.id));
  res.status(204).send();
});

// ── Domain Blacklist ──────────────────────────────────────────────────────────

router.get("/admin/domain-blacklist", async (_req, res) => {
  const rows = await db.select().from(domainBlacklistTable);
  res.json(rows.map((r) => ({ ...r, createdAt: r.createdAt.toISOString() })));
});

router.post("/admin/domain-blacklist", async (req, res) => {
  const parsed = AddDomainBlacklistBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const [row] = await db.insert(domainBlacklistTable).values({ domain: parsed.data.domain }).returning();
  res.status(201).json({ ...row, createdAt: row.createdAt.toISOString() });
});

router.delete("/admin/domain-blacklist/:id", async (req, res) => {
  const parsed = DeleteDomainBlacklistParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(domainBlacklistTable).where(eq(domainBlacklistTable.id, parsed.data.id));
  res.status(204).send();
});

// ── Users ─────────────────────────────────────────────────────────────────────

const CreateUserBody = z.object({
  name: z.string().min(1),
  email: z.string().email(),
  role: z.enum(["admin", "viewer"]).default("viewer"),
});

const UpdateUserBody = z.object({
  name: z.string().min(1).optional(),
  email: z.string().email().optional(),
  role: z.enum(["admin", "viewer"]).optional(),
});

function serializeUser(u: typeof usersTable.$inferSelect) {
  return {
    id: u.id,
    name: u.name,
    email: u.email,
    role: u.role,
    activatedAt: u.activatedAt ? u.activatedAt.toISOString() : null,
    createdAt: u.createdAt.toISOString(),
  };
}

router.get("/admin/users", async (_req, res) => {
  const rows = await db.select().from(usersTable).orderBy(usersTable.createdAt);
  res.json(rows.map(serializeUser));
});

router.post("/admin/users", async (req, res) => {
  const parsed = CreateUserBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }

  try {
    const token = generateActivationToken();
    const expiresAt = activationTokenExpiresAt();

    const [row] = await db
      .insert(usersTable)
      .values({ ...parsed.data, activationToken: token, activationTokenExpiresAt: expiresAt })
      .returning();

    const activationUrl = `${getAppBaseUrl()}/activate?token=${token}`;

    // Send activation email non-blocking
    sendActivationEmail(row.email, row.name, activationUrl).catch((err) => {
      req.log.error({ err }, "Failed to send activation email after user creation");
    });

    res.status(201).json(serializeUser(row));
  } catch {
    res.status(409).json({ error: "Email already exists" });
  }
});

router.patch("/admin/users/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }
  const parsed = UpdateUserBody.safeParse(req.body);
  if (!parsed.success) { res.status(400).json({ error: "Invalid input" }); return; }
  const [updated] = await db.update(usersTable).set(parsed.data).where(eq(usersTable.id, id)).returning();
  if (!updated) { res.status(404).json({ error: "Not found" }); return; }
  res.json(serializeUser(updated));
});

router.delete("/admin/users/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }
  await db.delete(usersTable).where(eq(usersTable.id, id));
  res.status(204).send();
});

// POST /admin/users/:id/resend-invite
router.post("/admin/users/:id/resend-invite", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id)).limit(1);
  if (!user) { res.status(404).json({ error: "User not found" }); return; }
  if (user.activatedAt) { res.status(400).json({ error: "User is already activated" }); return; }

  const token = generateActivationToken();
  const expiresAt = activationTokenExpiresAt();
  const activationUrl = `${getAppBaseUrl()}/activate?token=${token}`;

  await db
    .update(usersTable)
    .set({ activationToken: token, activationTokenExpiresAt: expiresAt })
    .where(eq(usersTable.id, id));

  sendActivationEmail(user.email, user.name, activationUrl).catch((err) => {
    req.log.error({ err }, "Failed to resend activation email");
  });

  res.json({ message: "Invitation resent" });
});

export default router;
