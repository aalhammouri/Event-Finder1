import { Router } from "express";
import { db } from "@workspace/db";
import {
  crawlRunsTable,
  eventsTable,
  urlListsTable,
  urlListItemsTable,
  adminSettingsTable,
  domainBlacklistTable,
} from "@workspace/db";
import { eq, sql, and } from "drizzle-orm";
import { GetCrawlRunParams, GetCrawlRunsQueryParams } from "@workspace/api-zod";
import { crawlSite } from "../services/crawler";
import type { CrawlProgressEvent } from "../services/crawler";
import { classifyEvents } from "../services/dedupe";
import type { ClassifiedEvent } from "../services/dedupe";
import { logger } from "../lib/logger";

const router = Router();

// SSE progress map: runId -> set of response writers
const progressListeners = new Map<number, Set<(event: CrawlProgressEvent) => void>>();

// In-memory log buffer: runId -> log entries
type LogEntry = { ts: string; type: string; url?: string; msg: string; score?: number };
const logBuffers = new Map<number, LogEntry[]>();

// Stop signal: runIds that have been asked to stop
const stoppedRuns = new Set<number>();

// Pause signal: runIds that have been asked to pause (resumable later)
const pausedRuns = new Set<number>();

export function emitProgress(runId: number, event: CrawlProgressEvent): void {
  const listeners = progressListeners.get(runId);
  if (listeners) {
    for (const fn of listeners) fn(event);
  }
}

function toLogEntry(event: CrawlProgressEvent): LogEntry {
  const ts = new Date().toISOString();
  switch (event.type) {
    case "url_start":
      return { ts, type: event.type, url: event.url, msg: event.url ? `Starting crawl of ${event.url}` : "Crawl run started" };
    case "page_crawled":
      return { ts, type: event.type, url: event.pageUrl, msg: `Crawled page: ${event.pageUrl ?? ""}` };
    case "event_found":
      return { ts, type: event.type, url: event.pageUrl, msg: `Found event: "${event.eventName ?? "Unknown"}"`, score: event.score };
    case "error":
      return { ts, type: event.type, url: event.url, msg: `Error on ${event.url ?? "unknown"}: ${event.errorMessage ?? ""}` };
    case "url_done":
      return { ts, type: event.type, url: event.url, msg: `Finished: ${event.url}` };
    case "complete":
      return { ts, type: event.type, msg: "Crawl run complete" };
    default:
      return { ts, type: event.type, msg: JSON.stringify(event) };
  }
}

const FLUSH_INTERVAL_MS = 5_000; // persist log buffer to DB every 5 seconds mid-run

// Insert events in chunks instead of row-by-row
const INSERT_BATCH_SIZE = 50;

function toInsertRow(runId: number, classified: ClassifiedEvent) {
  const { event, dedupeKey, contentHash, verdict } = classified;
  return {
    runId,
    score: event.score,
    tier: event.tier,
    status: (verdict === "UPDATED" ? "UPDATED" : "NEW") as "NEW" | "UPDATED",
    eventName: event.eventName,
    eventDate: event.eventDate,
    eventVenue: event.eventVenue,
    eventAddress: event.eventAddress,
    eventDescription: event.eventDescription,
    auctionType: event.auctionType,
    hasSilentAuction: event.hasSilentAuction,
    hasLiveAuction: event.hasLiveAuction,
    ticketPrice: event.ticketPrice?.toString(),
    tablePrice: event.tablePrice?.toString(),
    formality: event.formality,
    rsvpLink: event.rsvpLink,
    contactName: event.contactName,
    contactEmail: event.contactEmail,
    contactPhone: event.contactPhone,
    eventPageUrl: event.eventPageUrl,
    audienceNote: event.audienceNote,
    sponsorshipMentioned: event.sponsorshipMentioned,
    orgName: event.orgName,
    orgAddress: event.orgAddress,
    orgCity: event.orgCity,
    orgPhone: event.orgPhone,
    orgEmail: event.orgEmail,
    orgWebsite: event.orgWebsite,
    isPast: event.isPast,
    errorMessage: event.errorMessage,
    dedupeKey,
    contentHash,
  };
}

/**
 * Marks runs left in "running"/"pending" by a previous process (crash/restart)
 * as "paused" so they can be resumed instead of appearing stuck forever.
 * Called once on server boot.
 */
export async function recoverInterruptedRuns(): Promise<void> {
  const recovered = await db
    .update(crawlRunsTable)
    .set({ status: "paused" })
    .where(sql`${crawlRunsTable.status} in ('running', 'pending')`)
    .returning({ id: crawlRunsTable.id });
  if (recovered.length > 0) {
    logger.warn({ runIds: recovered.map((r) => r.id) }, "Marked interrupted runs as paused (resumable)");
  }
}

export async function startCrawlRun(
  runId: number,
  urls: string[],
  triggeredBy: "manual" | "scheduled",
  opts: { resume?: boolean } = {}
): Promise<void> {
  stoppedRuns.delete(runId);
  pausedRuns.delete(runId);

  // Counters declared here so the periodic flush interval can read them.
  let pagesCrawled = 0;
  let eventsMatched = 0;
  let errorCount = 0;
  let newCount = 0;
  let updatedCount = 0;
  let duplicateCount = 0;
  const completedUrls: string[] = [];

  if (opts.resume) {
    // Carry prior progress forward so counters and the activity log continue
    // where the paused run left off.
    const [prior] = await db.select().from(crawlRunsTable).where(eq(crawlRunsTable.id, runId));
    if (prior) {
      pagesCrawled = prior.pagesCrawled;
      eventsMatched = prior.eventsMatched;
      errorCount = prior.errorCount;
      newCount = prior.newCount;
      updatedCount = prior.updatedCount;
      duplicateCount = prior.duplicateCount;
      completedUrls.push(...((prior.completedUrls as string[]) ?? []));
      logBuffers.set(runId, [...((prior.debugLog as LogEntry[]) ?? [])]);
    } else {
      logBuffers.set(runId, []);
    }
  } else {
    logBuffers.set(runId, []);
  }

  const doneOffset = completedUrls.length;
  const total = doneOffset + urls.length;
  let done = doneOffset;

  const appendLog = (entry: LogEntry) => {
    logBuffers.get(runId)?.push(entry);
  };

  const flushToDb = () =>
    db
      .update(crawlRunsTable)
      .set({
        pagesCrawled, eventsMatched, errorCount,
        newCount, updatedCount, duplicateCount,
        completedUrls, debugLog: logBuffers.get(runId) ?? [],
      })
      .where(eq(crawlRunsTable.id, runId));

  // Periodically flush the in-memory log buffer to DB so a server restart
  // mid-run doesn't lose progress. The flush is fire-and-forget; errors are
  // logged but do not abort the run.
  const flushTimer = setInterval(() => {
    flushToDb().catch((err) => logger.warn({ err, runId }, "Periodic log flush failed"));
  }, FLUSH_INTERVAL_MS);

  const finalize = async (status: "completed" | "stopped" | "paused" | "failed") => {
    clearInterval(flushTimer);
    const finalLog = logBuffers.get(runId) ?? [];
    await db
      .update(crawlRunsTable)
      .set({
        status,
        completedAt: status === "paused" ? null : new Date(),
        pagesCrawled, eventsMatched, errorCount,
        newCount, updatedCount, duplicateCount,
        completedUrls, debugLog: finalLog,
      })
      .where(eq(crawlRunsTable.id, runId));
    progressListeners.delete(runId);
    logBuffers.delete(runId);
    stoppedRuns.delete(runId);
    pausedRuns.delete(runId);
    logger.info(
      { runId, triggeredBy, status, pagesCrawled, eventsMatched, newCount, updatedCount, duplicateCount, errorCount },
      "Crawl run finished"
    );
  };

  try {
    await db.update(crawlRunsTable).set({ status: "running" }).where(eq(crawlRunsTable.id, runId));

    const startEvt: CrawlProgressEvent = { type: "url_start", progress: { done, total } };
    appendLog(toLogEntry(startEvt));
    emitProgress(runId, startEvt);

    const [settings] = await db.select().from(adminSettingsTable).limit(1);
    const blacklist = await db.select({ domain: domainBlacklistTable.domain }).from(domainBlacklistTable);

    const config = {
      maxPagesPerSite: settings?.maxPagesPerSite ?? 30,
      timeoutPerPage: settings?.timeoutPerPage ?? 30,
      imageReadingEnabled: settings?.imageReadingEnabled ?? true,
      searchKeywords: (settings?.searchKeywords as string[]) ?? ["silent auction", "gala", "fundraiser"],
      avoidKeywords: (settings?.avoidKeywords as string[]) ?? [],
      overrideKeywords: (settings?.overrideKeywords as string[]) ?? ["silent auction"],
      blacklistedDomains: blacklist.map((b) => b.domain),
      scoringWeights: (settings?.scoringWeights as any) ?? {},
      tierThresholds: (settings?.tierThresholds as any) ?? { tierA: 70, tierB: 45 },
      perDomainDelayMs: settings?.perDomainDelayMs ?? 1000,
      maxRetries: settings?.maxRetries ?? 3,
    };
    const maxConcurrentSites = Math.max(1, settings?.maxConcurrentSites ?? 5);

    // ── Worker pool over seed URLs ────────────────────────────────────────────
    // Each worker pulls the next un-crawled site off the shared cursor. A
    // failure on one site only affects that site; pause/stop signals are
    // checked before each new site is started (in-flight sites finish and
    // their results are saved).
    let cursor = 0;

    const processSite = async (url: string) => {
      const startEvt: CrawlProgressEvent = { type: "url_start", url, progress: { done, total } };
      appendLog(toLogEntry(startEvt));
      emitProgress(runId, startEvt);

      try {
        const events = await crawlSite(url, config, (ev) => {
          if (ev.type === "page_crawled") pagesCrawled++;
          if (ev.type === "error") errorCount++;
          appendLog(toLogEntry(ev));
          emitProgress(runId, ev);
        });

        // Cross-run dedupe: skip exact duplicates, flag changed events as
        // UPDATED, insert genuinely new finds as NEW.
        const classified = await classifyEvents(events);
        const toInsert = classified.filter((c) => c.verdict !== "DUPLICATE");

        for (const c of classified) {
          if (c.verdict === "DUPLICATE") {
            duplicateCount++;
            appendLog({
              ts: new Date().toISOString(), type: "dedupe", url: c.event.eventPageUrl,
              msg: `Skipped duplicate: "${c.event.eventName ?? c.event.eventPageUrl}" (already in database)`,
            });
          } else if (c.verdict === "UPDATED") {
            updatedCount++;
            appendLog({
              ts: new Date().toISOString(), type: "dedupe", url: c.event.eventPageUrl,
              msg: `Updated event: "${c.event.eventName ?? c.event.eventPageUrl}" (details changed since last crawl)`,
            });
          } else {
            newCount++;
            appendLog({
              ts: new Date().toISOString(), type: "dedupe", url: c.event.eventPageUrl,
              msg: `NEW find: "${c.event.eventName ?? c.event.eventPageUrl}"`, score: c.event.score,
            });
          }
        }

        // Batch insert instead of one row at a time
        for (let i = 0; i < toInsert.length; i += INSERT_BATCH_SIZE) {
          const chunk = toInsert.slice(i, i + INSERT_BATCH_SIZE);
          await db.insert(eventsTable).values(chunk.map((c) => toInsertRow(runId, c)));
          eventsMatched += chunk.length;
        }
      } catch (err) {
        errorCount++;
        logger.error({ err, url, runId }, "Crawl site error");
        const errEvt: CrawlProgressEvent = { type: "error", url, errorMessage: String(err) };
        appendLog(toLogEntry(errEvt));
        emitProgress(runId, errEvt);
      }

      completedUrls.push(url);
      done++;
      const doneEvt: CrawlProgressEvent = { type: "url_done", url, progress: { done, total } };
      appendLog(toLogEntry(doneEvt));
      emitProgress(runId, doneEvt);

      // Flush counters + log buffer to DB after each URL so restarts can resume
      await flushToDb().catch((err) => logger.warn({ err, runId }, "Post-site flush failed"));
    };

    const worker = async () => {
      while (true) {
        if (stoppedRuns.has(runId) || pausedRuns.has(runId)) return;
        const index = cursor++;
        if (index >= urls.length) return;
        await processSite(urls[index]);
      }
    };

    await Promise.all(Array.from({ length: Math.min(maxConcurrentSites, Math.max(1, urls.length)) }, worker));

    if (stoppedRuns.has(runId)) {
      appendLog({ ts: new Date().toISOString(), type: "error", msg: "Run stopped by user" });
      emitProgress(runId, { type: "complete", progress: { done, total } });
      await finalize("stopped");
      return;
    }

    if (pausedRuns.has(runId)) {
      appendLog({ ts: new Date().toISOString(), type: "url_done", msg: `Run paused by user (${done}/${total} sites done — resumable)` });
      emitProgress(runId, { type: "complete", progress: { done, total } });
      await finalize("paused");
      return;
    }

    const completeEvt: CrawlProgressEvent = { type: "complete", progress: { done, total } };
    appendLog(toLogEntry(completeEvt));
    emitProgress(runId, completeEvt);
    await finalize("completed");
  } catch (err) {
    logger.error({ err, runId }, "Crawl run failed");
    appendLog({ ts: new Date().toISOString(), type: "error", msg: `Run failed: ${String(err)}` });
    await finalize("failed");
  }
}

function serializeRun(run: typeof crawlRunsTable.$inferSelect, listName: string, topScore?: number | null) {
  return {
    id: run.id,
    urlListId: run.urlListId,
    urlListName: listName,
    status: run.status,
    triggeredBy: run.triggeredBy,
    totalUrls: run.totalUrls,
    pagesCrawled: run.pagesCrawled,
    eventsMatched: run.eventsMatched,
    errorCount: run.errorCount,
    newCount: run.newCount,
    updatedCount: run.updatedCount,
    duplicateCount: run.duplicateCount,
    archived: run.archived,
    topScore: topScore ?? null,
    createdAt: run.createdAt.toISOString(),
    completedAt: run.completedAt?.toISOString() ?? null,
  };
}

// GET /crawl-runs
router.get("/crawl-runs", async (req, res) => {
  const parsed = GetCrawlRunsQueryParams.safeParse(req.query);
  const urlListId = parsed.success ? parsed.data.urlListId : undefined;
  // Only include archived runs if the client explicitly passes includeArchived=true
  const includeArchived = req.query.includeArchived === "true" || req.query.includeArchived === "1";

  const conditions = [];
  if (urlListId) conditions.push(eq(crawlRunsTable.urlListId, Number(urlListId)));
  if (!includeArchived) conditions.push(eq(crawlRunsTable.archived, false));

  const baseQuery = db
    .select({
      run: crawlRunsTable,
      listName: urlListsTable.name,
      topScore: sql<number | null>`max(${eventsTable.score})`,
    })
    .from(crawlRunsTable)
    .innerJoin(urlListsTable, eq(crawlRunsTable.urlListId, urlListsTable.id))
    .leftJoin(eventsTable, eq(eventsTable.runId, crawlRunsTable.id))
    .groupBy(crawlRunsTable.id, urlListsTable.name)
    .$dynamic();

  const rows = conditions.length > 0
    ? await baseQuery.where(conditions.length === 1 ? conditions[0] : and(...conditions)).orderBy(sql`${crawlRunsTable.createdAt} desc`)
    : await baseQuery.orderBy(sql`${crawlRunsTable.createdAt} desc`);

  res.json(rows.map(({ run, listName, topScore }) => serializeRun(run, listName, topScore)));
});

// GET /crawl-runs/:id
router.get("/crawl-runs/:id", async (req, res) => {
  const parsed = GetCrawlRunParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) { res.status(400).json({ error: "Invalid id" }); return; }

  const [row] = await db
    .select({ run: crawlRunsTable, listName: urlListsTable.name })
    .from(crawlRunsTable)
    .innerJoin(urlListsTable, eq(crawlRunsTable.urlListId, urlListsTable.id))
    .where(eq(crawlRunsTable.id, parsed.data.id));

  if (!row) { res.status(404).json({ error: "Not found" }); return; }

  const topEvents = await db
    .select()
    .from(eventsTable)
    .where(eq(eventsTable.runId, parsed.data.id))
    .orderBy(sql`${eventsTable.score} desc`)
    .limit(3);

  res.json({
    ...serializeRun(row.run, row.listName),
    topEvents: topEvents.map(serializeEvent),
  });
});

// PATCH /crawl-runs/:id — archive/unarchive
router.patch("/crawl-runs/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const { archived } = req.body as { archived?: boolean };
  if (typeof archived !== "boolean") {
    res.status(400).json({ error: "archived (boolean) required" });
    return;
  }

  const [row] = await db
    .update(crawlRunsTable)
    .set({ archived })
    .where(eq(crawlRunsTable.id, id))
    .returning();

  if (!row) { res.status(404).json({ error: "Not found" }); return; }

  const [listRow] = await db
    .select({ name: urlListsTable.name })
    .from(urlListsTable)
    .where(eq(urlListsTable.id, row.urlListId));

  res.json(serializeRun(row, listRow?.name ?? ""));
});

// DELETE /crawl-runs/:id
router.delete("/crawl-runs/:id", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  await db.delete(crawlRunsTable).where(eq(crawlRunsTable.id, id));
  res.status(204).send();
});

// POST /crawl-runs/:id/stop
router.post("/crawl-runs/:id/stop", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [row] = await db
    .select({ status: crawlRunsTable.status })
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  if (row.status !== "running" && row.status !== "pending") {
    res.status(400).json({ error: "Run is not active" });
    return;
  }

  stoppedRuns.add(id);

  // Also immediately mark as stopped in DB so stuck runs (where server restarted
  // and the crawl loop is gone) are immediately reflected as stopped.
  await db
    .update(crawlRunsTable)
    .set({ status: "stopped", completedAt: new Date() })
    .where(eq(crawlRunsTable.id, id));

  // If the crawl loop is alive in this process it will notice the stop signal
  // and clean up (finalize) itself — deleting the buffer here would wipe the
  // persisted log. Only clean up when the loop is gone (previous process).
  if (!logBuffers.has(id)) {
    progressListeners.delete(id);
    stoppedRuns.delete(id);
  }

  res.json({ message: "Stop signal sent" });
});

// POST /crawl-runs/:id/pause — cooperative pause; in-flight sites finish, then
// the run halts with its queue position saved so it can be resumed later.
router.post("/crawl-runs/:id/pause", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [row] = await db
    .select({ status: crawlRunsTable.status })
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  if (row.status !== "running" && row.status !== "pending") {
    res.status(400).json({ error: "Run is not active" });
    return;
  }

  pausedRuns.add(id);
  // Reflect immediately in DB so a restarted server (where the crawl loop is
  // gone) still shows the run as paused/resumable.
  await db.update(crawlRunsTable).set({ status: "paused" }).where(eq(crawlRunsTable.id, id));

  res.json({ message: "Pause signal sent — in-flight sites will finish first" });
});

// POST /crawl-runs/:id/resume — continue a paused run from where it left off
router.post("/crawl-runs/:id/resume", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [run] = await db.select().from(crawlRunsTable).where(eq(crawlRunsTable.id, id));
  if (!run) { res.status(404).json({ error: "Not found" }); return; }
  if (run.status !== "paused") {
    res.status(400).json({ error: "Only paused runs can be resumed" });
    return;
  }

  const urlItems = await db
    .select({ url: urlListItemsTable.url })
    .from(urlListItemsTable)
    .where(eq(urlListItemsTable.urlListId, run.urlListId));

  const alreadyDone = new Set((run.completedUrls as string[]) ?? []);
  const remaining = urlItems.map((r) => r.url).filter((u) => !alreadyDone.has(u));

  await db.update(crawlRunsTable).set({ status: "running" }).where(eq(crawlRunsTable.id, id));

  // Fire and forget
  startCrawlRun(id, remaining, run.triggeredBy, { resume: true }).catch((err) =>
    logger.error({ err, runId: id }, "Resumed run failed")
  );

  const [listRow] = await db
    .select({ name: urlListsTable.name })
    .from(urlListsTable)
    .where(eq(urlListsTable.id, run.urlListId));

  res.status(202).json(serializeRun({ ...run, status: "running" }, listRow?.name ?? ""));
});

// POST /crawl-runs/:id/rerun
router.post("/crawl-runs/:id/rerun", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  const [existingRun] = await db
    .select()
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!existingRun) { res.status(404).json({ error: "Not found" }); return; }

  const urlListId = existingRun.urlListId;

  const urlItems = await db
    .select({ url: urlListItemsTable.url })
    .from(urlListItemsTable)
    .where(eq(urlListItemsTable.urlListId, urlListId));

  const urls = urlItems.map((r) => r.url);

  const [newRun] = await db
    .insert(crawlRunsTable)
    .values({
      urlListId,
      status: "pending",
      triggeredBy: "manual",
      totalUrls: urls.length,
      pagesCrawled: 0,
      eventsMatched: 0,
      errorCount: 0,
      archived: false,
      debugLog: [],
    })
    .returning();

  const [listRow] = await db
    .select({ name: urlListsTable.name })
    .from(urlListsTable)
    .where(eq(urlListsTable.id, urlListId));

  // Fire and forget
  startCrawlRun(newRun.id, urls, "manual").catch((err) =>
    logger.error({ err, runId: newRun.id }, "Re-run failed")
  );

  res.status(202).json(serializeRun(newRun, listRow?.name ?? ""));
});

// GET /crawl-runs/:id/logs — stored debug log for completed runs
router.get("/crawl-runs/:id/logs", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }

  if (logBuffers.has(id)) {
    res.json(logBuffers.get(id) ?? []);
    return;
  }

  const [row] = await db
    .select({ debugLog: crawlRunsTable.debugLog })
    .from(crawlRunsTable)
    .where(eq(crawlRunsTable.id, id));

  if (!row) { res.status(404).json({ error: "Not found" }); return; }
  res.json(row.debugLog ?? []);
});

// GET /crawl-runs/:id/events — all events for a run
router.get("/crawl-runs/:id/events", async (req, res) => {
  const id = Number(req.params.id);
  if (!id) { res.status(400).json({ error: "Invalid id" }); return; }
  const events = await db
    .select()
    .from(eventsTable)
    .where(eq(eventsTable.runId, id))
    .orderBy(sql`${eventsTable.score} desc`);
  res.json(events.map(serializeEvent));
});

// GET /crawl-runs/:id/progress (SSE)
router.get("/crawl-runs/:id/progress", async (req, res) => {
  const runId = Number(req.params.id);

  res.setHeader("Content-Type", "text/event-stream");
  res.setHeader("Cache-Control", "no-cache");
  res.setHeader("Connection", "keep-alive");
  res.flushHeaders();

  const send = (event: CrawlProgressEvent) => {
    res.write(`data: ${JSON.stringify(event)}\n\n`);
  };

  // Replay existing log entries so a reconnecting client sees full history.
  // We send a special "log_replay" wrapper so the client can push entries
  // directly (preserving original timestamps and messages).
  const sendReplay = (entries: LogEntry[]) => {
    if (entries.length === 0) return;
    res.write(`data: ${JSON.stringify({ type: "log_replay", entries })}\n\n`);
  };

  const inMemory: LogEntry[] = logBuffers.get(runId) ?? [];
  if (inMemory.length > 0) {
    // Run is still active in this process — replay in-memory buffer
    sendReplay(inMemory);
  } else {
    // Run may be finished or from a previous process — try DB
    try {
      const [row] = await db
        .select({ debugLog: crawlRunsTable.debugLog, status: crawlRunsTable.status })
        .from(crawlRunsTable)
        .where(eq(crawlRunsTable.id, runId));
      if (row?.debugLog && Array.isArray(row.debugLog) && row.debugLog.length > 0) {
        sendReplay(row.debugLog as LogEntry[]);
        // If run is already terminal, send a final "complete" so the client
        // can close the connection and show the completed state.
        if (row.status === "completed" || row.status === "stopped" || row.status === "failed") {
          send({ type: "complete" });
          res.end();
          return;
        }
      }
    } catch (err) {
      req.log.warn({ err, runId }, "SSE log replay failed");
    }
  }

  if (!progressListeners.has(runId)) {
    progressListeners.set(runId, new Set());
  }
  progressListeners.get(runId)!.add(send);

  req.on("close", () => {
    progressListeners.get(runId)?.delete(send);
  });
});

function serializeEvent(e: typeof eventsTable.$inferSelect) {
  return {
    id: e.id,
    runId: e.runId,
    score: e.score,
    tier: e.tier,
    status: e.status,
    eventName: e.eventName,
    eventDate: e.eventDate,
    eventVenue: e.eventVenue,
    eventAddress: e.eventAddress,
    eventDescription: e.eventDescription,
    auctionType: e.auctionType,
    hasSilentAuction: e.hasSilentAuction,
    hasLiveAuction: e.hasLiveAuction,
    ticketPrice: e.ticketPrice ? parseFloat(String(e.ticketPrice)) : null,
    tablePrice: e.tablePrice ? parseFloat(String(e.tablePrice)) : null,
    formality: e.formality,
    rsvpLink: e.rsvpLink,
    contactName: e.contactName,
    contactEmail: e.contactEmail,
    contactPhone: e.contactPhone,
    eventPageUrl: e.eventPageUrl,
    audienceNote: e.audienceNote,
    sponsorshipMentioned: e.sponsorshipMentioned,
    orgName: e.orgName,
    orgAddress: e.orgAddress,
    orgCity: e.orgCity,
    orgPhone: e.orgPhone,
    orgEmail: e.orgEmail,
    orgWebsite: e.orgWebsite,
    isPast: e.isPast,
    errorMessage: e.errorMessage,
    createdAt: e.createdAt.toISOString(),
  };
}

export { serializeEvent };
export default router;
