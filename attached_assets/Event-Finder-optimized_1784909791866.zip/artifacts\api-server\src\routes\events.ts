import { Router } from "express";
import { db } from "@workspace/db";
import { eventsTable, crawlRunsTable, urlListsTable } from "@workspace/db";
import { eq, and, gte, lte, ilike, or, sql, ne } from "drizzle-orm";
import { GetEventsQueryParams, GetEventParams, ExportEventsQueryParams } from "@workspace/api-zod";
import { serializeEvent } from "./crawlRuns";

const router = Router();

// GET /events
router.get("/events", async (req, res) => {
  const parsed = GetEventsQueryParams.safeParse(req.query);
  const params = (parsed.success ? parsed.data : {}) as NonNullable<typeof parsed["data"]>;

  const {
    runId,
    tier,
    auctionType,
    status,
    minScore,
    maxScore,
    search,
    sortBy = "score",
    sortDir = "desc",
    page = 1,
    limit = 50,
  } = params;

  // Read hidePast directly from the raw query string.
  // zod.coerce.boolean() coerces "false" → true, so we bypass it here.
  // Default: hide past events (true) unless the client sends hidePast=false.
  const showPast = req.query.hidePast === "false";

  const conditions = [];
  if (runId) conditions.push(eq(eventsTable.runId, Number(runId)));
  if (tier) conditions.push(eq(eventsTable.tier, tier));
  if (status) conditions.push(eq(eventsTable.status, status));
  if (!showPast) {
    conditions.push(ne(eventsTable.isPast, true));
  }
  if (auctionType) conditions.push(eq(eventsTable.auctionType, auctionType));
  if (minScore !== undefined) conditions.push(gte(eventsTable.score, Number(minScore)));
  if (maxScore !== undefined) conditions.push(lte(eventsTable.score, Number(maxScore)));

  if (search) {
    const s = `%${search}%`;
    conditions.push(
      or(
        ilike(eventsTable.eventName, s),
        ilike(eventsTable.orgName, s),
        ilike(eventsTable.eventVenue, s),
        ilike(eventsTable.eventAddress, s),
        ilike(eventsTable.contactName, s),
        ilike(eventsTable.contactEmail, s),
        ilike(eventsTable.audienceNote, s)
      )
    );
  }

  const where = conditions.length > 0 ? and(...conditions) : undefined;

  const validSortCols: Record<string, any> = {
    score: eventsTable.score,
    eventDate: eventsTable.eventDate,
    tier: eventsTable.tier,
    ticketPrice: eventsTable.ticketPrice,
    tablePrice: eventsTable.tablePrice,
    eventName: eventsTable.eventName,
    orgName: eventsTable.orgName,
    createdAt: eventsTable.createdAt,
  };
  const sortCol = validSortCols[sortBy as string] ?? eventsTable.score;
  const orderExpr = sortDir === "asc" ? sql`${sortCol} asc` : sql`${sortCol} desc`;

  const offset = (Number(page) - 1) * Number(limit);

  const [countRow] = await db
    .select({ count: sql<number>`count(*)` })
    .from(eventsTable)
    .where(where);

  const rows = await db
    .select({ event: eventsTable, listName: urlListsTable.name })
    .from(eventsTable)
    .leftJoin(crawlRunsTable, eq(eventsTable.runId, crawlRunsTable.id))
    .leftJoin(urlListsTable, eq(crawlRunsTable.urlListId, urlListsTable.id))
    .where(where)
    .orderBy(orderExpr)
    .limit(Number(limit))
    .offset(offset);

  res.json({
    events: rows.map(({ event, listName }) => ({ ...serializeEvent(event), runName: listName ?? null })),
    total: Number(countRow?.count ?? 0),
    page: Number(page),
    limit: Number(limit),
  });
});

// GET /events/export (must be before /:id)
router.get("/events/export", async (req, res) => {
  const parsed = ExportEventsQueryParams.safeParse(req.query);
  const params = parsed.success ? parsed.data : {};

  const conditions = [];
  if ((params as any).runId) conditions.push(eq(eventsTable.runId, Number((params as any).runId)));
  if ((params as any).tier) conditions.push(eq(eventsTable.tier, (params as any).tier));

  const where = conditions.length > 0 ? and(...conditions) : undefined;
  const rows = await db.select().from(eventsTable).where(where).orderBy(sql`${eventsTable.score} desc`);

  const headers = [
    "Score", "Tier", "Status", "Event Name", "Event Date", "Event Venue", "Event Address",
    "Auction Type", "Has Silent Auction", "Has Live Auction", "Ticket Price", "Table Price",
    "Formality", "RSVP Link", "Contact Name", "Contact Email", "Contact Phone",
    "Event Page URL", "Audience Note", "Sponsorship Mentioned",
    "Org Name", "Org Address", "Org City", "Org Phone", "Org Email", "Org Website", "Error",
  ];

  const csvRows = [
    headers.join(","),
    ...rows.map((e) => [
      e.score, e.tier, e.status,
      csvEscape(e.eventName), csvEscape(e.eventDate), csvEscape(e.eventVenue), csvEscape(e.eventAddress),
      csvEscape(e.auctionType), e.hasSilentAuction, e.hasLiveAuction,
      e.ticketPrice, e.tablePrice, csvEscape(e.formality),
      csvEscape(e.rsvpLink), csvEscape(e.contactName), csvEscape(e.contactEmail), csvEscape(e.contactPhone),
      csvEscape(e.eventPageUrl), csvEscape(e.audienceNote), e.sponsorshipMentioned,
      csvEscape(e.orgName), csvEscape(e.orgAddress), csvEscape(e.orgCity),
      csvEscape(e.orgPhone), csvEscape(e.orgEmail), csvEscape(e.orgWebsite), csvEscape(e.errorMessage),
    ].join(",")),
  ];

  res.setHeader("Content-Type", "text/csv");
  res.setHeader("Content-Disposition", "attachment; filename=events.csv");
  res.send(csvRows.join("\n"));
});

// GET /events/:id
router.get("/events/:id", async (req, res) => {
  const parsed = GetEventParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) { res.status(400).json({ error: "Invalid id" }); return; }

  const [event] = await db.select().from(eventsTable).where(eq(eventsTable.id, parsed.data.id));
  if (!event) { res.status(404).json({ error: "Not found" }); return; }

  res.json(serializeEvent(event));
});

function csvEscape(val: string | null | undefined): string {
  if (val == null) return "";
  const str = String(val);
  if (str.includes(",") || str.includes('"') || str.includes("\n")) {
    return `"${str.replace(/"/g, '""')}"`;
  }
  return str;
}

export default router;
