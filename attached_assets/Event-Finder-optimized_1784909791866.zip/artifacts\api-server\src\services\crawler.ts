import * as cheerio from "cheerio";
import got from "got";
import { Firecrawl as FirecrawlApp } from "@mendable/firecrawl-js";
import { logger } from "../lib/logger";
import { extractEventFromPage } from "./extractor";
import { scoreEvent } from "./scorer";
import type { ScoringWeights, TierThresholds } from "./scorer";
import { politeDelay, withRetry } from "./rateLimiter";

export interface CrawlConfig {
  maxPagesPerSite: number;
  timeoutPerPage: number;
  imageReadingEnabled: boolean;
  searchKeywords: string[];
  avoidKeywords: string[];
  overrideKeywords: string[];
  blacklistedDomains: string[];
  scoringWeights: ScoringWeights;
  tierThresholds: TierThresholds;
  /** Minimum gap between two requests to the same domain (politeness). */
  perDomainDelayMs: number;
  /** Retries per page fetch on transient failures (429/5xx/network). */
  maxRetries: number;
}

export interface CrawlProgressEvent {
  type: "url_start" | "url_done" | "page_crawled" | "event_found" | "error" | "complete";
  url?: string;
  pageUrl?: string;
  eventName?: string;
  score?: number;
  errorMessage?: string;
  progress?: { done: number; total: number };
}

export interface CrawledEvent {
  eventPageUrl: string;
  eventName?: string;
  eventDate?: string;
  eventVenue?: string;
  eventAddress?: string;
  eventDescription?: string;
  auctionType?: string;
  hasSilentAuction?: boolean;
  hasLiveAuction?: boolean;
  ticketPrice?: number | null;
  tablePrice?: number | null;
  formality?: string;
  rsvpLink?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  audienceNote?: string;
  sponsorshipMentioned?: boolean;
  orgName?: string;
  orgAddress?: string;
  orgCity?: string;
  orgPhone?: string;
  orgEmail?: string;
  orgWebsite?: string;
  score: number;
  tier: "A" | "B" | "C";
  isPast: boolean;
  errorMessage?: string;
}

const EVENT_PATH_KEYWORDS = [
  "event", "gala", "auction", "fundraiser", "calendar", "benefit",
  "banquet", "rsvp", "donate", "support", "tickets", "programs", "get-involved"
];

const ARCHIVE_PATTERNS = [
  "past", "archive", "previous", "recap", "gallery", "highlights",
  "2020", "2021", "2022", "2023", "2024",
];

// ── Firecrawl client (singleton, lazy) ────────────────────────────────────────
let _firecrawlClient: FirecrawlApp | null | undefined = undefined; // undefined = not yet checked

function getFirecrawlClient(): FirecrawlApp | null {
  if (_firecrawlClient !== undefined) return _firecrawlClient;
  const key = process.env.FIRECRAWL_API_KEY;
  if (!key) {
    logger.warn("FIRECRAWL_API_KEY not set — falling back to got+cheerio");
    _firecrawlClient = null;
    return null;
  }
  _firecrawlClient = new FirecrawlApp({ apiKey: key });
  logger.info("Firecrawl client initialised");
  return _firecrawlClient;
}

// ── Archive / URL helpers ──────────────────────────────────────────────────────
function isArchivePage(url: string, htmlOrText: string): boolean {
  try {
    const urlPath = new URL(url).pathname.toLowerCase();
    if (ARCHIVE_PATTERNS.some((p) => urlPath.includes(p))) return true;
  } catch {
    // ignore malformed URL
  }
  // Works for both raw HTML and plain text
  const lower = htmlOrText.toLowerCase().slice(0, 2000);
  return ARCHIVE_PATTERNS.some((p) => lower.includes(p));
}

function deduplicateEvents(events: CrawledEvent[]): CrawledEvent[] {
  const keyMap = new Map<string, CrawledEvent>();
  const countFilled = (e: CrawledEvent): number =>
    Object.values(e).filter((v) => v !== null && v !== undefined && v !== "").length;

  for (const event of events) {
    const name = (event.eventName ?? "").toLowerCase().trim();
    const date = (event.eventDate ?? "").toLowerCase().trim();
    const key = name || date ? `${name}|||${date}` : `__no-key-${Math.random()}`;
    const existing = keyMap.get(key);
    if (!existing || countFilled(event) > countFilled(existing)) {
      keyMap.set(key, event);
    }
  }
  return Array.from(keyMap.values());
}

function getDomain(url: string): string {
  try {
    return new URL(url).hostname;
  } catch {
    return "";
  }
}

function isEventUrl(url: string): boolean {
  const path = url.toLowerCase();
  return EVENT_PATH_KEYWORDS.some((k) => path.includes(k));
}

// Static assets and WordPress junk paths that should never be crawled
const STATIC_ASSET_EXTENSIONS = [
  ".pdf", ".png", ".jpg", ".jpeg", ".gif", ".webp", ".svg",
  ".mp4", ".mp3", ".mov", ".avi", ".zip", ".tar", ".gz",
  ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
  ".css", ".js", ".woff", ".woff2", ".ttf", ".eot", ".ico",
];
const STATIC_PATH_SEGMENTS = ["/wp-content/uploads/", "/wp-json/", "/feed/", "/.well-known/"];

function isStaticAsset(url: string): boolean {
  try {
    const pathname = new URL(url).pathname.toLowerCase();
    if (STATIC_ASSET_EXTENSIONS.some((ext) => pathname.endsWith(ext))) return true;
    if (STATIC_PATH_SEGMENTS.some((seg) => pathname.includes(seg))) return true;
  } catch {
    // malformed URL — let the fetcher deal with it
  }
  return false;
}

function normalizeUrl(base: string, href: string): string | null {
  try {
    const url = new URL(href, base);
    url.hash = "";
    if (url.protocol !== "http:" && url.protocol !== "https:") return null;
    return url.href;
  } catch {
    return null;
  }
}

// ── Firecrawl page fetch ───────────────────────────────────────────────────────
async function fetchPageFirecrawl(
  url: string,
  domain: string,
  timeoutMs: number
): Promise<{ text: string; html: string; links: string[] } | null> {
  const fc = getFirecrawlClient();
  if (!fc) return null;

  try {
    // Race the Firecrawl call against a hard timeout so a hanging server
    // doesn't stall the entire crawl indefinitely.
    const scrapePromise = fc.scrape(url, {
      formats: ["markdown", "html", "links"] as any,
      onlyMainContent: true,
    } as any);

    let timeoutHandle!: ReturnType<typeof setTimeout>;
    const timeoutPromise = new Promise<never>((_, reject) => {
      timeoutHandle = setTimeout(
        () => reject(new Error(`Firecrawl timeout after ${timeoutMs}ms`)),
        timeoutMs
      );
    });

    const result = await Promise.race([scrapePromise, timeoutPromise]);
    clearTimeout(timeoutHandle);

    const text = result.markdown ?? "";
    const html = result.html ?? "";
    // Filter links to same-domain only, skip static assets
    const rawLinks: string[] = result.links ?? [];
    const links = rawLinks
      .map((href) => normalizeUrl(url, href))
      .filter((u): u is string => !!u && getDomain(u) === domain && !isStaticAsset(u));

    return { text, html, links };
  } catch (err) {
    logger.warn({ url, err }, "Firecrawl scrape threw or timed out — will fall back to got");
    return null;
  }
}

// ── Cheerio fallback page fetch ────────────────────────────────────────────────
async function fetchPageFallback(
  url: string,
  timeoutMs: number,
  maxRetries: number
): Promise<{ text: string; html: string } | null> {
  try {
    const response = await withRetry(
      () =>
        got(url, {
          timeout: { request: timeoutMs },
          headers: {
            "User-Agent": "Mozilla/5.0 (compatible; EventFinderBot/1.0)",
            Accept: "text/html,application/xhtml+xml",
          },
          followRedirect: true,
          retry: { limit: 0 }, // retries handled by withRetry so backoff also cools the domain
          https: { rejectUnauthorized: false },
        }),
      { retries: maxRetries, domain: getDomain(url), label: "page-fetch" }
    );
    const html = response.body;
    const $ = cheerio.load(html);
    $("script, style, nav, header, footer, head, aside, iframe, noscript, [role='navigation'], [role='banner'], [role='complementary'], .cookie-banner, .cookie-notice, .nav, .navbar, .menu, .sidebar, .breadcrumb").remove();
    const mainEl = $("main, article, [role='main'], .main-content, #main-content, .post-content, .entry-content, .content-area, #content").first();
    const textSource = mainEl.length ? mainEl : $("body");
    const text = textSource.text().replace(/\s+/g, " ").trim();
    return { text, html };
  } catch (err) {
    logger.warn({ url, err }, "Fallback fetch failed");
    return null;
  }
}

// ── Unified fetchPage ──────────────────────────────────────────────────────────
async function fetchPage(
  url: string,
  domain: string,
  timeoutMs: number,
  config: Pick<CrawlConfig, "perDomainDelayMs" | "maxRetries">
): Promise<{ text: string; html: string; links?: string[] } | null> {
  // Politeness: space out requests to the same domain even when many sites
  // are being crawled in parallel.
  await politeDelay(domain, config.perDomainDelayMs);

  // Try Firecrawl first (with the same per-page timeout)
  const fc = await fetchPageFirecrawl(url, domain, timeoutMs);
  if (fc) return fc;
  // Fall back to got+cheerio (with retry + backoff)
  return fetchPageFallback(url, timeoutMs, config.maxRetries);
}

// ── Sitemap / link helpers (always use got — no need for Firecrawl) ─────────────
async function getSitemapUrls(baseUrl: string, timeoutMs: number, perDomainDelayMs: number): Promise<string[]> {
  try {
    await politeDelay(getDomain(baseUrl), perDomainDelayMs);
    const sitemapUrl = new URL("/sitemap.xml", baseUrl).href;
    const response = await got(sitemapUrl, {
      timeout: { request: timeoutMs },
      https: { rejectUnauthorized: false },
    });
    const $ = cheerio.load(response.body, { xmlMode: true });
    const urls: string[] = [];
    $("url loc").each((_, el) => {
      const loc = $(el).text().trim();
      if (loc) urls.push(loc);
    });
    return urls;
  } catch {
    return [];
  }
}

function extractInternalLinks(html: string, baseUrl: string): string[] {
  const $ = cheerio.load(html);
  const domain = getDomain(baseUrl);
  const links: string[] = [];
  $("a[href]").each((_, el) => {
    const href = $(el).attr("href");
    if (!href) return;
    const normalized = normalizeUrl(baseUrl, href);
    if (normalized && getDomain(normalized) === domain) {
      links.push(normalized);
    }
  });
  return [...new Set(links)];
}

// ── Main crawl function ────────────────────────────────────────────────────────
export async function crawlSite(
  siteUrl: string,
  config: CrawlConfig,
  onProgress: (event: CrawlProgressEvent) => void
): Promise<CrawledEvent[]> {
  const domain = getDomain(siteUrl);
  if (!domain) return [];

  if (config.blacklistedDomains.some((d) => domain.includes(d))) {
    onProgress({ type: "error", url: siteUrl, errorMessage: "Domain is blacklisted" });
    return [];
  }

  const visited = new Set<string>();
  const toVisit: string[] = [];
  const events: CrawledEvent[] = [];
  const timeoutMs = config.timeoutPerPage * 1000;

  // Try sitemap first
  const sitemapUrls = await getSitemapUrls(siteUrl, timeoutMs, config.perDomainDelayMs);
  if (sitemapUrls.length > 0) {
    // Drop static assets from sitemap before queuing
    const crawlable = sitemapUrls.filter((u) => !isStaticAsset(u));
    const eventUrls = crawlable.filter(isEventUrl);
    const otherUrls = crawlable.filter((u) => !isEventUrl(u));
    toVisit.push(...eventUrls, ...otherUrls);
  } else {
    toVisit.push(siteUrl);
  }

  while (toVisit.length > 0 && visited.size < config.maxPagesPerSite) {
    const url = toVisit.shift()!;
    if (visited.has(url)) continue;
    if (getDomain(url) !== domain) continue;
    // Skip static assets that slipped into the queue via link extraction
    if (isStaticAsset(url)) continue;
    visited.add(url);

    onProgress({ type: "page_crawled", pageUrl: url });

    const result = await fetchPage(url, domain, timeoutMs, config);
    if (!result) {
      onProgress({ type: "error", pageUrl: url, errorMessage: "Failed to fetch page" });
      continue;
    }

    const { text, html } = result;

    // Extract links and add to queue (prioritize event-related, skip static assets)
    if (sitemapUrls.length === 0) {
      // If Firecrawl returned links, use those; otherwise fall back to cheerio
      const rawLinks = result.links ?? extractInternalLinks(html, url);
      const links = rawLinks.filter((l) => !isStaticAsset(l));
      const eventLinks = links.filter(isEventUrl);
      const otherLinks = links.filter((l) => !isEventUrl(l));
      for (const link of [...eventLinks, ...otherLinks]) {
        if (!visited.has(link)) toVisit.unshift(link);
      }
    }

    // Archive/past-page gate
    if (isArchivePage(url, text || html)) {
      onProgress({ type: "error", pageUrl: url, errorMessage: "Skipped: archive/past page" });
      continue;
    }

    // Keyword gate + AI extraction
    try {
      const extracted = await extractEventFromPage(
        text,
        url,
        config.searchKeywords,
        config.avoidKeywords,
        config.overrideKeywords,
        html,
        config.imageReadingEnabled
      );

      if (extracted) {
        const { score, tier, isPast } = scoreEvent(
          {
            hasSilentAuction: extracted.hasSilentAuction,
            hasLiveAuction: extracted.hasLiveAuction,
            auctionType: extracted.auctionType,
            ticketPrice: extracted.ticketPrice,
            tablePrice: extracted.tablePrice,
            formality: extracted.formality,
            eventDate: extracted.eventDate,
            orgName: extracted.orgName,
          },
          config.scoringWeights,
          config.tierThresholds
        );

        const crawledEvent: CrawledEvent = {
          ...extracted,
          eventPageUrl: url,
          score,
          tier,
          isPast,
          ticketPrice: extracted.ticketPrice ?? null,
          tablePrice: extracted.tablePrice ?? null,
        };
        events.push(crawledEvent);
        onProgress({ type: "event_found", pageUrl: url, eventName: extracted.eventName, score });
      }
    } catch (err) {
      logger.error({ err, url }, "Extraction error");
    }
  }

  return deduplicateEvents(events);
}
