import OpenAI from "openai";
import * as cheerio from "cheerio";
import got from "got";
import { logger } from "../lib/logger";
import { createLimiter } from "./rateLimiter";

let openaiClient: OpenAI | null = null;

function getOpenAIClient(): OpenAI | null {
  const baseURL = process.env.AI_INTEGRATIONS_OPENAI_BASE_URL;
  const apiKey = process.env.AI_INTEGRATIONS_OPENAI_API_KEY;
  if (!baseURL || !apiKey) return null;
  if (!openaiClient) {
    // maxRetries: the SDK retries 429s/5xx with backoff on its own
    openaiClient = new OpenAI({ baseURL, apiKey, maxRetries: 3 });
  }
  return openaiClient;
}

// Global cap on concurrent AI calls so parallel site crawls can't stampede the
// OpenAI API into rate limits. Configurable via env; defaults to 4.
const aiLimit = createLimiter(Math.max(1, Number(process.env.AI_MAX_CONCURRENCY) || 4));

export interface ExtractedEvent {
  eventName?: string;
  eventDate?: string;
  eventVenue?: string;
  eventAddress?: string;
  eventDescription?: string;
  auctionType?: string;
  hasSilentAuction?: boolean;
  hasLiveAuction?: boolean;
  ticketPrice?: number | null;
  tablePrice?: number | null;
  formality?: string;
  rsvpLink?: string;
  contactName?: string;
  contactEmail?: string;
  contactPhone?: string;
  audienceNote?: string;
  sponsorshipMentioned?: boolean;
  orgName?: string;
  orgAddress?: string;
  orgCity?: string;
  orgPhone?: string;
  orgEmail?: string;
  orgWebsite?: string;
  relevant?: boolean;
}

const SYSTEM_PROMPT = `You are a strict charity fundraising event analyst for a financial advisory firm that sponsors charity galas, silent auctions, and major nonprofit fundraisers.

Your job: determine whether a webpage describes a QUALIFYING charity fundraising event, and if so, extract all structured details.

INPUT FORMAT: The page content you receive is clean markdown extracted by Firecrawl (not raw HTML). Use its structure to your advantage:
- ## and # headings often contain the event name, venue name, or section labels
- **bold text** often highlights key facts: dates, ticket prices, venue names, and contact details
- Bullet lists and tables often contain pricing tiers, schedule details, or sponsorship levels
- The first H1 or H2 heading is usually the event name
- Look for date patterns in headings and bold spans before scanning body paragraphs

QUALIFYING events MUST be:
- A charity gala, fundraising dinner, silent auction, live auction, benefit concert, golf tournament for charity, or similar nonprofit fundraiser
- Hosted by or benefiting a nonprofit, foundation, hospital, school, or charity organization
- Raising money for a cause (proceeds benefit someone or something beyond the organizer)
- An actual ticketed or sponsored event (not just a webpage, blog post, or news article ABOUT events)

DISQUALIFY and return relevant=false if the page is:
- A business conference, trade show, corporate event, or company open house
- A community market, craft fair, farmer's market, or local vendor fair (even if it benefits charity tangentially)
- A sporting event or competition where charity is not the primary stated purpose
- A recurring class, meetup, or organizational staff meeting
- A general "events calendar" listing page (multiple events, no single event detail)
- A past event recap or news article
- Any event where there is NO clear fundraising, donation, ticket purchase, or sponsorship language
- An event whose date has clearly already passed (return relevant=false for past events)

FUTURE EVENTS ONLY: If the event date is clearly in the past, return relevant=false. Only extract events that have not yet occurred.

FIELD POPULATION RULES — READ THESE CAREFULLY:
- event_name: NEVER return null, empty string, or "Unnamed event". The first # or ## heading is usually the event name — use it. If no heading exists, use the page title provided in the user message. A name is ALWAYS derivable.
- event_date: Check ## headings, **bold spans**, and the first few paragraphs first — dates are frequently bolded or placed under a heading. Extract the date as written.
- venue name and address: Look for a heading or bold label like "Venue:", "Location:", or "Where:" followed by the venue name. Also check bulleted details sections and any address-like text.
- org_name: Check the page footer text, copyright line, "About" or "Presented by" sections, and any header branding text.
- contact info: Try to find at least one contact method (email, phone, or RSVP link). Emails and phone numbers are often in a "Contact" or "Questions?" section at the bottom.
- For every field: exhaust ALL sources on the page before returning null. Only return null when the information is genuinely absent.

EXTRACTION RULES (when relevant=true):
- eventDate: extract the specific date as written (e.g. "April 30, 2026" or "Thursday, April 30, 2026"). If only a year is mentioned, skip it.
- eventVenue: the name of the venue or location where the event is held
- ticketPrice: numeric dollar amount per person/ticket (e.g. 150 for $150/ticket). null if not stated.
- tablePrice: numeric dollar amount for a full table/sponsorship (e.g. 2500 for $2,500/table). null if not stated.
- formality: one of "black-tie", "gala", "cocktail", "casual", "unknown"
- auctionType: one of "silent", "live", "both", "online", "none"
- hasSilentAuction / hasLiveAuction: true only if explicitly stated
- orgName: the charity/nonprofit hosting or benefiting from the event
- eventDescription: 1-2 sentences describing what the event is and who it benefits
- contactName, contactEmail, contactPhone: who to contact for tickets/info
- rsvpLink: direct URL or page for registration/tickets if found
- sponsorshipMentioned: true if sponsorship packages are described
- audienceNote: brief note on attendee demographics if mentioned (e.g. "Houston philanthropic community")

Return ONLY valid JSON matching this schema. No markdown, no explanation.`;

const IMAGE_SYSTEM_PROMPT = `You are analyzing an image from a webpage to determine if it is a flyer for a charity fundraising event and, if so, to extract details.

FIRST, decide whether this is a charity fundraising event flyer:
- relevant: true ONLY if the image is a flyer/poster for a charity gala, silent auction, benefit dinner, fundraising event, or nonprofit fundraiser with clear fundraising language (auction, donate, proceeds benefit, sponsorship, etc.)
- relevant: false for general community events, business/corporate events, sports, photos, logos, decorative images, or any image without explicit charity/fundraising language

If relevant=true, extract any of these fields that are clearly visible:
- eventName: the event title as shown
- eventDate: the date as written on the image
- eventVenue: the venue/location name
- ticketPrice: numeric dollar amount per ticket/person
- tablePrice: numeric dollar amount per table
- auctionType: "silent", "live", "both", or "none"
- hasSilentAuction: true/false
- hasLiveAuction: true/false
- orgName: the charity or organization name
- contactEmail or contactPhone if visible
- rsvpLink: any URL shown for registration

Return ONLY a JSON object. Always include "relevant": true or false. Omit other fields you cannot determine. If this is not a fundraiser flyer, return {"relevant": false}.`;

/**
 * Returns true for private/loopback/link-local hostnames and IPs.
 * Used to block SSRF when fetching user-supplied image URLs.
 */
function isPrivateHostname(hostname: string): boolean {
  if (!hostname) return true;
  const h = hostname.toLowerCase();
  if (h === "localhost" || h === "::1") return true;
  // Reject anything that resolves to a numeric IPv4 in a private range
  const parts = h.split(".").map(Number);
  if (parts.length === 4 && parts.every(n => !isNaN(n) && n >= 0 && n <= 255)) {
    const [a, b] = parts;
    if (a === 127) return true;               // loopback
    if (a === 10) return true;                // RFC 1918
    if (a === 172 && b >= 16 && b <= 31) return true; // RFC 1918
    if (a === 192 && b === 168) return true;  // RFC 1918
    if (a === 169 && b === 254) return true;  // link-local
    if (a === 0) return true;                 // "this" network
    if (a === 100 && b >= 64 && b <= 127) return true; // shared address
    if (a === 198 && (b === 18 || b === 19)) return true; // benchmarking
  }
  return false;
}

function extractImageUrls(html: string, baseUrl: string): string[] {
  const $ = cheerio.load(html);
  const domain = (() => { try { return new URL(baseUrl).hostname; } catch { return ""; } })();
  const priorityUrls: string[] = [];
  const regularUrls: string[] = [];

  $("img").each((_, el) => {
    const src = $(el).attr("src") || $(el).attr("data-src") || $(el).attr("data-lazy-src");
    if (!src) return;

    // Skip tiny/icon images
    const width = parseInt($(el).attr("width") || "0", 10);
    const height = parseInt($(el).attr("height") || "0", 10);
    if ((width > 0 && width < 80) || (height > 0 && height < 80)) return;

    // Skip obvious non-event images
    const srcLower = src.toLowerCase();
    if (srcLower.includes("logo") || srcLower.includes("icon") || srcLower.includes("avatar") ||
        srcLower.includes("thumbnail") || srcLower.includes("sprite") || srcLower.includes(".svg")) return;

    try {
      const absoluteUrl = new URL(src, baseUrl).href;
      const parsed = new URL(absoluteUrl);

      // Only allow http/https
      if (parsed.protocol !== "http:" && parsed.protocol !== "https:") return;

      // SSRF guard: only same-domain images; never fetch arbitrary external hosts
      if (parsed.hostname !== domain) return;

      // Extra guard against private IPs in same-domain aliases
      if (isPrivateHostname(parsed.hostname)) return;

      // Prioritize images near event keywords
      const alt = ($(el).attr("alt") || "").toLowerCase();
      const surroundingText = ($(el).closest("section, article, div").text() || "").toLowerCase().slice(0, 300);
      const isEventRelated = alt.includes("gala") || alt.includes("auction") || alt.includes("fundraiser") ||
        alt.includes("event") || alt.includes("benefit") || alt.includes("tournament") ||
        surroundingText.includes("gala") || surroundingText.includes("auction") ||
        surroundingText.includes("fundraiser") || surroundingText.includes("benefit");

      if (isEventRelated) {
        priorityUrls.push(absoluteUrl);
      } else {
        regularUrls.push(absoluteUrl);
      }
    } catch {
      // skip malformed
    }
  });

  // Deduplicate; event-related images first, then the rest
  return [...new Set([...priorityUrls, ...regularUrls])].slice(0, 5);
}

async function fetchImageAsBase64(url: string): Promise<{ base64: string; mimeType: string } | null> {
  try {
    const response = await got(url, {
      timeout: { request: 8000 },
      responseType: "buffer",
    });

    const contentType = (response.headers["content-type"] || "image/jpeg").split(";")[0].trim();
    if (!contentType.startsWith("image/")) return null;

    const buffer = response.body as Buffer;
    // Skip images smaller than 5KB (likely icons/spacers)
    if (buffer.length < 5000) return null;
    // Skip images larger than 4MB
    if (buffer.length > 4_000_000) return null;

    return {
      base64: buffer.toString("base64"),
      mimeType: contentType,
    };
  } catch {
    return null;
  }
}

async function extractFromImages(
  imageUrls: string[],
  client: OpenAI
): Promise<Partial<ExtractedEvent>> {
  const merged: Partial<ExtractedEvent> = {};

  // Try up to 3 images, stop after first useful result
  for (const url of imageUrls.slice(0, 3)) {
    try {
      const img = await fetchImageAsBase64(url);
      if (!img) continue;

      const response = await aiLimit(() => client.chat.completions.create({
        model: "gpt-4o",
        messages: [
          { role: "system", content: IMAGE_SYSTEM_PROMPT },
          {
            role: "user",
            content: [
              {
                type: "image_url",
                image_url: {
                  url: `data:${img.mimeType};base64,${img.base64}`,
                  detail: "low",
                },
              },
            ],
          },
        ],
        max_tokens: 600,
        response_format: { type: "json_object" },
      }));

      const raw = response.choices[0]?.message?.content;
      if (!raw) continue;

      const parsed = JSON.parse(raw) as Partial<ExtractedEvent> & { relevant?: boolean };

      // `relevant` uses OR semantics: if ANY image says true, we keep it true.
      // All other fields use first-write-wins (fill gaps only).
      if (parsed.relevant === true) {
        (merged as any).relevant = true;
      } else if (!("relevant" in merged)) {
        (merged as any).relevant = parsed.relevant ?? false;
      }

      for (const [k, v] of Object.entries(parsed)) {
        if (k === "relevant") continue; // handled above
        if (v !== null && v !== undefined && v !== "" && !(k in merged)) {
          (merged as any)[k] = v;
        }
      }

      // If we got a date and name from a relevant image, that's enough signal
      if ((merged as any).relevant === true && merged.eventDate && merged.eventName) break;
    } catch (err) {
      logger.warn({ url, err }, "Image vision extraction failed");
    }
  }

  return merged;
}

function mergeExtracted(textResult: ExtractedEvent, imageResult: Partial<ExtractedEvent>): ExtractedEvent {
  const merged = { ...textResult };
  for (const [k, v] of Object.entries(imageResult)) {
    if (v !== null && v !== undefined && v !== "") {
      const existing = (merged as any)[k];
      // Only fill in if text result has no value or has a falsy value
      if (existing === null || existing === undefined || existing === "" || existing === false) {
        (merged as any)[k] = v;
      }
    }
  }
  return merged;
}

export async function extractEventFromPage(
  pageText: string,
  pageUrl: string,
  searchKeywords: string[],
  avoidKeywords: string[],
  overrideKeywords: string[],
  pageHtml?: string,
  imageReadingEnabled?: boolean
): Promise<ExtractedEvent | null> {
  const textLower = pageText.toLowerCase();

  // Silent auction is a hard override — always send to AI regardless of avoid keywords
  const hasSilentAuctionText = textLower.includes("silent auction");

  // Check override keywords first
  const hasOverride = hasSilentAuctionText || overrideKeywords.some((k) => textLower.includes(k.toLowerCase()));

  // Keyword gate
  const hasSearch = searchKeywords.some((k) => textLower.includes(k.toLowerCase()));
  if (!hasSearch && !hasOverride) {
    return null;
  }

  // Check avoid keywords (bypassed if silent auction or other override keyword present)
  const hasAvoid = avoidKeywords.some((k) => textLower.includes(k.toLowerCase()));
  if (hasAvoid && !hasOverride) {
    return null;
  }

  const client = getOpenAIClient();
  if (!client) {
    return basicExtraction(pageText, pageUrl, searchKeywords);
  }

  // Extract page title and first heading to help the AI populate event_name
  let pageMeta = "";
  let derivedTitle = ""; // Best-guess title for fallback if AI returns no eventName
  {
    const parts: string[] = [];

    // 1. From HTML: page <title> and H1/H2
    if (pageHtml) {
      const $m = cheerio.load(pageHtml);
      const title = $m("title").text().trim();
      const h1 = $m("h1").first().text().trim();
      const h2 = $m("h2").first().text().trim();
      if (title) { parts.push(`Page title: ${title}`); if (!derivedTitle) derivedTitle = title; }
      if (h1) { parts.push(`First H1: ${h1}`); if (!derivedTitle) derivedTitle = h1; }
      else if (h2) { parts.push(`First H2: ${h2}`); if (!derivedTitle) derivedTitle = h2; }
    }

    // 2. From markdown: first # or ## heading (Firecrawl often returns clean headings here
    //    even when the HTML title tag is absent or generic)
    const mdHeadingMatch = pageText.match(/^#{1,2}\s+(.{3,80})$/m);
    if (mdHeadingMatch) {
      const mdHeading = mdHeadingMatch[1].trim();
      parts.push(`First markdown heading: ${mdHeading}`);
      if (!derivedTitle) derivedTitle = mdHeading;
    }

    // 3. URL-based fallback: turn the last path segment into Title Case
    if (!derivedTitle) {
      try {
        const segments = new URL(pageUrl).pathname.split("/").filter(Boolean);
        const last = segments[segments.length - 1] ?? "";
        derivedTitle = last
          .replace(/[-_]/g, " ")
          .replace(/\b\w/g, (c) => c.toUpperCase())
          .trim();
      } catch { /* ignore */ }
    }

    if (parts.length) pageMeta = "\n" + parts.join("\n");
  }

  try {
    const truncatedText = pageText.slice(0, 8000);
    const response = await aiLimit(() => client.chat.completions.create({
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: SYSTEM_PROMPT },
        {
          role: "user",
          content: `Page URL: ${pageUrl}${pageMeta}\n\nPage markdown:\n${truncatedText}`,
        },
      ],
      response_format: { type: "json_object" },
      max_tokens: 1200,
    }));

    const raw = response.choices[0]?.message?.content;
    if (!raw) return null;

    const textResult = JSON.parse(raw) as ExtractedEvent;

    // If AI returned no event name (null / empty / "Unknown"), fill from our derived title
    if (!textResult.eventName || textResult.eventName.toLowerCase() === "unknown") {
      textResult.eventName = derivedTitle || undefined;
    }

    let result = textResult;

    // Vision image analysis runs BEFORE the relevance gate.
    // Some pages carry event details only in flyer images; text alone may say
    // relevant=false while an image contains the date, name, and org clearly.
    if (imageReadingEnabled && pageHtml) {
      try {
        const imageUrls = extractImageUrls(pageHtml, pageUrl);
        if (imageUrls.length > 0) {
          const imageData = await extractFromImages(imageUrls, client);
          result = mergeExtracted(textResult, imageData);
          // Only override text's relevant=false if the image model itself
          // explicitly classified the image as a charity fundraiser flyer.
          // This prevents generic event images (date/name only) from
          // bypassing the charity qualification gate.
          if (textResult.relevant === false && (imageData as any).relevant === true) {
            result.relevant = true;
          }
        }
      } catch (err) {
        logger.warn({ err, pageUrl }, "Image extraction failed, using text-only result");
      }
    }

    if (result.relevant === false) return null;

    return result;
  } catch (err) {
    logger.error({ err, pageUrl }, "AI extraction failed, using fallback");
    return basicExtraction(pageText, pageUrl, searchKeywords);
  }
}

function basicExtraction(
  pageText: string,
  _pageUrl: string,
  searchKeywords: string[]
): ExtractedEvent | null {
  const textLower = pageText.toLowerCase();
  const hasSearch = searchKeywords.some((k) => textLower.includes(k.toLowerCase()));
  if (!hasSearch) return null;

  const lines = pageText.split("\n").filter((l) => l.trim().length > 20).slice(0, 5);

  const hasSilentAuction = textLower.includes("silent auction");
  const hasLiveAuction = textLower.includes("live auction");

  const ticketMatch = pageText.match(/\$\s*(\d[\d,]*)\s*(ticket|per person|per seat)/i);
  const tableMatch = pageText.match(/\$\s*(\d[\d,]*)\s*(table|sponsorship)/i);

  return {
    eventDescription: lines.join(" ").slice(0, 200),
    hasSilentAuction,
    hasLiveAuction,
    auctionType: hasSilentAuction ? "silent" : hasLiveAuction ? "live" : "none",
    ticketPrice: ticketMatch ? parseFloat(ticketMatch[1].replace(/,/g, "")) : null,
    tablePrice: tableMatch ? parseFloat(tableMatch[1].replace(/,/g, "")) : null,
    relevant: true,
  };
}
