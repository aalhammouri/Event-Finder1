import cron from "node-cron";
import { db } from "@workspace/db";
import {
  urlListsTable,
  urlListItemsTable,
  crawlRunsTable,
  eventsTable,
  emailRecipientsTable,
  adminSettingsTable,
} from "@workspace/db";
import { eq, sql, and, gte } from "drizzle-orm";
import { logger } from "../lib/logger";
import { startCrawlRun } from "../routes/crawlRuns";
import { sendWeeklyDigest } from "./emailService";

let currentTask: ReturnType<typeof cron.schedule> | null = null;

const DAY_TO_CRON: Record<string, number> = {
  sunday: 0, monday: 1, tuesday: 2, wednesday: 3,
  thursday: 4, friday: 5, saturday: 6,
};

/**
 * Builds a cron expression from the admin-configured schedule:
 * scheduleDays (e.g. ["Monday"]) + scheduleTime (e.g. "06:00").
 * Falls back to Monday 06:00 when values are missing or malformed.
 */
function buildCronExpression(days: string[] | null | undefined, time: string | null | undefined): string {
  const match = /^(\d{1,2}):(\d{2})$/.exec((time ?? "").trim());
  const hour = match ? Math.min(23, parseInt(match[1], 10)) : 6;
  const minute = match ? Math.min(59, parseInt(match[2], 10)) : 0;

  const dayNums = (days ?? [])
    .map((d) => DAY_TO_CRON[d.toLowerCase().trim()])
    .filter((n): n is number => n !== undefined);
  const dayField = dayNums.length > 0 ? [...new Set(dayNums)].sort().join(",") : "1";

  return `${minute} ${hour} * * ${dayField}`;
}

export async function initScheduler(): Promise<void> {
  await reloadSchedule();
}

/**
 * (Re)builds the cron job from the schedule settings stored in the database.
 * Called on server start and again whenever an admin saves schedule settings,
 * so changes take effect without a restart.
 */
export async function reloadSchedule(): Promise<void> {
  const [settings] = await db.select().from(adminSettingsTable).limit(1);

  if (currentTask) {
    currentTask.stop();
    currentTask = null;
  }

  if (!settings?.scheduleEnabled) {
    logger.info("Scheduler: schedule disabled — no cron job registered");
    return;
  }

  const expression = buildCronExpression(settings.scheduleDays, settings.scheduleTime);
  const timezone = settings.scheduleTimezone || "America/Chicago";

  currentTask = cron.schedule(
    expression,
    async () => {
      logger.info("Starting scheduled crawl");
      try {
        await runWeeklyJob();
      } catch (err) {
        logger.error({ err }, "Scheduled crawl job failed");
      }
    },
    { timezone }
  );

  logger.info({ expression, timezone }, "Scheduler initialized from database settings");
}

async function runWeeklyJob(): Promise<void> {
  const [settings] = await db.select().from(adminSettingsTable).limit(1);

  if (!settings?.scheduleEnabled) {
    logger.info("Scheduler: schedule is disabled, skipping");
    return;
  }

  // If a specific list is configured, crawl only that list; otherwise crawl all
  let lists: { id: number; name: string }[];
  if (settings.scheduleUrlListId) {
    const [target] = await db
      .select({ id: urlListsTable.id, name: urlListsTable.name })
      .from(urlListsTable)
      .where(eq(urlListsTable.id, settings.scheduleUrlListId))
      .limit(1);
    lists = target ? [target] : [];
    if (!target) {
      logger.warn({ listId: settings.scheduleUrlListId }, "Scheduled list not found, skipping run");
      return;
    }
  } else {
    lists = await db.select({ id: urlListsTable.id, name: urlListsTable.name }).from(urlListsTable);
  }

  for (const list of lists) {
    const items = await db
      .select({ url: urlListItemsTable.url })
      .from(urlListItemsTable)
      .where(eq(urlListItemsTable.urlListId, list.id));

    if (items.length === 0) continue;

    const [run] = await db
      .insert(crawlRunsTable)
      .values({
        urlListId: list.id,
        status: "pending",
        triggeredBy: "scheduled",
        totalUrls: items.length,
      })
      .returning();

    try {
      await startCrawlRun(run.id, items.map((i) => i.url), "scheduled");
      logger.info({ runId: run.id, listId: list.id }, "Scheduled crawl run completed");

      // Send digest for this run
      await sendDigestForRun(run.id, list.name);
    } catch (err) {
      logger.error({ err, runId: run.id }, "Scheduled crawl run failed");
    }
  }
}

async function sendDigestForRun(runId: number, listName: string): Promise<void> {
  const [settings] = await db.select().from(adminSettingsTable).limit(1);
  const minScore = settings?.minScoreForEmail ?? 45;

  const activeRecipients = await db
    .select({ email: emailRecipientsTable.email })
    .from(emailRecipientsTable)
    .where(eq(emailRecipientsTable.active, true));

  if (activeRecipients.length === 0) return;

  const newEvents = await db
    .select()
    .from(eventsTable)
    .where(
      and(
        eq(eventsTable.runId, runId),
        eq(eventsTable.status, "NEW"),
        gte(eventsTable.score, minScore)
      )
    )
    .orderBy(sql`${eventsTable.score} desc`);

  const updatedEvents = await db
    .select()
    .from(eventsTable)
    .where(
      and(
        eq(eventsTable.runId, runId),
        eq(eventsTable.status, "UPDATED"),
        gte(eventsTable.score, minScore)
      )
    )
    .orderBy(sql`${eventsTable.score} desc`);

  if (newEvents.length === 0 && updatedEvents.length === 0) return;

  await sendWeeklyDigest(
    activeRecipients.map((r) => r.email),
    {
      runDate: new Date().toLocaleDateString(),
      listName,
      newEvents: newEvents.map((e) => ({
        eventName: e.eventName,
        eventDate: e.eventDate,
        eventVenue: e.eventVenue,
        score: e.score,
        tier: e.tier,
        eventPageUrl: e.eventPageUrl,
        orgName: e.orgName,
      })),
      updatedEvents: updatedEvents.map((e) => ({
        eventName: e.eventName,
        eventDate: e.eventDate,
        eventVenue: e.eventVenue,
        score: e.score,
        tier: e.tier,
        eventPageUrl: e.eventPageUrl,
        orgName: e.orgName,
      })),
    }
  );
}
