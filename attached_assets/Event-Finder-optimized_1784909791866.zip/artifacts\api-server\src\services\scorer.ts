export interface ScoringWeights {
  hasAuction: number;
  auctionTypeBonus: number;
  highTicketPrice: number;
  midTicketPrice: number;
  lowTicketPrice: number;
  formalityBonus: number;
  timingPrime: number;
  timingGood: number;
  timingPenalty: number;
  beneficiaryBonus: number;
}

export interface TierThresholds {
  tierA: number;
  tierB: number;
}

export interface EventData {
  hasSilentAuction?: boolean | null;
  hasLiveAuction?: boolean | null;
  auctionType?: string | null;
  ticketPrice?: number | null;
  tablePrice?: number | null;
  formality?: string | null;
  eventDate?: string | null;
  orgName?: string | null;
}

const DEFAULT_WEIGHTS: ScoringWeights = {
  hasAuction: 30,
  auctionTypeBonus: 10,
  highTicketPrice: 30,
  midTicketPrice: 20,
  lowTicketPrice: 8,
  formalityBonus: 15,
  timingPrime: 25,
  timingGood: 10,
  timingPenalty: -20,
  beneficiaryBonus: 10,
};

const BENEFICIARY_KEYWORDS = [
  "hospital", "foundation", "museum", "symphony", "opera", "ballet", "university", "college"
];

export function scoreEvent(
  event: EventData,
  weights: ScoringWeights = DEFAULT_WEIGHTS,
  thresholds: TierThresholds = { tierA: 70, tierB: 45 }
): { score: number; tier: "A" | "B" | "C"; isPast: boolean } {
  let score = 0;

  // Auction presence
  if (event.hasSilentAuction || event.hasLiveAuction) {
    score += weights.hasAuction;
  }

  // Auction type bonus
  const aType = (event.auctionType || "").toLowerCase();
  if (aType === "silent" || aType === "live") {
    score += weights.auctionTypeBonus;
  }

  // Ticket / table price
  const ticket = event.ticketPrice ?? 0;
  const table = event.tablePrice ?? 0;
  if (ticket >= 500 || table >= 5000) {
    score += weights.highTicketPrice;
  } else if (ticket >= 250 || table >= 2500) {
    score += weights.midTicketPrice;
  } else if (ticket >= 100) {
    score += weights.lowTicketPrice;
  }

  // Formality
  const formality = (event.formality || "").toLowerCase();
  if (formality === "black-tie" || formality === "gala") {
    score += weights.formalityBonus;
  }

  // Timing
  const timingScore = computeTimingScore(event.eventDate, weights);
  score += timingScore;

  // Beneficiary
  const orgLower = (event.orgName || "").toLowerCase();
  if (BENEFICIARY_KEYWORDS.some((k) => orgLower.includes(k))) {
    score += weights.beneficiaryBonus;
  }

  // Cap 0-100
  score = Math.min(100, Math.max(0, score));

  const isPast = isEventPast(event.eventDate);

  return { score, tier: getTier(score, thresholds), isPast };
}

function isEventPast(eventDate: string | null | undefined): boolean {
  if (!eventDate) return false;
  try {
    const d = new Date(eventDate);
    if (isNaN(d.getTime())) return false;
    // For date-only strings (no time component), the parsed Date is midnight UTC,
    // which can mark same-day events as past. Compare against end-of-day instead.
    const isDateOnly = /^\d{4}-\d{2}-\d{2}$/.test(eventDate.trim()) ||
      /^[A-Za-z]/.test(eventDate.trim()); // e.g. "April 30, 2026"
    if (isDateOnly) {
      // End of day: set to 23:59:59 local time on the event date
      const endOfDay = new Date(d);
      endOfDay.setHours(23, 59, 59, 999);
      return endOfDay < new Date();
    }
    return d < new Date();
  } catch {
    return false;
  }
}

function computeTimingScore(eventDate: string | null | undefined, weights: ScoringWeights): number {
  if (!eventDate) return 0;
  try {
    const now = new Date();
    const date = new Date(eventDate);
    if (isNaN(date.getTime())) return 0;
    const weeksAway = (date.getTime() - now.getTime()) / (7 * 24 * 60 * 60 * 1000);

    if (weeksAway < 0) return weights.timingPenalty; // Past
    if (weeksAway < 2) return weights.timingPenalty; // Too soon
    if (weeksAway >= 6 && weeksAway <= 12) return weights.timingPrime; // Prime window
    if ((weeksAway >= 2 && weeksAway < 6) || (weeksAway > 12 && weeksAway <= 17)) {
      return weights.timingGood;
    }
    return 0;
  } catch {
    return 0;
  }
}

export function getTier(
  score: number,
  thresholds: TierThresholds = { tierA: 70, tierB: 45 }
): "A" | "B" | "C" {
  if (score >= thresholds.tierA) return "A";
  if (score >= thresholds.tierB) return "B";
  return "C";
}
