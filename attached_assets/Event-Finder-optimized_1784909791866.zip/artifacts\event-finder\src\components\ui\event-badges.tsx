import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { EventTier, EventStatus, CrawlRunStatus } from "@workspace/api-client-react";

export function TierBadge({ tier }: { tier: EventTier }) {
  const styles = {
    [EventTier.A]: "bg-amber-500 text-amber-950 border-transparent hover:bg-amber-600",
    [EventTier.B]: "bg-blue-500 text-white border-transparent hover:bg-blue-600",
    [EventTier.C]: "bg-slate-300 text-slate-800 border-transparent hover:bg-slate-400",
  };
  return <Badge className={styles[tier]}>Tier {tier}</Badge>;
}

export function StatusBadge({ status }: { status: EventStatus }) {
  const styles = {
    [EventStatus.NEW]: "bg-green-100 text-green-800 border-green-200",
    [EventStatus.UPDATED]: "bg-amber-100 text-amber-800 border-amber-200",
    [EventStatus.UNCHANGED]: "bg-slate-100 text-slate-800 border-slate-200",
  };
  return <Badge variant="outline" className={styles[status]}>{status}</Badge>;
}

export function ScorePill({ score }: { score: number }) {
  let color = "bg-slate-100 text-slate-800";
  if (score >= 70) color = "bg-green-100 text-green-800";
  else if (score >= 45) color = "bg-amber-100 text-amber-800";
  else color = "bg-red-100 text-red-800";

  return (
    <span className={cn("px-2 py-1 rounded-full text-xs font-semibold whitespace-nowrap font-mono", color)}>
      {score}
    </span>
  );
}

export function RunStatusBadge({ status }: { status: CrawlRunStatus }) {
  const styles: Record<CrawlRunStatus, string> = {
    [CrawlRunStatus.pending]: "bg-slate-100 text-slate-800",
    [CrawlRunStatus.running]: "bg-blue-100 text-blue-800 animate-pulse",
    [CrawlRunStatus.paused]: "bg-amber-100 text-amber-800",
    [CrawlRunStatus.completed]: "bg-green-100 text-green-800",
    [CrawlRunStatus.failed]: "bg-red-100 text-red-800",
    [CrawlRunStatus.stopped]: "bg-orange-100 text-orange-800",
  };
  return <Badge variant="outline" className={styles[status]}>{status.toUpperCase()}</Badge>;
}
