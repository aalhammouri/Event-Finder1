import {
  useGetCrawlRuns,
  useUpdateCrawlRun,
  useDeleteCrawlRun,
  useRerunCrawlRun,
  getGetCrawlRunsQueryKey,
  CrawlRun,
  CrawlRunStatus,
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { TierBadge, ScorePill, RunStatusBadge } from "@/components/ui/event-badges";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  ArrowLeft, Calendar, Clock, Download, ExternalLink, Loader2,
  MoreHorizontal, Archive, ArchiveX, Trash2, RefreshCw, Eye, Activity,
} from "lucide-react";
import { authFetch } from "@/lib/auth-fetch";
import { useState, useEffect, useCallback } from "react";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

function fmtDate(iso: string | null | undefined): string {
  if (!iso) return "—";
  try {
    return new Date(iso).toLocaleString("en-US", {
      month: "short", day: "numeric", year: "numeric",
      hour: "2-digit", minute: "2-digit",
    });
  } catch {
    return iso;
  }
}

function fmtEventDate(raw: string | null | undefined): string {
  if (!raw) return "—";
  try {
    const d = new Date(raw);
    if (!isNaN(d.getTime())) {
      return d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    }
  } catch {}
  return raw;
}

function AuctionBadge({ type }: { type: string | null | undefined }) {
  if (!type || type === "none") return <span className="text-muted-foreground text-xs">—</span>;
  const colors: Record<string, string> = {
    silent: "bg-purple-100 text-purple-800",
    live: "bg-orange-100 text-orange-800",
    both: "bg-indigo-100 text-indigo-800",
    online: "bg-cyan-100 text-cyan-800",
  };
  const label: Record<string, string> = {
    silent: "Silent",
    live: "Live",
    both: "Silent + Live",
    online: "Online",
  };
  const cls = colors[type.toLowerCase()] ?? "bg-gray-100 text-gray-700";
  return <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${cls}`}>{label[type.toLowerCase()] ?? type}</span>;
}

// ── Run Events Table ──────────────────────────────────────────────────────────
function RunEventsTable({ runId }: { runId: number }) {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    setLoading(true);
    const res = await authFetch(`/api/crawl-runs/${runId}/events`);
    if (res.ok) setEvents(await res.json());
    setLoading(false);
  }, [runId]);

  useEffect(() => { load(); }, [load]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-12 text-muted-foreground gap-2">
        <Loader2 className="w-4 h-4 animate-spin" /> Loading events…
      </div>
    );
  }

  if (events.length === 0) {
    return (
      <div className="text-center py-12 text-muted-foreground text-sm">No events found in this run.</div>
    );
  }

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="whitespace-nowrap text-xs">
            <TableHead className="w-14">Score</TableHead>
            <TableHead className="w-16">Tier</TableHead>
            <TableHead className="min-w-[200px]">Event</TableHead>
            <TableHead className="w-28">Date</TableHead>
            <TableHead className="min-w-[120px]">Venue</TableHead>
            <TableHead className="w-28">Auction</TableHead>
            <TableHead className="w-20">Ticket</TableHead>
            <TableHead className="w-20">Table</TableHead>
            <TableHead className="min-w-[140px]">Organization</TableHead>
            <TableHead className="min-w-[140px]">Contact</TableHead>
            <TableHead className="w-36">Found at</TableHead>
            <TableHead className="w-10"></TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {events.map((evt) => (
            <TableRow key={evt.id} className={`whitespace-nowrap align-top ${evt.isPast ? "opacity-60" : ""}`}>
              <TableCell className="pt-3"><ScorePill score={evt.score} /></TableCell>
              <TableCell className="pt-3"><TierBadge tier={evt.tier} /></TableCell>
              <TableCell className="max-w-[220px] pt-2 pb-2">
                <div className="font-medium leading-snug line-clamp-2 whitespace-normal" title={evt.eventName || ""}>
                  {evt.eventName || <span className="text-muted-foreground italic text-xs">Unnamed event</span>}
                </div>
                {evt.eventDescription && (
                  <div className="text-xs text-muted-foreground mt-1 whitespace-normal line-clamp-2 max-w-[200px]">
                    {evt.eventDescription}
                  </div>
                )}
              </TableCell>
              <TableCell className="pt-3 text-sm">{fmtEventDate(evt.eventDate)}</TableCell>
              <TableCell className="pt-2 pb-2 max-w-[160px]">
                <div className="text-sm whitespace-normal line-clamp-2">{evt.eventVenue || <span className="text-muted-foreground">—</span>}</div>
                {evt.eventAddress && <div className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{evt.eventAddress}</div>}
              </TableCell>
              <TableCell className="pt-3"><AuctionBadge type={evt.auctionType} /></TableCell>
              <TableCell className="pt-3 text-sm">{evt.ticketPrice ? `$${Number(evt.ticketPrice).toLocaleString()}` : <span className="text-muted-foreground">—</span>}</TableCell>
              <TableCell className="pt-3 text-sm">{evt.tablePrice ? `$${Number(evt.tablePrice).toLocaleString()}` : <span className="text-muted-foreground">—</span>}</TableCell>
              <TableCell className="pt-2 pb-2 max-w-[160px]">
                <div className="text-sm font-medium whitespace-normal line-clamp-2">{evt.orgName || <span className="text-muted-foreground">—</span>}</div>
                {evt.orgCity && <div className="text-xs text-muted-foreground mt-0.5">{evt.orgCity}</div>}
              </TableCell>
              <TableCell className="pt-2 pb-2 max-w-[180px]">
                {evt.contactName && <div className="text-sm font-medium">{evt.contactName}</div>}
                {evt.contactEmail && (
                  <a href={`mailto:${evt.contactEmail}`} className="text-xs text-blue-600 hover:underline block truncate">{evt.contactEmail}</a>
                )}
                {evt.contactPhone && <div className="text-xs text-muted-foreground mt-0.5">{evt.contactPhone}</div>}
                {!evt.contactName && !evt.contactEmail && !evt.contactPhone && <span className="text-muted-foreground">—</span>}
              </TableCell>
              <TableCell className="pt-3 text-xs text-muted-foreground whitespace-nowrap">
                {evt.createdAt ? fmtDate(evt.createdAt) : "—"}
              </TableCell>
              <TableCell className="pt-3">
                {evt.eventPageUrl ? (
                  <a href={evt.eventPageUrl} target="_blank" rel="noreferrer" className="text-blue-600 hover:text-blue-800">
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                ) : <span className="text-muted-foreground">—</span>}
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function runDisplayName(run: CrawlRun): string {
  try {
    const d = new Date(run.createdAt);
    const datePart = d.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" });
    const timePart = d.toLocaleTimeString("en-US", { hour: "2-digit", minute: "2-digit" });
    return `${run.urlListName} — ${datePart} ${timePart}`;
  } catch {
    return run.urlListName;
  }
}

// ── Stat Pill ─────────────────────────────────────────────────────────────────
function StatPill({ label, value, accent }: { label: string; value: number | null | undefined; accent?: "amber" | "primary" }) {
  const valueClass =
    accent === "amber" ? "text-amber-700 font-bold" :
    accent === "primary" ? "text-primary font-bold" :
    "font-bold";
  return (
    <div className="flex flex-col items-center justify-center px-4 py-2 min-w-[60px]">
      <span className={`text-base tabular-nums leading-none ${valueClass}`}>{value ?? 0}</span>
      <span className="text-[10px] text-muted-foreground mt-1 leading-none uppercase tracking-wide">{label}</span>
    </div>
  );
}

// ── Run Card ──────────────────────────────────────────────────────────────────
function RunCard({
  run,
  onView,
  onViewLive,
  onArchive,
  onDelete,
  onRerun,
}: {
  run: CrawlRun;
  onView: () => void;
  onViewLive: () => void;
  onArchive: () => void;
  onDelete: () => void;
  onRerun: () => void;
}) {
  const isActive = run.status === CrawlRunStatus.running || run.status === CrawlRunStatus.pending;
  const [showDelete, setShowDelete] = useState(false);

  return (
    <>
      <div className={`w-full bg-card border rounded-xl p-5 shadow-sm transition-all ${run.archived ? "opacity-50" : "hover:shadow-md hover:border-primary/30"}`}>
        <div className="flex items-start justify-between gap-4">
          <button className="min-w-0 flex-1 text-left" onClick={isActive ? onViewLive : onView}>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="font-semibold text-base truncate">{runDisplayName(run)}</span>
              <RunStatusBadge status={run.status} />
              {run.archived && (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded text-xs bg-muted text-muted-foreground">
                  <Archive className="w-3 h-3" /> Archived
                </span>
              )}
            </div>
            <div className="flex items-center gap-4 mt-2 text-xs text-muted-foreground flex-wrap">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" />
                Started: {fmtDate(run.createdAt)}
              </span>
              {run.completedAt && (
                <span className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {run.status === CrawlRunStatus.stopped ? "Stopped" : "Finished"}: {fmtDate(run.completedAt)}
                </span>
              )}
              {isActive && (
                <span className="flex items-center gap-1 text-blue-600 animate-pulse">
                  <Loader2 className="w-3 h-3 animate-spin" /> In progress — click to view live
                </span>
              )}
            </div>
          </button>

          <div className="flex items-center gap-3 shrink-0">
            {/* Stats strip — hidden on xs */}
            <div className="hidden sm:flex items-stretch divide-x divide-border border rounded-lg overflow-hidden bg-muted/40">
              <StatPill label="URLs" value={run.totalUrls} />
              <StatPill label="Pages" value={run.pagesCrawled} />
              <StatPill label="Events" value={run.eventsMatched} accent="amber" />
              {run.topScore != null && (
                <StatPill label="Top Score" value={run.topScore} accent="primary" />
              )}
            </div>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-8 w-8 shrink-0">
                  <MoreHorizontal className="w-4 h-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-44">
                {isActive ? (
                  <DropdownMenuItem onClick={onViewLive}>
                    <Activity className="w-4 h-4 mr-2" /> View live run
                  </DropdownMenuItem>
                ) : (
                  <DropdownMenuItem onClick={onView}>
                    <Eye className="w-4 h-4 mr-2" /> View results
                  </DropdownMenuItem>
                )}
                <DropdownMenuItem onClick={onRerun}>
                  <RefreshCw className="w-4 h-4 mr-2" /> Re-run
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={onArchive}>
                  {run.archived
                    ? <><ArchiveX className="w-4 h-4 mr-2" /> Unarchive</>
                    : <><Archive className="w-4 h-4 mr-2" /> Archive</>
                  }
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem
                  onClick={() => setShowDelete(true)}
                  className="text-red-600 focus:text-red-600"
                >
                  <Trash2 className="w-4 h-4 mr-2" /> Delete run
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </div>

      <AlertDialog open={showDelete} onOpenChange={setShowDelete}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete this run?</AlertDialogTitle>
            <AlertDialogDescription>
              This permanently deletes the run and all its results. This cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-red-600 hover:bg-red-700"
              onClick={() => { setShowDelete(false); onDelete(); }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
}

// ── Main Component ────────────────────────────────────────────────────────────
export default function Results() {
  const [selectedRunId, setSelectedRunId] = useState<number | null>(null);
  const [showArchived, setShowArchived] = useState(false);
  const [, setLocation] = useLocation();
  const qc = useQueryClient();
  const { toast } = useToast();

  const { data: allRuns, isLoading } = useGetCrawlRuns(showArchived ? { includeArchived: true } as any : {});

  const archiveMutation = useUpdateCrawlRun({
    mutation: { onSuccess: () => qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() }) },
  });
  const deleteMutation = useDeleteCrawlRun({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() });
        toast({ title: "Run deleted" });
      },
    },
  });
  const rerunMutation = useRerunCrawlRun({
    mutation: {
      onSuccess: (newRun) => {
        qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() });
        setLocation(`/runs/${newRun.id}`);
      },
    },
  });

  const runs = allRuns;
  const selectedRun = runs?.find((r) => r.id === selectedRunId);

  if (selectedRunId && selectedRun) {
    const isActive = selectedRun.status === CrawlRunStatus.running || selectedRun.status === CrawlRunStatus.pending;
    return (
      <div className="space-y-6">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => setSelectedRunId(null)}>
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1 min-w-0">
            <h1 className="text-2xl font-bold truncate">{selectedRun.urlListName}</h1>
            <p className="text-sm text-muted-foreground">
              {fmtDate(selectedRun.createdAt)}
              {selectedRun.completedAt ? ` — ${fmtDate(selectedRun.completedAt)}` : ""}
              {" · "}{selectedRun.eventsMatched} event{selectedRun.eventsMatched !== 1 ? "s" : ""} found
            </p>
          </div>
          <RunStatusBadge status={selectedRun.status} />
          {isActive ? (
            <Button variant="outline" onClick={() => setLocation(`/runs/${selectedRun.id}`)}>
              <Activity className="w-4 h-4 mr-2" /> View live run
            </Button>
          ) : (
            <Button
              variant="outline"
              onClick={() => window.open(`/api/events/export?runId=${selectedRunId}`, "_blank")}
            >
              <Download className="w-4 h-4 mr-2" /> Export CSV
            </Button>
          )}
        </div>

        {isActive ? (
          <div className="text-center py-16 text-muted-foreground">
            <Loader2 className="w-6 h-6 animate-spin mx-auto mb-3" />
            <p className="font-medium">This run is in progress.</p>
            <p className="text-sm mt-1">Results will appear here once the crawl completes.</p>
          </div>
        ) : (
          <div className="bg-card rounded-md border shadow-sm">
            <RunEventsTable runId={selectedRunId} />
          </div>
        )}
      </div>
    );
  }

  const activeRuns = runs?.filter((r) => r.status === CrawlRunStatus.running || r.status === CrawlRunStatus.pending) ?? [];
  const finishedRuns = runs?.filter((r) => r.status !== CrawlRunStatus.running && r.status !== CrawlRunStatus.pending) ?? [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between gap-4">
        <h1 className="text-3xl font-bold tracking-tight">Results</h1>
        <button
          onClick={() => setShowArchived((v) => !v)}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm border transition-colors ${
            showArchived
              ? "bg-amber-50 border-amber-300 text-amber-800"
              : "bg-white border-gray-200 text-muted-foreground hover:border-gray-300"
          }`}
        >
          <Archive className="w-3.5 h-3.5" />
          {showArchived ? "Hide archived" : "Show archived"}
        </button>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center py-16 text-muted-foreground gap-2">
          <Loader2 className="w-5 h-5 animate-spin" /> Loading runs…
        </div>
      ) : (
        <>
          {activeRuns.length > 0 && (
            <div className="space-y-3">
              <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider">In Progress</h2>
              {activeRuns.map((run) => (
                <RunCard
                  key={run.id}
                  run={run}
                  onView={() => setSelectedRunId(run.id)}
                  onViewLive={() => setLocation(`/runs/${run.id}`)}
                  onArchive={() => archiveMutation.mutate({ id: run.id, data: { archived: !run.archived } })}
                  onDelete={() => deleteMutation.mutate({ id: run.id })}
                  onRerun={() => rerunMutation.mutate({ id: run.id })}
                />
              ))}
            </div>
          )}

          {finishedRuns.length > 0 && (
            <div className="space-y-3">
              {activeRuns.length > 0 && (
                <h2 className="text-sm font-semibold text-muted-foreground uppercase tracking-wider mt-2">Completed</h2>
              )}
              {finishedRuns.map((run) => (
                <RunCard
                  key={run.id}
                  run={run}
                  onView={() => setSelectedRunId(run.id)}
                  onViewLive={() => setLocation(`/runs/${run.id}`)}
                  onArchive={() => archiveMutation.mutate({ id: run.id, data: { archived: !run.archived } })}
                  onDelete={() => deleteMutation.mutate({ id: run.id })}
                  onRerun={() => rerunMutation.mutate({ id: run.id })}
                />
              ))}
            </div>
          )}

          {!runs?.length && (
            <div className="text-center py-16 text-muted-foreground">
              <p className="text-lg font-medium mb-1">No runs yet</p>
              <p className="text-sm">Start a crawl from the Import Data page to see results here.</p>
            </div>
          )}
        </>
      )}
    </div>
  );
}
