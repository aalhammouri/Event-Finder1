import { useParams, useLocation } from "wouter";
import { useGetCrawlRun, useStopCrawlRun, getGetCrawlRunQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { authFetch, sseUrl } from "@/lib/auth-fetch";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { ArrowLeft, Globe, FileText, AlertTriangle, CheckCircle2, Loader2, StopCircle, PauseCircle, PlayCircle, Zap, ExternalLink } from "lucide-react";
import { RunStatusBadge, TierBadge, ScorePill } from "@/components/ui/event-badges";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { useEffect, useRef, useState, useCallback } from "react";
import { cn } from "@/lib/utils";

// ── Types ─────────────────────────────────────────────────────────────────────
type LogEntry = { ts: string; type: string; url?: string; msg: string; score?: number };
type LiveStats = { pagesCrawled: number; eventsMatched: number; errorCount: number; done: number; total: number };

// ── Log entry styling ─────────────────────────────────────────────────────────
function logIcon(type: string) {
  switch (type) {
    case "event_found": return <Zap className="w-3.5 h-3.5 text-amber-500 shrink-0 mt-0.5" />;
    case "error":       return <AlertTriangle className="w-3.5 h-3.5 text-red-500 shrink-0 mt-0.5" />;
    case "url_done":    return <CheckCircle2 className="w-3.5 h-3.5 text-green-500 shrink-0 mt-0.5" />;
    case "complete":    return <CheckCircle2 className="w-3.5 h-3.5 text-green-600 shrink-0 mt-0.5" />;
    case "url_start":   return <Globe className="w-3.5 h-3.5 text-blue-500 shrink-0 mt-0.5" />;
    default:            return <div className="w-1.5 h-1.5 rounded-full bg-muted-foreground/40 shrink-0 mt-1.5 ml-1" />;
  }
}

function logRowClass(type: string) {
  switch (type) {
    case "event_found": return "bg-amber-50/60 border-l-2 border-amber-400";
    case "error":       return "bg-red-50/60 border-l-2 border-red-400";
    case "url_done":    return "border-l-2 border-green-400";
    case "complete":    return "bg-green-50/60 border-l-2 border-green-500 font-medium";
    case "url_start":   return "border-l-2 border-blue-400";
    default:            return "border-l-2 border-transparent";
  }
}

function fmtTime(ts: string) {
  try { return new Date(ts).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit", second: "2-digit" }); }
  catch { return ts; }
}

// ── Activity Log Panel ────────────────────────────────────────────────────────
function ActivityLog({ entries, isLive }: { entries: LogEntry[]; isLive: boolean }) {
  const bottomRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [autoScroll, setAutoScroll] = useState(true);

  useEffect(() => {
    if (autoScroll && bottomRef.current) {
      bottomRef.current.scrollIntoView({ behavior: "smooth" });
    }
  }, [entries, autoScroll]);

  const handleScroll = () => {
    const el = containerRef.current;
    if (!el) return;
    const atBottom = el.scrollHeight - el.scrollTop - el.clientHeight < 50;
    setAutoScroll(atBottom);
  };

  if (entries.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-48 text-muted-foreground text-sm gap-2">
        {isLive ? <><Loader2 className="w-5 h-5 animate-spin" /> Waiting for crawl activity…</> : "No log entries recorded."}
      </div>
    );
  }

  return (
    <div className="relative">
      {isLive && (
        <div className="flex items-center gap-1.5 text-xs text-green-600 font-medium mb-2">
          <span className="inline-block w-2 h-2 rounded-full bg-green-500 animate-pulse" />
          Live — streaming activity
        </div>
      )}
      <div
        ref={containerRef}
        onScroll={handleScroll}
        tabIndex={-1}
        className="h-[480px] overflow-y-auto rounded-lg bg-muted/20 font-mono text-xs space-y-0.5 p-1 outline-none focus:outline-none [&::-webkit-scrollbar]:w-1.5 [&::-webkit-scrollbar-thumb]:rounded-full [&::-webkit-scrollbar-thumb]:bg-border [&::-webkit-scrollbar-track]:bg-transparent"
      >
        {entries.map((entry, i) => (
          <div key={i} className={cn("flex gap-2 items-start px-2 py-1 rounded-sm", logRowClass(entry.type))}>
            {logIcon(entry.type)}
            <span className="text-muted-foreground shrink-0 tabular-nums">{fmtTime(entry.ts)}</span>
            <span className={cn("break-all", entry.type === "error" ? "text-red-700" : entry.type === "event_found" ? "text-amber-800 font-medium" : "text-foreground/80")}>
              {entry.msg}
              {entry.score !== undefined && (
                <span className="ml-2 px-1.5 py-0.5 rounded bg-amber-100 text-amber-700 text-[10px] font-bold not-italic">score {entry.score}</span>
              )}
            </span>
          </div>
        ))}
        <div ref={bottomRef} />
      </div>
      {!autoScroll && isLive && (
        <button
          onClick={() => { setAutoScroll(true); bottomRef.current?.scrollIntoView({ behavior: "smooth" }); }}
          className="absolute bottom-3 right-3 text-xs bg-primary text-primary-foreground px-2 py-1 rounded shadow"
        >
          ↓ Jump to bottom
        </button>
      )}
    </div>
  );
}

// ── Events Table ──────────────────────────────────────────────────────────────
function EventsTable({ runId, isActive }: { runId: number; isActive?: boolean }) {
  const [events, setEvents] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const res = await authFetch(`/api/crawl-runs/${runId}/events`);
    if (res.ok) setEvents(await res.json());
    setLoading(false);
  }, [runId]);

  useEffect(() => {
    load();
    if (!isActive) return;
    // Poll every 5 s while the run is live so new events appear without a refresh
    const timer = setInterval(load, 5000);
    return () => clearInterval(timer);
  }, [load, isActive]);

  if (loading) return <div className="text-muted-foreground text-sm py-8 text-center"><Loader2 className="w-4 h-4 animate-spin inline mr-2" />Loading events…</div>;

  if (events.length === 0) return (
    <div className="text-center py-12 text-muted-foreground text-sm">No events found in this run yet.</div>
  );

  function fmtFoundAt(iso: string) {
    try { return new Date(iso).toLocaleString("en-US", { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit" }); }
    catch { return iso; }
  }

  return (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead className="w-16">Score</TableHead>
          <TableHead className="w-16">Tier</TableHead>
          <TableHead>Event Name</TableHead>
          <TableHead>Org</TableHead>
          <TableHead>Date</TableHead>
          <TableHead>Venue</TableHead>
          <TableHead className="w-36">Found at</TableHead>
          <TableHead className="w-10"></TableHead>
        </TableRow>
      </TableHeader>
      <TableBody>
        {events.map((evt) => (
          <TableRow key={evt.id}>
            <TableCell><ScorePill score={evt.score} /></TableCell>
            <TableCell><TierBadge tier={evt.tier} /></TableCell>
            <TableCell className="font-medium max-w-[220px] truncate">{evt.eventName || "—"}</TableCell>
            <TableCell className="text-muted-foreground text-sm max-w-[160px] truncate">{evt.orgName || "—"}</TableCell>
            <TableCell className="text-sm">{evt.eventDate || "—"}</TableCell>
            <TableCell className="text-sm max-w-[160px] truncate">{evt.eventVenue || "—"}</TableCell>
            <TableCell className="text-xs text-muted-foreground whitespace-nowrap">
              {evt.createdAt ? fmtFoundAt(evt.createdAt) : "—"}
            </TableCell>
            <TableCell>
              {evt.eventPageUrl && (
                <a href={evt.eventPageUrl} target="_blank" rel="noopener noreferrer" className="text-primary hover:text-primary/80">
                  <ExternalLink className="w-3.5 h-3.5" />
                </a>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );
}

// ── Stat Card ─────────────────────────────────────────────────────────────────
function StatCard({ label, value, sub, warn }: { label: string; value: number | string; sub?: string; warn?: boolean }) {
  return (
    <div className="bg-card border rounded-xl p-4 shadow-sm">
      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wide mb-1">{label}</p>
      <p className={cn("text-3xl font-bold tabular-nums", warn && Number(value) > 0 ? "text-red-500" : "")}>{value}</p>
      {sub && <p className="text-xs text-muted-foreground mt-1">{sub}</p>}
    </div>
  );
}

// ── Main Page ─────────────────────────────────────────────────────────────────
export default function RunDetail() {
  const { id } = useParams();
  const runId = Number(id);
  const [, setLocation] = useLocation();
  const qc = useQueryClient();

  const { data: run, isLoading } = useGetCrawlRun(runId, {
    query: {
      enabled: !!runId,
      queryKey: getGetCrawlRunQueryKey(runId),
      refetchInterval: (q) => {
        const status = (q.state.data as any)?.status;
        return status === "running" || status === "pending" ? 3000 : false;
      },
    },
  });

  const isActive = run?.status === "running" || run?.status === "pending";
  const isPaused = run?.status === "paused";

  const stopMutation = useStopCrawlRun({
    mutation: {
      onSuccess: () => {
        qc.invalidateQueries({ queryKey: getGetCrawlRunQueryKey(runId) });
      },
    },
  });

  const [pauseResumePending, setPauseResumePending] = useState(false);
  const pauseOrResume = useCallback(async (action: "pause" | "resume") => {
    setPauseResumePending(true);
    try {
      await authFetch(`/api/crawl-runs/${runId}/${action}`, { method: "POST" });
      qc.invalidateQueries({ queryKey: getGetCrawlRunQueryKey(runId) });
    } finally {
      setPauseResumePending(false);
    }
  }, [runId, qc]);

  // Live stats from SSE
  const [liveLog, setLiveLog] = useState<LogEntry[]>([]);
  const [liveStats, setLiveStats] = useState<LiveStats>({ pagesCrawled: 0, eventsMatched: 0, errorCount: 0, done: 0, total: 0 });
  const [currentUrl, setCurrentUrl] = useState<string>("");
  const [sseConnected, setSseConnected] = useState(false);

  // Stored log for completed runs
  const [storedLog, setStoredLog] = useState<LogEntry[]>([]);
  const [logLoaded, setLogLoaded] = useState(false);

  // Connect SSE when run is active
  useEffect(() => {
    if (!runId || !isActive) return;

    const es = new EventSource(sseUrl(`/api/crawl-runs/${runId}/progress`));
    setSseConnected(true);

    es.onmessage = (e) => {
      const ev = JSON.parse(e.data) as any;

      // Bulk replay of historical log entries (preserves original ts + msg)
      if (ev.type === "log_replay") {
        if (Array.isArray(ev.entries)) {
          const entries = ev.entries as LogEntry[];
          setLiveLog((prev) => [...prev, ...entries]);

          // Seed progress counters from the replayed history so the progress bar
          // shows correct values immediately after reconnection instead of "Starting up..."
          const doneCount = entries.filter((e) => e.type === "url_done").length;
          const lastStart = [...entries].reverse().find((e) => e.type === "url_start");
          if (doneCount > 0) {
            setLiveStats((p) => ({ ...p, done: Math.max(p.done, doneCount) }));
          }
          if (lastStart?.url) {
            setCurrentUrl(lastStart.url);
          }
        }
        return;
      }

      // Build log entry from live events
      const entry: LogEntry = {
        ts: new Date().toISOString(),
        type: ev.type,
        url: ev.url ?? ev.pageUrl,
        msg: "",
        score: ev.score,
      };
      switch (ev.type) {
        case "url_start":
          entry.msg = ev.url ? `Starting crawl of ${ev.url}` : "Crawl run started";
          if (ev.url) setCurrentUrl(ev.url);
          break;
        case "page_crawled":
          entry.msg = `Crawled: ${ev.pageUrl ?? ""}`;
          setLiveStats((p) => ({ ...p, pagesCrawled: p.pagesCrawled + 1, done: ev.progress?.done ?? p.done, total: ev.progress?.total ?? p.total }));
          break;
        case "event_found":
          entry.msg = `Found event: "${ev.eventName ?? "Unknown"}"`;
          setLiveStats((p) => ({ ...p, eventsMatched: p.eventsMatched + 1 }));
          break;
        case "error":
          entry.msg = `Error on ${ev.url ?? "unknown"}: ${ev.errorMessage ?? ""}`;
          setLiveStats((p) => ({ ...p, errorCount: p.errorCount + 1 }));
          break;
        case "url_done":
          entry.msg = `Finished: ${ev.url}`;
          setLiveStats((p) => ({ ...p, done: ev.progress?.done ?? p.done, total: ev.progress?.total ?? p.total }));
          setCurrentUrl("");
          break;
        case "complete":
          entry.msg = "Crawl run complete";
          qc.invalidateQueries({ queryKey: getGetCrawlRunQueryKey(runId) });
          es.close();
          setSseConnected(false);
          break;
        default:
          entry.msg = JSON.stringify(ev);
      }
      setLiveLog((prev) => [...prev, entry]);
    };

    es.onerror = () => {
      setSseConnected(false);
      es.close();
    };

    return () => { es.close(); setSseConnected(false); };
  }, [runId, isActive]);

  // Load stored log for completed/failed runs
  useEffect(() => {
    if (!runId || isActive || logLoaded) return;
    authFetch(`/api/crawl-runs/${runId}/logs`)
      .then((r) => r.json())
      .then((data) => { setStoredLog(Array.isArray(data) ? data : []); setLogLoaded(true); });
  }, [runId, isActive, logLoaded]);

  // Sync initial live stats from run data
  useEffect(() => {
    if (run && isActive) {
      setLiveStats((p) => ({
        ...p,
        pagesCrawled: Math.max(p.pagesCrawled, run.pagesCrawled ?? 0),
        eventsMatched: Math.max(p.eventsMatched, run.eventsMatched ?? 0),
        errorCount: Math.max(p.errorCount, run.errorCount ?? 0),
        total: run.totalUrls ?? 0,
      }));
    }
  }, [run]);

  if (isLoading) return <div className="flex items-center gap-2 p-8 text-muted-foreground"><Loader2 className="w-4 h-4 animate-spin" /> Loading run…</div>;
  if (!run) return <div className="p-8 text-muted-foreground">Run not found.</div>;

  const displayPages = isActive ? liveStats.pagesCrawled : (run.pagesCrawled ?? 0);
  const displayEvents = isActive ? liveStats.eventsMatched : (run.eventsMatched ?? 0);
  const displayErrors = isActive ? liveStats.errorCount : (run.errorCount ?? 0);
  const progressTotal = run.totalUrls ?? liveStats.total;
  const progressDone = isActive ? liveStats.done : progressTotal;
  const progressPct = progressTotal > 0 ? Math.round((progressDone / progressTotal) * 100) : 0;

  const duration = run.completedAt && run.createdAt
    ? Math.round((new Date(run.completedAt).getTime() - new Date(run.createdAt).getTime()) / 1000)
    : null;

  const displayLog = isActive ? liveLog : storedLog;

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-3">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/runs")}>
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <div className="flex-1 min-w-0">
          <h1 className="text-2xl font-bold truncate">{run.urlListName}</h1>
          <p className="text-sm text-muted-foreground">
            {run.triggeredBy === "scheduled" ? "Scheduled" : "Manual"} run · Started {new Date(run.createdAt).toLocaleString()}
          </p>
        </div>
        <RunStatusBadge status={run.status} />
        {isActive && (
          <Button
            variant="outline"
            size="sm"
            disabled={pauseResumePending}
            className="flex items-center gap-1.5"
            onClick={() => pauseOrResume("pause")}
          >
            <PauseCircle className="w-4 h-4" />
            Pause
          </Button>
        )}
        {isPaused && (
          <Button
            variant="default"
            size="sm"
            disabled={pauseResumePending}
            className="flex items-center gap-1.5"
            onClick={() => pauseOrResume("resume")}
          >
            <PlayCircle className="w-4 h-4" />
            Resume
          </Button>
        )}
        {isActive && (
          <AlertDialog>
            <AlertDialogTrigger asChild>
              <Button
                variant="destructive"
                size="sm"
                disabled={stopMutation.isPending}
                className="flex items-center gap-1.5"
              >
                <StopCircle className="w-4 h-4" />
                Stop
              </Button>
            </AlertDialogTrigger>
            <AlertDialogContent>
              <AlertDialogHeader>
                <AlertDialogTitle>Stop this run?</AlertDialogTitle>
                <AlertDialogDescription>
                  The crawl will finish its current URL, then stop. All results collected so far will be saved.
                </AlertDialogDescription>
              </AlertDialogHeader>
              <AlertDialogFooter>
                <AlertDialogCancel>Cancel</AlertDialogCancel>
                <AlertDialogAction
                  className="bg-red-600 hover:bg-red-700"
                  onClick={() => stopMutation.mutate({ id: runId })}
                >
                  Stop run
                </AlertDialogAction>
              </AlertDialogFooter>
            </AlertDialogContent>
          </AlertDialog>
        )}
      </div>

      {/* Progress bar — shown when active */}
      {isActive && (
        <div className="bg-card border rounded-xl p-4 shadow-sm space-y-2">
          <div className="flex items-center justify-between text-sm">
            <span className="flex items-center gap-2 font-medium">
              <Loader2 className="w-4 h-4 animate-spin text-primary" />
              {currentUrl ? (
                <span className="text-muted-foreground truncate max-w-[500px]">Crawling: <span className="text-foreground font-mono text-xs">{currentUrl}</span></span>
              ) : "Starting up…"}
            </span>
            <span className="text-muted-foreground tabular-nums">{progressDone} / {progressTotal} sites</span>
          </div>
          <Progress value={progressPct} className="h-2" />
          <p className="text-xs text-muted-foreground text-right">{progressPct}% complete</p>
        </div>
      )}

      {/* Stat Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard label="Pages Crawled" value={displayPages} />
        <StatCard label="Events Found" value={displayEvents} />
        <StatCard label="Errors" value={displayErrors} warn />
        <StatCard
          label="Duration"
          value={duration !== null ? `${duration}s` : isActive ? "—" : "—"}
          sub={duration !== null ? `${Math.floor(duration / 60)}m ${duration % 60}s` : undefined}
        />
      </div>

      {/* Tabs */}
      <Tabs defaultValue="log">
        <TabsList>
          <TabsTrigger value="log" className="flex items-center gap-1.5">
            <FileText className="w-4 h-4" />
            Activity Log
            {isActive && liveLog.length > 0 && (
              <span className="ml-1 px-1.5 py-0.5 rounded-full bg-primary text-primary-foreground text-[10px] font-bold tabular-nums">{liveLog.length}</span>
            )}
          </TabsTrigger>
          <TabsTrigger value="events" className="flex items-center gap-1.5">
            <Zap className="w-4 h-4" />
            Events Found
            <span className="ml-1 px-1.5 py-0.5 rounded-full bg-muted text-muted-foreground text-[10px] font-bold tabular-nums">{displayEvents}</span>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="log" className="mt-4">
          <ActivityLog entries={displayLog} isLive={isActive && sseConnected} />
        </TabsContent>

        <TabsContent value="events" className="mt-4">
          <div className="border rounded-xl overflow-hidden">
            <EventsTable runId={runId} isActive={isActive} />
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}
