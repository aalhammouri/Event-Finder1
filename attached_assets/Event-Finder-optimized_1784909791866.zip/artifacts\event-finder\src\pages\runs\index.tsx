import {
  useGetCrawlRuns,
  useUpdateCrawlRun,
  useDeleteCrawlRun,
  useRerunCrawlRun,
  getGetCrawlRunsQueryKey,
  CrawlRun,
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { useLocation } from "wouter";
import { useQueryClient } from "@tanstack/react-query";
import { RunStatusBadge } from "@/components/ui/event-badges";
import { Archive, ArchiveX, Eye, RefreshCw, Trash2 } from "lucide-react";
import { useState } from "react";

function fmtDate(iso: string) {
  return new Date(iso).toLocaleString("en-US", {
    month: "short", day: "numeric", year: "numeric",
    hour: "2-digit", minute: "2-digit",
  });
}

export default function RunHistory() {
  const [showArchived, setShowArchived] = useState(false);
  const { data: runs, isLoading } = useGetCrawlRuns(showArchived ? { includeArchived: true } : {});
  const [, setLocation] = useLocation();
  const qc = useQueryClient();

  const archiveMutation = useUpdateCrawlRun({
    mutation: {
      onSuccess: () => qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() }),
    },
  });

  const deleteMutation = useDeleteCrawlRun({
    mutation: {
      onSuccess: () => qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() }),
    },
  });

  const rerunMutation = useRerunCrawlRun({
    mutation: {
      onSuccess: (newRun) => {
        qc.invalidateQueries({ queryKey: getGetCrawlRunsQueryKey() });
        setLocation(`/runs/${newRun.id}`);
      },
    },
  });

  const handleArchive = (run: CrawlRun) => {
    archiveMutation.mutate({ id: run.id, data: { archived: !run.archived } });
  };

  const handleDelete = (id: number) => {
    deleteMutation.mutate({ id });
  };

  const handleRerun = (id: number) => {
    rerunMutation.mutate({ id });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold tracking-tight">Run History</h1>
        <button
          onClick={() => setShowArchived((v) => !v)}
          className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md text-sm border transition-colors ${
            showArchived
              ? "bg-amber-50 border-amber-300 text-amber-800"
              : "bg-white border-gray-200 text-muted-foreground hover:border-gray-300"
          }`}
        >
          <Archive className="w-3.5 h-3.5" />
          {showArchived ? "Hiding archived" : "Show archived"}
        </button>
      </div>

      <div className="bg-card rounded-md border shadow-sm">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Started</TableHead>
              <TableHead>Finished</TableHead>
              <TableHead>List</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="text-right">Crawled / Total</TableHead>
              <TableHead className="text-right">Events</TableHead>
              <TableHead className="text-right">Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="text-center py-8">Loading...</TableCell></TableRow>
            ) : runs?.length ? (
              runs.map((run) => (
                <TableRow key={run.id} className={run.archived ? "opacity-50" : ""}>
                  <TableCell className="text-sm whitespace-nowrap">{fmtDate(run.createdAt)}</TableCell>
                  <TableCell className="text-sm whitespace-nowrap text-muted-foreground">
                    {run.completedAt ? fmtDate(run.completedAt) : "—"}
                  </TableCell>
                  <TableCell className="font-medium max-w-[160px] truncate">{run.urlListName}</TableCell>
                  <TableCell><RunStatusBadge status={run.status} /></TableCell>
                  <TableCell className="text-right tabular-nums">
                    {run.pagesCrawled}<span className="text-muted-foreground">/{run.totalUrls}</span>
                  </TableCell>
                  <TableCell className="text-right font-semibold">{run.eventsMatched}</TableCell>
                  <TableCell>
                    <div className="flex items-center justify-end gap-1">
                      <Button
                        variant="ghost"
                        size="icon"
                        title="View run"
                        onClick={() => setLocation(`/runs/${run.id}`)}
                      >
                        <Eye className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="icon"
                        title="Re-run"
                        disabled={rerunMutation.isPending}
                        onClick={() => handleRerun(run.id)}
                      >
                        <RefreshCw className="w-4 h-4" />
                      </Button>

                      <Button
                        variant="ghost"
                        size="icon"
                        title={run.archived ? "Unarchive" : "Archive"}
                        onClick={() => handleArchive(run)}
                      >
                        {run.archived ? <ArchiveX className="w-4 h-4" /> : <Archive className="w-4 h-4" />}
                      </Button>

                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" title="Delete run" className="text-red-500 hover:text-red-700 hover:bg-red-50">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Delete this run?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete this run and all its results. This cannot be undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction
                              className="bg-red-600 hover:bg-red-700"
                              onClick={() => handleDelete(run.id)}
                            >
                              Delete
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))
            ) : (
              <TableRow>
                <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                  {showArchived ? "No runs yet." : "No runs yet. Archived runs are hidden — toggle above to show them."}
                </TableCell>
              </TableRow>
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
