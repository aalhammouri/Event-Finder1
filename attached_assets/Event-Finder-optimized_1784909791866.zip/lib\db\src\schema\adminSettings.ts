import { pgTable, serial, text, integer, boolean, jsonb, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const adminSettingsTable = pgTable("admin_settings", {
  id: serial("id").primaryKey(),
  searchKeywords: text("search_keywords").array().notNull().default([
    "silent auction", "live auction", "online auction", "raffle", "golf",
    "benefit auction", "auction items", "fundraiser", "fundraising event",
    "benefit dinner", "charity", "gala", "black-tie", "gala dinner",
    "church fundraiser"
  ]),
  avoidKeywords: text("avoid_keywords").array().notNull().default([
    "bingo", "walk", "wine", "arts", "art silent auction", "fashion show", "outdoor event"
  ]),
  overrideKeywords: text("override_keywords").array().notNull().default(["silent auction"]),
  maxPagesPerSite: integer("max_pages_per_site").notNull().default(30),
  timeoutPerPage: integer("timeout_per_page").notNull().default(30),
  // Scale/politeness controls: how many sites are crawled in parallel, the
  // minimum gap between requests to the same domain, and how many times a
  // failed fetch is retried (exponential backoff) before giving up.
  maxConcurrentSites: integer("max_concurrent_sites").notNull().default(5),
  perDomainDelayMs: integer("per_domain_delay_ms").notNull().default(1000),
  maxRetries: integer("max_retries").notNull().default(3),
  imageReadingEnabled: boolean("image_reading_enabled").notNull().default(true),
  scoringWeights: jsonb("scoring_weights").notNull().default({
    hasAuction: 30,
    auctionTypeBonus: 10,
    highTicketPrice: 30,
    midTicketPrice: 20,
    lowTicketPrice: 8,
    formalityBonus: 15,
    timingPrime: 25,
    timingGood: 10,
    timingPenalty: -20,
    beneficiaryBonus: 10,
  }),
  tierThresholds: jsonb("tier_thresholds").notNull().default({ tierA: 70, tierB: 45 }),
  minScoreForEmail: integer("min_score_for_email").notNull().default(45),
  scheduleEnabled: boolean("schedule_enabled").notNull().default(false),
  scheduleDays: text("schedule_days").array().notNull().default(["Monday"]),
  scheduleTime: text("schedule_time").notNull().default("06:00"),
  scheduleTimezone: text("schedule_timezone").notNull().default("America/Chicago"),
  scheduleUrlListId: integer("schedule_url_list_id"),
  updatedAt: timestamp("updated_at", { withTimezone: true }).notNull().defaultNow().$onUpdate(() => new Date()),
});

export const emailRecipientsTable = pgTable("email_recipients", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  active: boolean("active").notNull().default(true),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const domainBlacklistTable = pgTable("domain_blacklist", {
  id: serial("id").primaryKey(),
  domain: text("domain").notNull().unique(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AdminSettings = typeof adminSettingsTable.$inferSelect;
export type EmailRecipient = typeof emailRecipientsTable.$inferSelect;
export type BlacklistedDomain = typeof domainBlacklistTable.$inferSelect;
