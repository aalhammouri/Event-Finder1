import { pgTable, serial, integer, text, boolean, numeric, timestamp, index } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { crawlRunsTable } from "./crawlRuns";

export const eventsTable = pgTable("events", {
  id: serial("id").primaryKey(),
  runId: integer("run_id").notNull().references(() => crawlRunsTable.id, { onDelete: "cascade" }),
  score: integer("score").notNull().default(0),
  tier: text("tier", { enum: ["A", "B", "C"] }).notNull().default("C"),
  status: text("status", { enum: ["NEW", "UPDATED", "UNCHANGED"] }).notNull().default("NEW"),

  // Event info
  eventName: text("event_name"),
  eventDate: text("event_date"),
  eventVenue: text("event_venue"),
  eventAddress: text("event_address"),
  eventDescription: text("event_description"),
  auctionType: text("auction_type"),
  hasSilentAuction: boolean("has_silent_auction"),
  hasLiveAuction: boolean("has_live_auction"),
  ticketPrice: numeric("ticket_price", { precision: 10, scale: 2 }),
  tablePrice: numeric("table_price", { precision: 10, scale: 2 }),
  formality: text("formality"),
  rsvpLink: text("rsvp_link"),
  contactName: text("contact_name"),
  contactEmail: text("contact_email"),
  contactPhone: text("contact_phone"),
  eventPageUrl: text("event_page_url"),
  audienceNote: text("audience_note"),
  sponsorshipMentioned: boolean("sponsorship_mentioned"),

  // Org info
  orgName: text("org_name"),
  orgAddress: text("org_address"),
  orgCity: text("org_city"),
  orgPhone: text("org_phone"),
  orgEmail: text("org_email"),
  orgWebsite: text("org_website"),

  isPast: boolean("is_past").notNull().default(false),
  errorMessage: text("error_message"),

  // Cross-run dedupe: stable identity key (hash of name+date+domain, or the
  // normalized page URL) and a content hash of the significant fields so a
  // re-scrape can tell "same event, unchanged" from "same event, updated".
  dedupeKey: text("dedupe_key"),
  contentHash: text("content_hash"),

  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
}, (table) => [
  index("events_dedupe_key_idx").on(table.dedupeKey),
]);

export const insertEventSchema = createInsertSchema(eventsTable).omit({ id: true, createdAt: true });
export type InsertEvent = z.infer<typeof insertEventSchema>;
export type Event = typeof eventsTable.$inferSelect;
